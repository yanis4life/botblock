package com.example.botblocks.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.botblocks.format.TelegramFormatter
import com.example.botblocks.model.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KeyboardBuilderDialog(
    initialInlineKeyboard: InlineKeyboardConfig?,
    initialReplyKeyboard: ReplyKeyboardConfig?,
    onDismiss: () -> Unit,
    onApply: (inline: InlineKeyboardConfig?, reply: ReplyKeyboardConfig?, remove: RemoveKeyboardConfig?) -> Unit
) {
    var activeTab by remember { mutableStateOf(if (initialReplyKeyboard != null) 1 else 0) }

    // Inline Keyboard State
    var inlineRows by remember {
        mutableStateOf(
            initialInlineKeyboard?.rows ?: listOf(
                InlineKeyboardRow(
                    buttons = listOf(
                        InlineButton(text = "Option 1", actionType = ActionType.CALLBACK_DATA, actionValue = "opt_1", style = ButtonStyle.PRIMARY),
                        InlineButton(text = "Option 2", actionType = ActionType.CALLBACK_DATA, actionValue = "opt_2", style = ButtonStyle.DEFAULT)
                    )
                )
            )
        )
    }

    // Reply Keyboard State
    var replyRows by remember {
        mutableStateOf(
            initialReplyKeyboard?.rows ?: listOf(
                ReplyKeyboardRow(
                    buttons = listOf(
                        ReplyKeyboardButton(text = "Option A"),
                        ReplyKeyboardButton(text = "Option B")
                    )
                )
            )
        )
    }
    var resizeKeyboard by remember { mutableStateOf(initialReplyKeyboard?.resizeKeyboard ?: true) }
    var oneTimeKeyboard by remember { mutableStateOf(initialReplyKeyboard?.oneTimeKeyboard ?: false) }
    var placeholderText by remember { mutableStateOf(initialReplyKeyboard?.inputFieldPlaceholder ?: "") }
    var removeMarkupSelected by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(12.dp))
                .testTag("keyboard_builder_dialog"),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Keyboard & Reply Markup Builder", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Configure inline buttons, Bot API 9.0 button styles, or custom reply keyboards", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("keyboard_builder_close_button")) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Tabs: Inline Keyboard vs Reply Keyboard vs Remove Markup
                TabRow(selectedTabIndex = activeTab) {
                    Tab(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0; removeMarkupSelected = false },
                        text = { Text("Inline Keyboard") }
                    )
                    Tab(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1; removeMarkupSelected = false },
                        text = { Text("Reply Keyboard") }
                    )
                    Tab(
                        selected = activeTab == 2,
                        onClick = { activeTab = 2; removeMarkupSelected = true },
                        text = { Text("Remove Markup") }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(modifier = Modifier.weight(1f)) {
                    when (activeTab) {
                        0 -> InlineKeyboardTabContent(
                            rows = inlineRows,
                            onUpdateRows = { inlineRows = it }
                        )
                        1 -> ReplyKeyboardTabContent(
                            rows = replyRows,
                            onUpdateRows = { replyRows = it },
                            resizeKeyboard = resizeKeyboard,
                            onUpdateResize = { resizeKeyboard = it },
                            oneTimeKeyboard = oneTimeKeyboard,
                            onUpdateOneTime = { oneTimeKeyboard = it },
                            placeholder = placeholderText,
                            onUpdatePlaceholder = { placeholderText = it }
                        )
                        2 -> RemoveMarkupTabContent()
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            when (activeTab) {
                                0 -> onApply(InlineKeyboardConfig(inlineRows), null, null)
                                1 -> onApply(null, ReplyKeyboardConfig(replyRows, resizeKeyboard, oneTimeKeyboard, false, placeholderText), null)
                                2 -> onApply(null, null, RemoveKeyboardConfig(true, false))
                            }
                            onDismiss()
                        },
                        modifier = Modifier.testTag("apply_keyboard_button")
                    ) {
                        Text("Save Markup")
                    }
                }
            }
        }
    }
}

@Composable
private fun InlineKeyboardTabContent(
    rows: List<InlineKeyboardRow>,
    onUpdateRows: (List<InlineKeyboardRow>) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Button Rows (${rows.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            OutlinedButton(
                onClick = {
                    val newRow = InlineKeyboardRow(
                        buttons = listOf(
                            InlineButton(
                                text = "New Button",
                                actionType = ActionType.CALLBACK_DATA,
                                actionValue = "action_${System.currentTimeMillis() % 1000}"
                            )
                        )
                    )
                    onUpdateRows(rows + newRow)
                },
                modifier = Modifier.testTag("add_inline_row_button"),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Row")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            itemsIndexed(rows) { rowIndex, row ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Row ${rowIndex + 1}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Row {
                                TextButton(
                                    onClick = {
                                        val newBtn = InlineButton(text = "Btn", actionType = ActionType.CALLBACK_DATA, actionValue = "data")
                                        val updatedRow = row.copy(buttons = row.buttons + newBtn)
                                        val updated = rows.toMutableList()
                                        updated[rowIndex] = updatedRow
                                        onUpdateRows(updated)
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Text("Add Button")
                                }
                                IconButton(
                                    onClick = {
                                        val updated = rows.toMutableList()
                                        updated.removeAt(rowIndex)
                                        onUpdateRows(updated)
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Row", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        for ((btnIndex, btn) in row.buttons.withIndex()) {
                            InlineButtonEditor(
                                button = btn,
                                onUpdate = { updatedBtn ->
                                    val newButtons = row.buttons.toMutableList()
                                    newButtons[btnIndex] = updatedBtn
                                    val updatedRows = rows.toMutableList()
                                    updatedRows[rowIndex] = row.copy(buttons = newButtons)
                                    onUpdateRows(updatedRows)
                                },
                                onDelete = {
                                    val newButtons = row.buttons.toMutableList()
                                    newButtons.removeAt(btnIndex)
                                    val updatedRows = rows.toMutableList()
                                    updatedRows[rowIndex] = row.copy(buttons = newButtons)
                                    onUpdateRows(updatedRows)
                                }
                            )
                            if (btnIndex < row.buttons.size - 1) {
                                Spacer(modifier = Modifier.height(6.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InlineButtonEditor(
    button: InlineButton,
    onUpdate: (InlineButton) -> Unit,
    onDelete: () -> Unit
) {
    var expandedActionType by remember { mutableStateOf(false) }
    var expandedStyle by remember { mutableStateOf(false) }

    val (valid, byteCountMsg) = if (button.actionType == ActionType.CALLBACK_DATA) {
        TelegramFormatter.validateCallbackData(button.actionValue)
    } else {
        Pair(true, "")
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(6.dp)),
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = button.text,
                    onValueChange = { onUpdate(button.copy(text = it)) },
                    label = { Text("Button Text") },
                    modifier = Modifier.weight(1.2f),
                    singleLine = true
                )

                // Action Type Dropdown
                Box(modifier = Modifier.weight(1.3f)) {
                    ExposedDropdownMenuBox(
                        expanded = expandedActionType,
                        onExpandedChange = { expandedActionType = it }
                    ) {
                        OutlinedTextField(
                            value = button.actionType.displayName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Action Type") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedActionType) },
                            modifier = Modifier.menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = expandedActionType,
                            onDismissRequest = { expandedActionType = false }
                        ) {
                            ActionType.values().forEach { at ->
                                DropdownMenuItem(
                                    text = { Text(at.displayName) },
                                    onClick = {
                                        onUpdate(button.copy(actionType = at))
                                        expandedActionType = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Button Style (Bot API 9.0)
                Box(modifier = Modifier.weight(1f)) {
                    ExposedDropdownMenuBox(
                        expanded = expandedStyle,
                        onExpandedChange = { expandedStyle = it }
                    ) {
                        OutlinedTextField(
                            value = button.style.displayName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Style (9.0)") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedStyle) },
                            modifier = Modifier.menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = expandedStyle,
                            onDismissRequest = { expandedStyle = false }
                        ) {
                            ButtonStyle.values().forEach { st ->
                                DropdownMenuItem(
                                    text = { Text(st.displayName) },
                                    onClick = {
                                        onUpdate(button.copy(style = st))
                                        expandedStyle = false
                                    }
                                )
                            }
                        }
                    }
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Remove Button", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Action Value input (e.g. callback_data or URL)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = button.actionValue,
                    onValueChange = { onUpdate(button.copy(actionValue = it)) },
                    label = { Text(button.actionType.displayName) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    isError = !valid
                )
                if (button.actionType == ActionType.CALLBACK_DATA) {
                    Text(
                        text = byteCountMsg,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = if (!valid) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ReplyKeyboardTabContent(
    rows: List<ReplyKeyboardRow>,
    onUpdateRows: (List<ReplyKeyboardRow>) -> Unit,
    resizeKeyboard: Boolean,
    onUpdateResize: (Boolean) -> Unit,
    oneTimeKeyboard: Boolean,
    onUpdateOneTime: (Boolean) -> Unit,
    placeholder: String,
    onUpdatePlaceholder: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Reply Buttons", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            OutlinedButton(
                onClick = {
                    val newRow = ReplyKeyboardRow(buttons = listOf(ReplyKeyboardButton(text = "New Option")))
                    onUpdateRows(rows + newRow)
                },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Row")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = resizeKeyboard, onCheckedChange = onUpdateResize)
                Text("Resize Keyboard", style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = oneTimeKeyboard, onCheckedChange = onUpdateOneTime)
                Text("One-Time Keyboard", style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        OutlinedTextField(
            value = placeholder,
            onValueChange = onUpdatePlaceholder,
            label = { Text("Input Field Placeholder") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(rows) { rIdx, row ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Row ${rIdx + 1}", style = MaterialTheme.typography.labelMedium)
                            IconButton(
                                onClick = {
                                    val updated = rows.toMutableList()
                                    updated.removeAt(rIdx)
                                    onUpdateRows(updated)
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Row", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                        for ((bIdx, btn) in row.buttons.withIndex()) {
                            OutlinedTextField(
                                value = btn.text,
                                onValueChange = {
                                    val newBtns = row.buttons.toMutableList()
                                    newBtns[bIdx] = btn.copy(text = it)
                                    val updatedRows = rows.toMutableList()
                                    updatedRows[rIdx] = row.copy(buttons = newBtns)
                                    onUpdateRows(updatedRows)
                                },
                                label = { Text("Button Text") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RemoveMarkupTabContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.secondary)
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            "ReplyKeyboardRemove Active",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            "This will send a signal to remove the custom keyboard interface for users.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
