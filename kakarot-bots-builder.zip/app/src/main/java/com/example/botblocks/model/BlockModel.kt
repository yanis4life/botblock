package com.example.botblocks.model

import java.util.UUID

enum class ExecutionMode {
    LONG_POLLING,
    WEBHOOK
}

enum class ParseMode(val apiValue: String, val displayName: String) {
    NONE("", "Plain Text"),
    MARKDOWN_V2("MarkdownV2", "MarkdownV2"),
    HTML("HTML", "HTML")
}

enum class ButtonStyle(val apiValue: String, val displayName: String) {
    DEFAULT("default", "Default"),
    PRIMARY("primary", "Primary"),
    SUCCESS("success", "Success"),
    DANGER("danger", "Danger")
}

enum class ActionType(val displayName: String) {
    CALLBACK_DATA("Callback Data"),
    URL("URL"),
    WEB_APP("Web App URL"),
    LOGIN_URL("Login URL"),
    SWITCH_INLINE_QUERY("Switch Inline Query"),
    SWITCH_INLINE_QUERY_CURRENT_CHAT("Switch Inline Current Chat"),
    PAY("Pay"),
    COPY_TEXT("Copy Text")
}

data class InlineButton(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "Button",
    val actionType: ActionType = ActionType.CALLBACK_DATA,
    val actionValue: String = "btn_click",
    val style: ButtonStyle = ButtonStyle.DEFAULT
)

data class InlineKeyboardRow(
    val id: String = UUID.randomUUID().toString(),
    val buttons: List<InlineButton> = emptyList()
)

data class InlineKeyboardConfig(
    val rows: List<InlineKeyboardRow> = emptyList()
)

data class ReplyKeyboardButton(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "Option",
    val requestContact: Boolean = false,
    val requestLocation: Boolean = false
)

data class ReplyKeyboardRow(
    val id: String = UUID.randomUUID().toString(),
    val buttons: List<ReplyKeyboardButton> = emptyList()
)

data class ReplyKeyboardConfig(
    val rows: List<ReplyKeyboardRow> = emptyList(),
    val resizeKeyboard: Boolean = true,
    val oneTimeKeyboard: Boolean = false,
    val selective: Boolean = false,
    val inputFieldPlaceholder: String = ""
)

data class RemoveKeyboardConfig(
    val removeKeyboard: Boolean = true,
    val selective: Boolean = false
)

enum class BlockCategory(val displayName: String) {
    EVENTS("Events"),
    MESSAGES("Messages"),
    MEDIA("Media"),
    KEYBOARDS("Keyboards"),
    EDITING("Editing"),
    CHAT_ADMIN("Chat Admin"),
    PAYMENTS("Payments"),
    LOGIC("Logic"),
    HTTP_WEB("Network & HTTP"),
    UPDATES("Updates & Webhook")
}

enum class ParameterType {
    STRING,
    TEXT_MULTILINE,
    INTEGER,
    BOOLEAN,
    PARSE_MODE,
    INLINE_KEYBOARD,
    REPLY_KEYBOARD,
    OPTION_LIST
}

data class ParameterDefinition(
    val key: String,
    val label: String,
    val type: ParameterType,
    val defaultValue: String = "",
    val required: Boolean = false,
    val options: List<String> = emptyList(),
    val hint: String = ""
)

data class BlockDefinition(
    val typeId: String,
    val title: String,
    val category: BlockCategory,
    val description: String,
    val parameters: List<ParameterDefinition>,
    val isEvent: Boolean = false,
    val hasBranch: Boolean = false,
    val returnVariableName: String? = null
)

data class BlockNode(
    val id: String = UUID.randomUUID().toString(),
    val typeId: String,
    val title: String,
    val category: BlockCategory,
    val parameters: Map<String, String> = emptyMap(),
    val inlineKeyboard: InlineKeyboardConfig? = null,
    val replyKeyboard: ReplyKeyboardConfig? = null,
    val removeKeyboard: RemoveKeyboardConfig? = null,
    val nextBlockId: String? = null,
    val branchBlockId: String? = null,
    val elseBlockId: String? = null,
    val posX: Float = 0f,
    val posY: Float = 0f
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "New Bot Project",
    val description: String = "Visual Telegram Bot",
    val botToken: String = "",
    val executionMode: ExecutionMode = ExecutionMode.LONG_POLLING,
    val webhookUrl: String = "",
    val blocks: List<BlockNode> = emptyList(),
    val variables: Map<String, String> = emptyMap(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class ProjectVersion(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val versionName: String,
    val description: String = "",
    val snapshotJson: String,
    val blockCount: Int,
    val timestamp: Long = System.currentTimeMillis()
)

