package com.example.botblocks.codegen

import com.example.botblocks.model.*

object RequirementsGenerator {
    fun generate(): String {
        return """
python-telegram-bot>=20.8
aiohttp>=3.9.0
requests>=2.31.0
""".trimIndent()
    }
}

object PythonCodeGenerator {

    fun generate(project: Project): String {
        val sb = StringBuilder()

        sb.append("import asyncio\n")
        sb.append("import os\n")
        sb.append("import aiohttp\n")
        sb.append("from telegram import (\n")
        sb.append("    Update,\n")
        sb.append("    InlineKeyboardButton,\n")
        sb.append("    InlineKeyboardMarkup,\n")
        sb.append("    KeyboardButton,\n")
        sb.append("    ReplyKeyboardMarkup,\n")
        sb.append("    ReplyKeyboardRemove,\n")
        sb.append("    constants,\n")
        sb.append(")\n")
        sb.append("from telegram.ext import (\n")
        sb.append("    Application,\n")
        sb.append("    CommandHandler,\n")
        sb.append("    MessageHandler,\n")
        sb.append("    CallbackQueryHandler,\n")
        sb.append("    InlineQueryHandler,\n")
        sb.append("    ContextTypes,\n")
        sb.append("    filters,\n")
        sb.append(")\n\n")

        val tokenLiteral = if (project.botToken.isNotBlank()) "\"${project.botToken}\"" else "os.environ.get(\"TELEGRAM_BOT_TOKEN\", \"YOUR_BOT_TOKEN_HERE\")"
        sb.append("BOT_TOKEN = $tokenLiteral\n\n")

        // Group event blocks
        val eventBlocks = project.blocks.filter { it.isEventBlock() }.sortedBy { it.id }

        for (eventBlock in eventBlocks) {
            generateEventHandlerFunction(sb, project, eventBlock)
        }

        // Main entry function
        sb.append("def main() -> None:\n")
        sb.append("    application = Application.builder().token(BOT_TOKEN).build()\n\n")

        for (eventBlock in eventBlocks) {
            val funcName = getHandlerFunctionName(eventBlock)
            when (eventBlock.typeId) {
                "on_message" -> {
                    val filterType = eventBlock.parameters["filter_type"] ?: "Any"
                    val filterVal = eventBlock.parameters["filter_value"]?.trim().orEmpty()
                    when (filterType) {
                        "Command" -> {
                            val cmd = filterVal.removePrefix("/").ifBlank { "start" }
                            sb.append("    application.add_handler(CommandHandler(\"$cmd\", $funcName))\n")
                        }
                        "Photo" -> {
                            sb.append("    application.add_handler(MessageHandler(filters.PHOTO, $funcName))\n")
                        }
                        "Document" -> {
                            sb.append("    application.add_handler(MessageHandler(filters.Document.ALL, $funcName))\n")
                        }
                        else -> {
                            sb.append("    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, $funcName))\n")
                        }
                    }
                }
                "on_callback_query" -> {
                    val pattern = eventBlock.parameters["data_pattern"]?.trim().orEmpty()
                    if (pattern.isNotBlank()) {
                        sb.append("    application.add_handler(CallbackQueryHandler($funcName, pattern=\"^$pattern\"))\n")
                    } else {
                        sb.append("    application.add_handler(CallbackQueryHandler($funcName))\n")
                    }
                }
                "on_inline_query" -> {
                    sb.append("    application.add_handler(InlineQueryHandler($funcName))\n")
                }
                "on_channel_post" -> {
                    sb.append("    application.add_handler(MessageHandler(filters.ChatType.CHANNEL, $funcName))\n")
                }
            }
        }

        sb.append("\n")
        if (project.executionMode == ExecutionMode.WEBHOOK && project.webhookUrl.isNotBlank()) {
            sb.append("    application.run_webhook(\n")
            sb.append("        listen=\"0.0.0.0\",\n")
            sb.append("        port=8443,\n")
            sb.append("        webhook_url=\"${project.webhookUrl}\",\n")
            sb.append("        secret_token=\"secret\"\n")
            sb.append("    )\n")
        } else {
            sb.append("    application.run_polling(allowed_updates=Update.ALL_TYPES)\n")
        }

        sb.append("\n\nif __name__ == \"__main__\":\n")
        sb.append("    main()\n")

        return sb.toString()
    }

    private fun BlockNode.isEventBlock(): Boolean {
        return typeId.startsWith("on_")
    }

    private fun getHandlerFunctionName(block: BlockNode): String {
        val safeId = block.id.replace("-", "_").take(8)
        return when (block.typeId) {
            "on_message" -> {
                val fVal = block.parameters["filter_value"]?.removePrefix("/")?.replace("[^a-zA-Z0-9_]".toRegex(), "") ?: ""
                if (fVal.isNotBlank()) "handle_${fVal}_$safeId" else "handle_message_$safeId"
            }
            "on_callback_query" -> "handle_callback_$safeId"
            "on_inline_query" -> "handle_inline_$safeId"
            "on_channel_post" -> "handle_channel_post_$safeId"
            else -> "handle_event_$safeId"
        }
    }

    private fun generateEventHandlerFunction(sb: StringBuilder, project: Project, eventBlock: BlockNode) {
        val funcName = getHandlerFunctionName(eventBlock)
        sb.append("async def $funcName(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:\n")

        val indent = "    "
        when (eventBlock.typeId) {
            "on_callback_query" -> {
                sb.append("${indent}query = update.callback_query\n")
                sb.append("${indent}chat_id = update.effective_chat.id if update.effective_chat else 0\n")
                sb.append("${indent}message_id = query.message.message_id if query.message else 0\n")
                sb.append("${indent}callback_query_id = query.id\n")
                sb.append("${indent}callback_data = query.data or \"\"\n")
                sb.append("${indent}user_id = query.from_user.id\n")
                sb.append("${indent}user_name = query.from_user.username or query.from_user.first_name\n")
            }
            else -> {
                sb.append("${indent}chat_id = update.effective_chat.id if update.effective_chat else 0\n")
                sb.append("${indent}message_id = update.effective_message.message_id if update.effective_message else 0\n")
                sb.append("${indent}text = update.effective_message.text or \"\"\n")
                sb.append("${indent}user_id = update.effective_user.id if update.effective_user else 0\n")
                sb.append("${indent}user_name = update.effective_user.username or update.effective_user.first_name if update.effective_user else \"User\"\n")
            }
        }

        if (eventBlock.nextBlockId == null) {
            sb.append("${indent}pass\n\n")
            return
        }

        generateBlockStatements(sb, project, eventBlock.nextBlockId, indent)
        sb.append("\n")
    }

    private fun generateBlockStatements(sb: StringBuilder, project: Project, startBlockId: String?, indent: String) {
        var currentId = startBlockId
        var loopGuard = 0

        while (currentId != null && loopGuard < 100) {
            loopGuard++
            val block = project.blocks.find { it.id == currentId } ?: break

            generateSingleBlockStatement(sb, project, block, indent)

            if (block.typeId == "if_condition") {
                break
            } else if (block.typeId == "loop_times") {
                currentId = block.nextBlockId
            } else {
                currentId = block.nextBlockId
            }
        }
    }

    private fun generateSingleBlockStatement(sb: StringBuilder, project: Project, block: BlockNode, indent: String) {
        fun formatParam(value: String): String {
            return value
                .replace("{chat_id}", "{chat_id}")
                .replace("{user_id}", "{user_id}")
                .replace("{user_name}", "{user_name}")
                .replace("{text}", "{text}")
                .replace("{message_id}", "{message_id}")
                .replace("{callback_query_id}", "{callback_query_id}")
                .replace("{callback_data}", "{callback_data}")
        }

        fun toPythonString(raw: String): String {
            val formatted = formatParam(raw)
            val escaped = formatted.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
            return if (formatted.contains("{")) {
                "f\"$escaped\""
            } else {
                "\"$escaped\""
            }
        }

        when (block.typeId) {
            "send_message" -> {
                val chatIdStr = block.parameters["chat_id"] ?: "{chat_id}"
                val targetChat = if (chatIdStr == "{chat_id}") "chat_id" else toPythonString(chatIdStr)
                val text = toPythonString(block.parameters["text"] ?: "")
                val parseMode = block.parameters["parse_mode"] ?: "MarkdownV2"
                val disableNotif = block.parameters["disable_notification"]?.toBoolean() ?: false
                val protectContent = block.parameters["protect_content"]?.toBoolean() ?: false

                sb.append("${indent}await context.bot.send_message(\n")
                sb.append("$indent    chat_id=$targetChat,\n")
                sb.append("$indent    text=$text,\n")

                if (parseMode.equals("MarkdownV2", ignoreCase = true)) {
                    sb.append("$indent    parse_mode=constants.ParseMode.MARKDOWN_V2,\n")
                } else if (parseMode.equals("HTML", ignoreCase = true)) {
                    sb.append("$indent    parse_mode=constants.ParseMode.HTML,\n")
                }

                if (disableNotif) sb.append("$indent    disable_notification=True,\n")
                if (protectContent) sb.append("$indent    protect_content=True,\n")

                block.inlineKeyboard?.let { kb ->
                    if (kb.rows.isNotEmpty()) {
                        val kbPy = generateInlineKeyboardPython(kb, "$indent    ")
                        sb.append("$indent    reply_markup=$kbPy,\n")
                    }
                }
                block.replyKeyboard?.let { rkb ->
                    if (rkb.rows.isNotEmpty()) {
                        val rkbPy = generateReplyKeyboardPython(rkb, "$indent    ")
                        sb.append("$indent    reply_markup=$rkbPy,\n")
                    }
                }
                block.removeKeyboard?.let {
                    sb.append("$indent    reply_markup=ReplyKeyboardRemove(selective=${if (it.selective) "True" else "False"}),\n")
                }

                sb.append("${indent})\n")
            }

            "send_photo" -> {
                val targetChat = if ((block.parameters["chat_id"] ?: "") == "{chat_id}") "chat_id" else toPythonString(block.parameters["chat_id"] ?: "")
                val photo = toPythonString(block.parameters["photo"] ?: "")
                val caption = toPythonString(block.parameters["caption"] ?: "")
                val parseMode = block.parameters["parse_mode"] ?: ""

                sb.append("${indent}await context.bot.send_photo(\n")
                sb.append("$indent    chat_id=$targetChat,\n")
                sb.append("$indent    photo=$photo,\n")
                sb.append("$indent    caption=$caption,\n")
                if (parseMode.equals("MarkdownV2", ignoreCase = true)) {
                    sb.append("$indent    parse_mode=constants.ParseMode.MARKDOWN_V2,\n")
                }
                block.inlineKeyboard?.let { kb ->
                    if (kb.rows.isNotEmpty()) {
                        sb.append("$indent    reply_markup=${generateInlineKeyboardPython(kb, "$indent    ")},\n")
                    }
                }
                sb.append("${indent})\n")
            }

            "send_poll" -> {
                val targetChat = if ((block.parameters["chat_id"] ?: "") == "{chat_id}") "chat_id" else toPythonString(block.parameters["chat_id"] ?: "")
                val question = toPythonString(block.parameters["question"] ?: "")
                val options = (block.parameters["options"] ?: "").split(",").map { "\"${it.trim()}\"" }.joinToString(", ")
                val isAnon = block.parameters["is_anonymous"]?.toBoolean() ?: true
                val pollType = block.parameters["type"] ?: "regular"

                sb.append("${indent}await context.bot.send_poll(\n")
                sb.append("$indent    chat_id=$targetChat,\n")
                sb.append("$indent    question=$question,\n")
                sb.append("$indent    options=[$options],\n")
                sb.append("$indent    is_anonymous=${if (isAnon) "True" else "False"},\n")
                sb.append("$indent    type=\"$pollType\",\n")
                if (pollType == "quiz") {
                    val correctId = block.parameters["correct_option_id"]?.toIntOrNull() ?: 0
                    sb.append("$indent    correct_option_id=$correctId,\n")
                }
                sb.append("${indent})\n")
            }

            "send_dice" -> {
                val targetChat = if ((block.parameters["chat_id"] ?: "") == "{chat_id}") "chat_id" else toPythonString(block.parameters["chat_id"] ?: "")
                val emoji = block.parameters["emoji"] ?: "dice"
                val diceChar = when (emoji) {
                    "dart" -> "\uD83C\uDFAF"
                    "basketball" -> "\uD83C\uDFC0"
                    "football" -> "\u26BD"
                    "slot_machine" -> "\uD83C\uDFB0"
                    "bowling" -> "\uD83C\uDFB3"
                    else -> "\uD83C\uDFB2"
                }
                sb.append("${indent}await context.bot.send_dice(chat_id=$targetChat, emoji=\"$diceChar\")\n")
            }

            "edit_message_text" -> {
                val targetChat = if ((block.parameters["chat_id"] ?: "") == "{chat_id}") "chat_id" else toPythonString(block.parameters["chat_id"] ?: "")
                val messageId = if ((block.parameters["message_id"] ?: "") == "{message_id}") "message_id" else block.parameters["message_id"] ?: "0"
                val text = toPythonString(block.parameters["text"] ?: "")

                sb.append("${indent}await context.bot.edit_message_text(\n")
                sb.append("$indent    chat_id=$targetChat,\n")
                sb.append("$indent    message_id=$messageId,\n")
                sb.append("$indent    text=$text\n")
                sb.append("${indent})\n")
            }

            "answer_callback_query" -> {
                val text = toPythonString(block.parameters["text"] ?: "")
                val showAlert = if (block.parameters["show_alert"]?.toBoolean() == true) "True" else "False"
                sb.append("${indent}await context.bot.answer_callback_query(\n")
                sb.append("$indent    callback_query_id=callback_query_id,\n")
                sb.append("$indent    text=$text,\n")
                sb.append("$indent    show_alert=$showAlert\n")
                sb.append("${indent})\n")
            }

            "delete_message" -> {
                val targetChat = if ((block.parameters["chat_id"] ?: "") == "{chat_id}") "chat_id" else toPythonString(block.parameters["chat_id"] ?: "")
                val messageId = if ((block.parameters["message_id"] ?: "") == "{message_id}") "message_id" else block.parameters["message_id"] ?: "0"
                sb.append("${indent}await context.bot.delete_message(chat_id=$targetChat, message_id=$messageId)\n")
            }

            "ban_chat_member" -> {
                val targetChat = if ((block.parameters["chat_id"] ?: "") == "{chat_id}") "chat_id" else toPythonString(block.parameters["chat_id"] ?: "")
                val userId = if ((block.parameters["user_id"] ?: "") == "{user_id}") "user_id" else block.parameters["user_id"] ?: "0"
                val revoke = if (block.parameters["revoke_messages"]?.toBoolean() == true) "True" else "False"
                sb.append("${indent}await context.bot.ban_chat_member(chat_id=$targetChat, user_id=$userId, revoke_messages=$revoke)\n")
            }

            "pin_chat_message" -> {
                val targetChat = if ((block.parameters["chat_id"] ?: "") == "{chat_id}") "chat_id" else toPythonString(block.parameters["chat_id"] ?: "")
                val messageId = if ((block.parameters["message_id"] ?: "") == "{message_id}") "message_id" else block.parameters["message_id"] ?: "0"
                sb.append("${indent}await context.bot.pin_chat_message(chat_id=$targetChat, message_id=$messageId)\n")
            }

            "set_variable" -> {
                val varName = block.parameters["var_name"] ?: "temp"
                val varValue = toPythonString(block.parameters["var_value"] ?: "")
                sb.append("${indent}context.user_data[\"$varName\"] = $varValue\n")
            }

            "string_operation" -> {
                val op = block.parameters["operation"] ?: "uppercase"
                val input = toPythonString(block.parameters["input_text"] ?: "")
                val target = block.parameters["target_var"] ?: "result"
                val pyExpr = when (op) {
                    "uppercase" -> "str($input).upper()"
                    "lowercase" -> "str($input).lower()"
                    "trim" -> "str($input).strip()"
                    "replace" -> "str($input).replace(\"${block.parameters["search_pattern"] ?: ""}\", \"${block.parameters["replace_value"] ?: ""}\")"
                    "length" -> "str(len(str($input)))"
                    else -> input
                }
                sb.append("${indent}context.user_data[\"$target\"] = $pyExpr\n")
            }

            "json_parse" -> {
                val src = toPythonString(block.parameters["source_json"] ?: "{}")
                val key = block.parameters["json_key"] ?: ""
                val target = block.parameters["target_var"] ?: "val"
                sb.append("${indent}import json\n")
                sb.append("${indent}context.user_data[\"$target\"] = json.loads($src).get(\"$key\", \"\")\n")
            }

            "http_request" -> {
                val method = block.parameters["method"]?.lowercase() ?: "get"
                val url = toPythonString(block.parameters["url"] ?: "")
                val target = block.parameters["target_var"] ?: "response_body"
                sb.append("${indent}async with aiohttp.ClientSession() as session:\n")
                sb.append("$indent    async with session.$method($url) as resp:\n")
                sb.append("$indent        context.user_data[\"$target\"] = await resp.text()\n")
            }

            "delay_seconds" -> {
                val secs = block.parameters["seconds"]?.toIntOrNull() ?: 1
                sb.append("${indent}await asyncio.sleep($secs)\n")
            }

            "if_condition" -> {
                val left = toPythonString(block.parameters["left_operand"] ?: "")
                val op = block.parameters["operator"] ?: "equals"
                val right = toPythonString(block.parameters["right_operand"] ?: "")

                val condStr = when (op) {
                    "equals" -> "str($left).lower() == str($right).lower()"
                    "not_equals" -> "str($left).lower() != str($right).lower()"
                    "contains" -> "str($right).lower() in str($left).lower()"
                    "starts_with" -> "str($left).lower().startswith(str($right).lower())"
                    "ends_with" -> "str($left).lower().endswith(str($right).lower())"
                    "is_empty" -> "not str($left).strip()"
                    "is_not_empty" -> "bool(str($left).strip())"
                    "greater_than" -> "float($left) > float($right)"
                    "less_than" -> "float($left) < float($right)"
                    else -> "True"
                }

                sb.append("${indent}if $condStr:\n")
                if (block.branchBlockId != null) {
                    generateBlockStatements(sb, project, block.branchBlockId, "$indent    ")
                } else {
                    sb.append("$indent    pass\n")
                }

                if (block.elseBlockId != null) {
                    sb.append("${indent}else:\n")
                    generateBlockStatements(sb, project, block.elseBlockId, "$indent    ")
                }
            }

            "loop_times" -> {
                val count = block.parameters["count"]?.toIntOrNull() ?: 3
                sb.append("${indent}for loop_idx in range($count):\n")
                if (block.branchBlockId != null) {
                    generateBlockStatements(sb, project, block.branchBlockId, "$indent    ")
                } else {
                    sb.append("$indent    pass\n")
                }
            }
        }
    }

    private fun generateInlineKeyboardPython(kb: InlineKeyboardConfig, baseIndent: String): String {
        val rowsList = mutableListOf<String>()
        for (row in kb.rows) {
            val btnsList = mutableListOf<String>()
            for (btn in row.buttons) {
                val actVal = btn.actionValue.replace("\"", "\\\"")
                val textVal = btn.text.replace("\"", "\\\"")
                val actParam = when (btn.actionType) {
                    ActionType.CALLBACK_DATA -> "callback_data=\"$actVal\""
                    ActionType.URL -> "url=\"$actVal\""
                    ActionType.WEB_APP -> "web_app={\"url\": \"$actVal\"}"
                    ActionType.SWITCH_INLINE_QUERY -> "switch_inline_query=\"$actVal\""
                    ActionType.SWITCH_INLINE_QUERY_CURRENT_CHAT -> "switch_inline_query_current_chat=\"$actVal\""
                    ActionType.PAY -> "pay=True"
                    ActionType.COPY_TEXT -> "copy_text={\"text\": \"$actVal\"}"
                    ActionType.LOGIN_URL -> "login_url={\"url\": \"$actVal\"}"
                }
                btnsList.add("InlineKeyboardButton(\"$textVal\", $actParam)")
            }
            rowsList.add("[${btnsList.joinToString(", ")}]")
        }
        return "InlineKeyboardMarkup([\n$baseIndent    " + rowsList.joinToString(",\n$baseIndent    ") + "\n$baseIndent])"
    }

    private fun generateReplyKeyboardPython(rkb: ReplyKeyboardConfig, baseIndent: String): String {
        val rowsList = mutableListOf<String>()
        for (row in rkb.rows) {
            val btnsList = mutableListOf<String>()
            for (btn in row.buttons) {
                val t = btn.text.replace("\"", "\\\"")
                btnsList.add("KeyboardButton(\"$t\")")
            }
            rowsList.add("[${btnsList.joinToString(", ")}]")
        }
        val resize = if (rkb.resizeKeyboard) "True" else "False"
        val oneTime = if (rkb.oneTimeKeyboard) "True" else "False"
        return "ReplyKeyboardMarkup([\n$baseIndent    " + rowsList.joinToString(",\n$baseIndent    ") + "\n$baseIndent], resize_keyboard=$resize, one_time_keyboard=$oneTime)"
    }
}
