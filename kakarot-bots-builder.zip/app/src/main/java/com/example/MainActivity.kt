package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.example.botblocks.ui.BotBlocksScreen
import com.example.botblocks.ui.BotBlocksViewModel
import com.example.ui.theme.BotBlocksTheme

class MainActivity : ComponentActivity() {

    private val viewModel: BotBlocksViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BotBlocksTheme {
                BotBlocksScreen(
                    viewModel = viewModel,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
