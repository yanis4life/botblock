package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val AccentBlue = Color(0xFF2563EB)
val AccentBlueLight = Color(0xFF3B82F6)
val AccentSuccess = Color(0xFF10B981)
val AccentDanger = Color(0xFFEF4444)
val AccentWarning = Color(0xFFF59E0B)

// Sketchware-inspired categorized block colors (vibrant and distinct)
val CategoryEvents = Color(0xFFE65100)       // Sketchware Event Hat Gold
val CategoryMessages = Color(0xFF0288D1)     // Telegram API Blue
val CategoryMedia = Color(0xFF0097A7)        // Media Cyan
val CategoryKeyboards = Color(0xFF00897B)    // Keyboard Teal
val CategoryEditing = Color(0xFF2E7D32)      // Green Action
val CategoryAdmin = Color(0xFFC62828)        // Moderation Red
val CategoryPayments = Color(0xFFD97706)     // Payment Gold
val CategoryLogic = Color(0xFF6A1B9A)        // Control & Branching Purple
val CategoryNetwork = Color(0xFF37474F)      // Network Slate
val CategoryUpdates = Color(0xFF455A64)      // Polling / Webhook Slate
