package com.example.botblocks.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*

data class OnboardingSlide(
    val title: String,
    val subtitle: String,
    val description: String,
    val iconVector: androidx.compose.ui.graphics.vector.ImageVector,
    val badgeColor: Color
)

@Composable
fun OnboardingDialog(
    onDismiss: () -> Unit,
    onStartTutorial: () -> Unit
) {
    var currentSlideIndex by remember { mutableStateOf(0) }

    val slides = remember {
        listOf(
            OnboardingSlide(
                title = "Welcome to KAKAROT BOTS BUILDER",
                subtitle = "Visual Sketchware-Style Programming for Telegram Bots",
                description = "KAKAROT BOTS BUILDER lets you build, test, and deploy Telegram bots without writing boilerplate. Like Sketchware, blocks have interlocking puzzle shapes representing API events, actions, and logic that connect visually on a canvas.",
                iconVector = Icons.Default.Extension,
                badgeColor = CategoryEvents
            ),
            OnboardingSlide(
                title = "Events, Actions & Connections",
                subtitle = "How the Logic Flow Operates",
                description = "Golden Hat blocks listen for events like On /start or Button Clicks. Cyan Action blocks call Telegram Bot API methods like sendMessage or sendPhoto. Connect blocks sequentially or create branching logic with If/Else conditions.",
                iconVector = Icons.Default.AccountTree,
                badgeColor = CategoryMessages
            ),
            OnboardingSlide(
                title = "Bot Authentication & Tokens",
                subtitle = "Safe On-Device Credential Storage",
                description = "Every Telegram bot requires an API token from @BotFather. Enter your token in Project Settings. KAKAROT BOTS BUILDER tests token validity via getMe and manages authentication securely on device.",
                iconVector = Icons.Default.Security,
                badgeColor = CategoryKeyboards
            ),
            OnboardingSlide(
                title = "Run On Device & Export to Python",
                subtitle = "Dual Execution & Code Generation",
                description = "Run your bot live directly on your Android device using real long polling with real-time logs. When you are ready, export a clean, standalone, PEP 8 async Python script (python-telegram-bot v20+) with zero comments.",
                iconVector = Icons.Default.Terminal,
                badgeColor = CategoryLogic
            )
        )
    }

    val currentSlide = slides[currentSlideIndex]

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .clip(RoundedCornerShape(16.dp))
                .testTag("onboarding_dialog"),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Category Icon Badge
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(currentSlide.badgeColor.copy(alpha = 0.15f), CircleShape)
                        .border(2.dp, currentSlide.badgeColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = currentSlide.iconVector,
                        contentDescription = null,
                        modifier = Modifier.size(32.dp),
                        tint = currentSlide.badgeColor
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = currentSlide.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = currentSlide.subtitle,
                    style = MaterialTheme.typography.titleSmall,
                    color = currentSlide.badgeColor,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = currentSlide.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Page indicator dots
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    slides.indices.forEach { idx ->
                        Box(
                            modifier = Modifier
                                .size(if (idx == currentSlideIndex) 10.dp else 6.dp)
                                .background(
                                    if (idx == currentSlideIndex) currentSlide.badgeColor else MaterialTheme.colorScheme.outlineVariant,
                                    CircleShape
                                )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Bottom actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss, modifier = Modifier.testTag("onboarding_skip_button")) {
                        Text("Skip")
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (currentSlideIndex > 0) {
                            OutlinedButton(onClick = { currentSlideIndex-- }) {
                                Text("Back")
                            }
                        }

                        if (currentSlideIndex < slides.size - 1) {
                            Button(
                                onClick = { currentSlideIndex++ },
                                modifier = Modifier.testTag("onboarding_next_button")
                            ) {
                                Text("Next")
                            }
                        } else {
                            Button(
                                onClick = {
                                    onDismiss()
                                    onStartTutorial()
                                },
                                modifier = Modifier.testTag("onboarding_tutorial_button")
                            ) {
                                Text("Start Tutorial Bot")
                            }
                        }
                    }
                }
            }
        }
    }
}
