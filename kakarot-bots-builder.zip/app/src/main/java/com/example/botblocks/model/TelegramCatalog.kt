package com.example.botblocks.model

object TelegramCatalog {

    val allDefinitions: List<BlockDefinition> = listOf(
        // Events
        BlockDefinition(
            typeId = "on_message",
            title = "On Message Received",
            category = BlockCategory.EVENTS,
            description = "Triggers when a private or group message is received",
            parameters = listOf(
                ParameterDefinition("filter_type", "Filter Type", ParameterType.OPTION_LIST, "Any", false, listOf("Any", "Command", "Text Matches", "Contains Text", "Photo", "Document")),
                ParameterDefinition("filter_value", "Filter Value (e.g. /start or text)", ParameterType.STRING, "", false, hint = "Example: /start")
            ),
            isEvent = true
        ),
        BlockDefinition(
            typeId = "on_callback_query",
            title = "On Button Click (Callback)",
            category = BlockCategory.EVENTS,
            description = "Triggers when an inline keyboard button with callback_data is clicked",
            parameters = listOf(
                ParameterDefinition("filter_type", "Filter Type", ParameterType.OPTION_LIST, "Any", false, listOf("Any", "Exact Match", "Starts With")),
                ParameterDefinition("data_pattern", "Callback Data Pattern", ParameterType.STRING, "", false, hint = "Leave blank for any, or enter expected data")
            ),
            isEvent = true
        ),
        BlockDefinition(
            typeId = "on_inline_query",
            title = "On Inline Query",
            category = BlockCategory.EVENTS,
            description = "Triggers when user mentions the bot in any chat for inline results",
            parameters = listOf(),
            isEvent = true
        ),
        BlockDefinition(
            typeId = "on_channel_post",
            title = "On Channel Post",
            category = BlockCategory.EVENTS,
            description = "Triggers when a message is posted to a channel where bot is admin",
            parameters = listOf(),
            isEvent = true
        ),
        BlockDefinition(
            typeId = "on_chat_member_updated",
            title = "On Chat Member Updated",
            category = BlockCategory.EVENTS,
            description = "Triggers when a member joins, leaves, or member permissions change",
            parameters = listOf(),
            isEvent = true
        ),
        BlockDefinition(
            typeId = "on_poll_answer",
            title = "On Poll Answer",
            category = BlockCategory.EVENTS,
            description = "Triggers when a user votes in a non-anonymous poll",
            parameters = listOf(),
            isEvent = true
        ),
        BlockDefinition(
            typeId = "on_pre_checkout_query",
            title = "On Pre-Checkout Query",
            category = BlockCategory.EVENTS,
            description = "Triggers when a user confirms checkout for payment invoice",
            parameters = listOf(),
            isEvent = true
        ),
        BlockDefinition(
            typeId = "on_edited_message",
            title = "On Edited Message",
            category = BlockCategory.EVENTS,
            description = "Triggers when a user edits an existing message",
            parameters = listOf(),
            isEvent = true
        ),

        // Messages
        BlockDefinition(
            typeId = "send_message",
            title = "Send Message",
            category = BlockCategory.MESSAGES,
            description = "Sends text message with formatting, keyboards, and options",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true, hint = "Target user or group ID, e.g. {chat_id}"),
                ParameterDefinition("text", "Message Text", ParameterType.TEXT_MULTILINE, "Hello from BotBlocks!", true, hint = "Message content"),
                ParameterDefinition("parse_mode", "Parse Mode", ParameterType.PARSE_MODE, "MarkdownV2", false),
                ParameterDefinition("disable_notification", "Silent Notification", ParameterType.BOOLEAN, "false", false),
                ParameterDefinition("protect_content", "Protect Content (No Forward/Save)", ParameterType.BOOLEAN, "false", false),
                ParameterDefinition("disable_web_page_preview", "Disable Link Preview", ParameterType.BOOLEAN, "false", false),
                ParameterDefinition("message_thread_id", "Forum Thread ID", ParameterType.STRING, "", false)
            )
        ),
        BlockDefinition(
            typeId = "send_photo",
            title = "Send Photo",
            category = BlockCategory.MEDIA,
            description = "Sends a photo from URL or file_id with caption",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("photo", "Photo URL or File ID", ParameterType.STRING, "https://picsum.photos/600/400", true),
                ParameterDefinition("caption", "Caption", ParameterType.TEXT_MULTILINE, "", false),
                ParameterDefinition("parse_mode", "Parse Mode", ParameterType.PARSE_MODE, "MarkdownV2", false),
                ParameterDefinition("protect_content", "Protect Content", ParameterType.BOOLEAN, "false", false)
            )
        ),
        BlockDefinition(
            typeId = "send_document",
            title = "Send Document",
            category = BlockCategory.MEDIA,
            description = "Sends general file document from URL or file_id",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("document", "Document URL or File ID", ParameterType.STRING, "", true),
                ParameterDefinition("caption", "Caption", ParameterType.TEXT_MULTILINE, "", false),
                ParameterDefinition("parse_mode", "Parse Mode", ParameterType.PARSE_MODE, "MarkdownV2", false)
            )
        ),
        BlockDefinition(
            typeId = "send_video",
            title = "Send Video",
            category = BlockCategory.MEDIA,
            description = "Sends video file or URL",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("video", "Video URL or File ID", ParameterType.STRING, "", true),
                ParameterDefinition("caption", "Caption", ParameterType.TEXT_MULTILINE, "", false),
                ParameterDefinition("supports_streaming", "Supports Streaming", ParameterType.BOOLEAN, "true", false)
            )
        ),
        BlockDefinition(
            typeId = "send_animation",
            title = "Send Animation (GIF)",
            category = BlockCategory.MEDIA,
            description = "Sends animation/GIF without sound",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("animation", "Animation URL or File ID", ParameterType.STRING, "", true),
                ParameterDefinition("caption", "Caption", ParameterType.TEXT_MULTILINE, "", false)
            )
        ),
        BlockDefinition(
            typeId = "send_audio",
            title = "Send Audio",
            category = BlockCategory.MEDIA,
            description = "Sends audio file with music tags",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("audio", "Audio URL or File ID", ParameterType.STRING, "", true),
                ParameterDefinition("caption", "Caption", ParameterType.TEXT_MULTILINE, "", false),
                ParameterDefinition("performer", "Performer", ParameterType.STRING, "", false),
                ParameterDefinition("title", "Track Title", ParameterType.STRING, "", false)
            )
        ),
        BlockDefinition(
            typeId = "send_voice",
            title = "Send Voice Note",
            category = BlockCategory.MEDIA,
            description = "Sends voice note (OGG opus)",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("voice", "Voice URL or File ID", ParameterType.STRING, "", true),
                ParameterDefinition("caption", "Caption", ParameterType.TEXT_MULTILINE, "", false)
            )
        ),
        BlockDefinition(
            typeId = "send_video_note",
            title = "Send Video Note (Round)",
            category = BlockCategory.MEDIA,
            description = "Sends circular video note message",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("video_note", "Video Note URL or File ID", ParameterType.STRING, "", true),
                ParameterDefinition("length", "Diameter (pixels)", ParameterType.INTEGER, "240", false)
            )
        ),
        BlockDefinition(
            typeId = "send_poll",
            title = "Send Poll or Quiz",
            category = BlockCategory.MESSAGES,
            description = "Sends an interactive poll or quiz to chat",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("question", "Poll Question", ParameterType.STRING, "What is your preference?", true),
                ParameterDefinition("options", "Options (comma-separated)", ParameterType.STRING, "Option A, Option B, Option C", true),
                ParameterDefinition("is_anonymous", "Anonymous Poll", ParameterType.BOOLEAN, "true", false),
                ParameterDefinition("type", "Poll Type", ParameterType.OPTION_LIST, "regular", false, listOf("regular", "quiz")),
                ParameterDefinition("correct_option_id", "Quiz Correct Option Index (0-based)", ParameterType.INTEGER, "0", false),
                ParameterDefinition("explanation", "Quiz Explanation", ParameterType.STRING, "", false)
            )
        ),
        BlockDefinition(
            typeId = "send_dice",
            title = "Send Animated Dice",
            category = BlockCategory.MESSAGES,
            description = "Sends animated random dice or game roll",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("emoji", "Dice Type", ParameterType.OPTION_LIST, "dice", false, listOf("dice", "dart", "basketball", "football", "slot_machine", "bowling"))
            )
        ),
        BlockDefinition(
            typeId = "send_location",
            title = "Send Location",
            category = BlockCategory.MESSAGES,
            description = "Sends GPS coordinates to chat",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("latitude", "Latitude", ParameterType.STRING, "48.8584", true),
                ParameterDefinition("longitude", "Longitude", ParameterType.STRING, "2.2945", true)
            )
        ),
        BlockDefinition(
            typeId = "send_venue",
            title = "Send Venue",
            category = BlockCategory.MESSAGES,
            description = "Sends place venue with title and address",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("latitude", "Latitude", ParameterType.STRING, "48.8584", true),
                ParameterDefinition("longitude", "Longitude", ParameterType.STRING, "2.2945", true),
                ParameterDefinition("title", "Venue Name", ParameterType.STRING, "Eiffel Tower", true),
                ParameterDefinition("address", "Address", ParameterType.STRING, "Champ de Mars, 5 Av. Anatole France, Paris", true)
            )
        ),
        BlockDefinition(
            typeId = "send_contact",
            title = "Send Contact",
            category = BlockCategory.MESSAGES,
            description = "Sends phone contact card",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("phone_number", "Phone Number", ParameterType.STRING, "+1234567890", true),
                ParameterDefinition("first_name", "First Name", ParameterType.STRING, "John", true),
                ParameterDefinition("last_name", "Last Name", ParameterType.STRING, "Doe", false)
            )
        ),
        BlockDefinition(
            typeId = "send_chat_action",
            title = "Send Chat Action (Status)",
            category = BlockCategory.MESSAGES,
            description = "Shows typing, uploading photo, recording audio status in chat",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("action", "Action", ParameterType.OPTION_LIST, "typing", true, listOf("typing", "upload_photo", "record_video", "upload_video", "record_voice", "upload_voice", "upload_document", "choose_sticker", "find_location"))
            )
        ),

        // Message Editing
        BlockDefinition(
            typeId = "edit_message_text",
            title = "Edit Message Text",
            category = BlockCategory.EDITING,
            description = "Edits text and markup of an existing message",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("message_id", "Message ID", ParameterType.STRING, "{message_id}", true),
                ParameterDefinition("text", "New Message Text", ParameterType.TEXT_MULTILINE, "Updated message text", true),
                ParameterDefinition("parse_mode", "Parse Mode", ParameterType.PARSE_MODE, "MarkdownV2", false)
            )
        ),
        BlockDefinition(
            typeId = "edit_message_caption",
            title = "Edit Message Caption",
            category = BlockCategory.EDITING,
            description = "Edits caption of a sent media message",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("message_id", "Message ID", ParameterType.STRING, "{message_id}", true),
                ParameterDefinition("caption", "New Caption", ParameterType.TEXT_MULTILINE, "", true),
                ParameterDefinition("parse_mode", "Parse Mode", ParameterType.PARSE_MODE, "MarkdownV2", false)
            )
        ),
        BlockDefinition(
            typeId = "edit_message_reply_markup",
            title = "Edit Reply Markup",
            category = BlockCategory.EDITING,
            description = "Updates the inline keyboard buttons of a message without changing text",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("message_id", "Message ID", ParameterType.STRING, "{message_id}", true)
            )
        ),
        BlockDefinition(
            typeId = "delete_message",
            title = "Delete Message",
            category = BlockCategory.EDITING,
            description = "Deletes a message from chat",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("message_id", "Message ID", ParameterType.STRING, "{message_id}", true)
            )
        ),

        // Interactive Callbacks
        BlockDefinition(
            typeId = "answer_callback_query",
            title = "Answer Callback Query",
            category = BlockCategory.KEYBOARDS,
            description = "Acknowledges button click with a toast popup or modal alert",
            parameters = listOf(
                ParameterDefinition("callback_query_id", "Callback Query ID", ParameterType.STRING, "{callback_query_id}", true),
                ParameterDefinition("text", "Alert Text", ParameterType.STRING, "Action confirmed", false),
                ParameterDefinition("show_alert", "Show As Modal Alert", ParameterType.BOOLEAN, "false", false),
                ParameterDefinition("cache_time", "Cache Time (seconds)", ParameterType.INTEGER, "0", false)
            )
        ),

        // Chat Administration & Moderation
        BlockDefinition(
            typeId = "ban_chat_member",
            title = "Ban Chat Member",
            category = BlockCategory.CHAT_ADMIN,
            description = "Bans a user from group/channel",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("user_id", "Target User ID", ParameterType.STRING, "{user_id}", true),
                ParameterDefinition("revoke_messages", "Revoke Past Messages", ParameterType.BOOLEAN, "true", false)
            )
        ),
        BlockDefinition(
            typeId = "unban_chat_member",
            title = "Unban Chat Member",
            category = BlockCategory.CHAT_ADMIN,
            description = "Unbans a previously banned user",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("user_id", "Target User ID", ParameterType.STRING, "{user_id}", true)
            )
        ),
        BlockDefinition(
            typeId = "restrict_chat_member",
            title = "Restrict Chat Member (Mute/Perms)",
            category = BlockCategory.CHAT_ADMIN,
            description = "Restricts user messaging or media sending abilities",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("user_id", "User ID", ParameterType.STRING, "{user_id}", true),
                ParameterDefinition("can_send_messages", "Can Send Messages", ParameterType.BOOLEAN, "false", false),
                ParameterDefinition("can_send_other_messages", "Can Send Media", ParameterType.BOOLEAN, "false", false),
                ParameterDefinition("until_date", "Until Unix Timestamp (0 for forever)", ParameterType.STRING, "0", false)
            )
        ),
        BlockDefinition(
            typeId = "pin_chat_message",
            title = "Pin Chat Message",
            category = BlockCategory.CHAT_ADMIN,
            description = "Pins a message at top of group or channel",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("message_id", "Message ID", ParameterType.STRING, "{message_id}", true),
                ParameterDefinition("disable_notification", "Silent Pin", ParameterType.BOOLEAN, "false", false)
            )
        ),
        BlockDefinition(
            typeId = "unpin_chat_message",
            title = "Unpin Chat Message",
            category = BlockCategory.CHAT_ADMIN,
            description = "Unpins a pinned message",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("message_id", "Message ID", ParameterType.STRING, "{message_id}", false)
            )
        ),
        BlockDefinition(
            typeId = "leave_chat",
            title = "Leave Chat",
            category = BlockCategory.CHAT_ADMIN,
            description = "Causes bot to exit a group or supergroup",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true)
            )
        ),
        BlockDefinition(
            typeId = "get_chat",
            title = "Get Chat Info",
            category = BlockCategory.CHAT_ADMIN,
            description = "Fetches metadata about chat or user",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("target_var", "Store In Variable", ParameterType.STRING, "chat_info", false)
            )
        ),

        // Forwarding & Copying
        BlockDefinition(
            typeId = "forward_message",
            title = "Forward Message",
            category = BlockCategory.MESSAGES,
            description = "Forwards message with original author header",
            parameters = listOf(
                ParameterDefinition("chat_id", "Target Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("from_chat_id", "Source Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("message_id", "Message ID", ParameterType.STRING, "{message_id}", true)
            )
        ),
        BlockDefinition(
            typeId = "copy_message",
            title = "Copy Message (No Quote)",
            category = BlockCategory.MESSAGES,
            description = "Copies content of message as a new message without forward header",
            parameters = listOf(
                ParameterDefinition("chat_id", "Target Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("from_chat_id", "Source Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("message_id", "Message ID", ParameterType.STRING, "{message_id}", true),
                ParameterDefinition("caption", "Override Caption", ParameterType.STRING, "", false)
            )
        ),

        // Payments
        BlockDefinition(
            typeId = "send_invoice",
            title = "Send Payment Invoice",
            category = BlockCategory.PAYMENTS,
            description = "Sends an official Telegram payment invoice",
            parameters = listOf(
                ParameterDefinition("chat_id", "Chat ID", ParameterType.STRING, "{chat_id}", true),
                ParameterDefinition("title", "Product Title", ParameterType.STRING, "Premium Pass", true),
                ParameterDefinition("description", "Description", ParameterType.STRING, "1 Month Subscription", true),
                ParameterDefinition("payload", "Internal Payload", ParameterType.STRING, "invoice_pass_001", true),
                ParameterDefinition("currency", "Currency (ISO 4217, e.g. USD, EUR, XTR)", ParameterType.STRING, "USD", true),
                ParameterDefinition("prices", "Price in Smallest Units (e.g. 500 for $5.00)", ParameterType.INTEGER, "500", true)
            )
        ),
        BlockDefinition(
            typeId = "answer_pre_checkout_query",
            title = "Answer Pre-Checkout Query",
            category = BlockCategory.PAYMENTS,
            description = "Responds to confirm or deny payment readiness",
            parameters = listOf(
                ParameterDefinition("pre_checkout_query_id", "Query ID", ParameterType.STRING, "{pre_checkout_id}", true),
                ParameterDefinition("ok", "Approve Payment", ParameterType.BOOLEAN, "true", true),
                ParameterDefinition("error_message", "Error Message if not ok", ParameterType.STRING, "", false)
            )
        ),

        // Updates & Webhook
        BlockDefinition(
            typeId = "get_me",
            title = "Get Bot Info (getMe)",
            category = BlockCategory.UPDATES,
            description = "Fetches bot identity and verifies token validity",
            parameters = listOf()
        ),
        BlockDefinition(
            typeId = "set_webhook",
            title = "Set Webhook",
            category = BlockCategory.UPDATES,
            description = "Registers HTTPS endpoint for incoming updates",
            parameters = listOf(
                ParameterDefinition("url", "HTTPS Webhook URL", ParameterType.STRING, "https://example.com/bot", true),
                ParameterDefinition("max_connections", "Max Connections", ParameterType.INTEGER, "40", false),
                ParameterDefinition("secret_token", "Secret Token", ParameterType.STRING, "", false)
            )
        ),
        BlockDefinition(
            typeId = "delete_webhook",
            title = "Delete Webhook",
            category = BlockCategory.UPDATES,
            description = "Removes webhook integration to switch back to polling",
            parameters = listOf(
                ParameterDefinition("drop_pending_updates", "Drop Pending Updates", ParameterType.BOOLEAN, "false", false)
            )
        ),

        // Logic & Control Flow
        BlockDefinition(
            typeId = "if_condition",
            title = "If Condition",
            category = BlockCategory.LOGIC,
            description = "Executes branch if condition is met, else alternate branch",
            parameters = listOf(
                ParameterDefinition("left_operand", "Left Value / Variable", ParameterType.STRING, "{text}", true),
                ParameterDefinition("operator", "Operator", ParameterType.OPTION_LIST, "equals", true, listOf("equals", "not_equals", "contains", "starts_with", "ends_with", "greater_than", "less_than", "is_empty", "is_not_empty")),
                ParameterDefinition("right_operand", "Right Value / Comparison", ParameterType.STRING, "help", false)
            ),
            hasBranch = true
        ),
        BlockDefinition(
            typeId = "loop_times",
            title = "Repeat Loop",
            category = BlockCategory.LOGIC,
            description = "Repeats inner branch N times",
            parameters = listOf(
                ParameterDefinition("count", "Repeat Count", ParameterType.INTEGER, "3", true)
            ),
            hasBranch = true
        ),
        BlockDefinition(
            typeId = "set_variable",
            title = "Set Variable",
            category = BlockCategory.LOGIC,
            description = "Stores a key-value pair in memory",
            parameters = listOf(
                ParameterDefinition("var_name", "Variable Name", ParameterType.STRING, "user_state", true),
                ParameterDefinition("var_value", "Value", ParameterType.STRING, "active", true)
            )
        ),
        BlockDefinition(
            typeId = "string_operation",
            title = "String Operations",
            category = BlockCategory.LOGIC,
            description = "Transforms text (uppercase, lowercase, replace, trim, length)",
            parameters = listOf(
                ParameterDefinition("operation", "Operation", ParameterType.OPTION_LIST, "uppercase", true, listOf("uppercase", "lowercase", "trim", "replace", "length")),
                ParameterDefinition("input_text", "Input Text", ParameterType.STRING, "{text}", true),
                ParameterDefinition("search_pattern", "Search (for replace)", ParameterType.STRING, "", false),
                ParameterDefinition("replace_value", "Replacement (for replace)", ParameterType.STRING, "", false),
                ParameterDefinition("target_var", "Save Result To Variable", ParameterType.STRING, "formatted_result", true)
            )
        ),
        BlockDefinition(
            typeId = "json_parse",
            title = "JSON Value Extractor",
            category = BlockCategory.LOGIC,
            description = "Extracts a field from JSON string",
            parameters = listOf(
                ParameterDefinition("source_json", "Source JSON String", ParameterType.STRING, "{response_body}", true),
                ParameterDefinition("json_key", "Key to Extract", ParameterType.STRING, "status", true),
                ParameterDefinition("target_var", "Save Result To Variable", ParameterType.STRING, "extracted_val", true)
            )
        ),
        BlockDefinition(
            typeId = "http_request",
            title = "HTTP Network Request",
            category = BlockCategory.HTTP_WEB,
            description = "Performs external REST API call (GET/POST)",
            parameters = listOf(
                ParameterDefinition("method", "HTTP Method", ParameterType.OPTION_LIST, "GET", true, listOf("GET", "POST", "PUT", "DELETE")),
                ParameterDefinition("url", "Request URL", ParameterType.STRING, "https://api.weatherapi.com/v1/current.json", true),
                ParameterDefinition("body", "Request Body (JSON)", ParameterType.TEXT_MULTILINE, "", false),
                ParameterDefinition("target_var", "Save Response Body To", ParameterType.STRING, "response_body", true)
            )
        ),
        BlockDefinition(
            typeId = "delay_seconds",
            title = "Delay Execution",
            category = BlockCategory.LOGIC,
            description = "Pauses execution flow for specified seconds",
            parameters = listOf(
                ParameterDefinition("seconds", "Seconds to Wait", ParameterType.INTEGER, "2", true)
            )
        )
    )

    fun findDefinition(typeId: String): BlockDefinition? {
        return allDefinitions.find { it.typeId == typeId }
    }
}
