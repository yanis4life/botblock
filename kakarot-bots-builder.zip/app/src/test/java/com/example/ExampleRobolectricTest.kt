package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.botblocks.codegen.PythonCodeGenerator
import com.example.botblocks.codegen.PythonSyntaxValidator
import com.example.botblocks.data.DefaultProjects
import com.example.botblocks.data.ProjectRepository
import com.example.botblocks.data.ProjectSerializer
import com.example.botblocks.format.TelegramFormatter
import com.example.botblocks.ui.components.BotTutorialSteps
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun appNameStringMatchesKakarotBotsBuilder() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("KAKAROT BOTS BUILDER", appName)
    }

    @Test
    fun markdownV2EscapesAllSpecialCharactersCorrectly() {
        val raw = "Hello_World *bold* [link](url) ~strike~ `code` >quote #tag +1 -1 =2 |pipe| {var} .dot !excl"
        val escaped = TelegramFormatter.escapeMarkdownV2(raw)

        val specialChars = listOf('_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!')
        for (ch in specialChars) {
            assertTrue("Expected escaped character \\$ch in result: $escaped", escaped.contains("\\$ch"))
        }
    }

    @Test
    fun callbackDataLengthValidationEnforces64Bytes() {
        val validData = "short_callback_123"
        val (ok1, _) = TelegramFormatter.validateCallbackData(validData)
        assertTrue(ok1)

        val tooLongData = "a".repeat(65)
        val (ok2, msg2) = TelegramFormatter.validateCallbackData(tooLongData)
        assertFalse(ok2)
        assertTrue(msg2.contains("Exceeds 64 bytes limit"))
    }

    @Test
    fun projectSerializationPreservesAllBlocksAndKeyboards() {
        val starters = DefaultProjects.createStarterProjects()
        for (project in starters) {
            val json = ProjectSerializer.toJson(project)
            assertNotNull(json)
            assertTrue(json.isNotBlank())

            val restored = ProjectSerializer.fromJson(json)
            assertEquals(project.id, restored.id)
            assertEquals(project.name, restored.name)
            assertEquals(project.blocks.size, restored.blocks.size)

            for (i in project.blocks.indices) {
                val origB = project.blocks[i]
                val restB = restored.blocks[i]
                assertEquals(origB.id, restB.id)
                assertEquals(origB.typeId, restB.typeId)
                assertEquals(origB.parameters, restB.parameters)
                if (origB.inlineKeyboard != null) {
                    assertNotNull(restB.inlineKeyboard)
                    assertEquals(origB.inlineKeyboard?.rows?.size, restB.inlineKeyboard?.rows?.size)
                }
            }
        }
    }

    @Test
    fun generatedPythonCodeContainsNoCommentsAndPassesSyntaxValidation() {
        val starters = DefaultProjects.createStarterProjects()
        for (project in starters) {
            val code = PythonCodeGenerator.generate(project)

            // Generated Python must contain no comments per technical constraints
            val lines = code.lines()
            for (line in lines) {
                val trimmed = line.trim()
                assertFalse("Line should not be a comment: $line", trimmed.startsWith("#"))
            }

            // Verify AST / Tokenizer syntax validation
            val validation = PythonSyntaxValidator.validate(code)
            assertTrue("Python validation failed for ${project.name}: ${validation.errors}", validation.isValid)
            assertEquals(0, validation.errors.size)
        }
    }

    @Test
    fun versionControlAllowsCreatingAndRestoringSnapshots() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = ProjectRepository(context)

        val starter = DefaultProjects.createStarterProjects().first().copy(id = "test_vc_${System.currentTimeMillis()}")
        repo.saveProject(starter)

        // Create named snapshot v1.0
        val v1 = repo.createProjectVersion(
            projectId = starter.id,
            versionName = "v1.0 - Initial Test",
            description = "Test initial checkpoint",
            project = starter
        )

        val versions = repo.getProjectVersions(starter.id).first()
        assertTrue("Expected v1 in versions: $versions", versions.any { it.id == v1.id && it.versionName == "v1.0 - Initial Test" })

        // Mutate project by removing all blocks
        val mutated = starter.copy(blocks = emptyList())
        repo.saveProject(mutated)
        val loadedMutated = repo.getProjectById(starter.id)
        assertEquals(0, loadedMutated?.blocks?.size)

        // Restore version v1
        val restored = repo.restoreVersion(v1.id)
        assertNotNull(restored)
        assertEquals(starter.blocks.size, restored?.blocks?.size)
    }

    @Test
    fun tutorialStepsAreStructuredAndSequential() {
        assertEquals(5, BotTutorialSteps.size)
        for (i in BotTutorialSteps.indices) {
            assertEquals(i + 1, BotTutorialSteps[i].stepIndex)
            assertTrue(BotTutorialSteps[i].instruction.isNotBlank())
            assertTrue(BotTutorialSteps[i].tip.isNotBlank())
        }
    }
}
