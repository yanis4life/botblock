package com.example.botblocks.codegen

data class PythonSyntaxError(
    val lineNumber: Int,
    val column: Int,
    val message: String
)

data class PythonValidationResult(
    val isValid: Boolean,
    val errors: List<PythonSyntaxError>
)

object PythonSyntaxValidator {

    fun validate(pythonCode: String): PythonValidationResult {
        val errors = mutableListOf<PythonSyntaxError>()
        val lines = pythonCode.lines()

        val bracketStack = mutableListOf<Triple<Char, Int, Int>>() // char, line, col
        val indentStack = mutableListOf(0)

        var insideTripleDoubleQuote = false
        var insideTripleSingleQuote = false
        var lastStatementEndedWithColon = false

        for ((idx, rawLine) in lines.withIndex()) {
            val lineNum = idx + 1
            val trimmed = rawLine.trimEnd()

            if (trimmed.isBlank()) {
                continue
            }

            val leadingSpaces = rawLine.takeWhile { it == ' ' }.length
            if (rawLine.startsWith("\t")) {
                errors.add(PythonSyntaxError(lineNum, 1, "Tab indentation detected. PEP 8 requires 4 spaces."))
            }

            val isInImplicitContinuation = bracketStack.isNotEmpty() || insideTripleDoubleQuote || insideTripleSingleQuote

            if (!isInImplicitContinuation) {
                val currentIndent = indentStack.last()
                if (leadingSpaces > currentIndent) {
                    if (!lastStatementEndedWithColon) {
                        errors.add(PythonSyntaxError(lineNum, leadingSpaces, "Unexpected indentation. Previous line did not end with a colon."))
                    }
                    indentStack.add(leadingSpaces)
                } else if (leadingSpaces < currentIndent) {
                    while (indentStack.isNotEmpty() && indentStack.last() > leadingSpaces) {
                        indentStack.removeAt(indentStack.size - 1)
                    }
                    if (indentStack.isEmpty() || indentStack.last() != leadingSpaces) {
                        errors.add(PythonSyntaxError(lineNum, leadingSpaces, "Unindent does not match any outer indentation level."))
                    }
                }
            }

            // Parse characters for string literals and brackets
            var i = 0
            var inSingleQuote = false
            var inDoubleQuote = false

            while (i < trimmed.length) {
                val ch = trimmed[i]
                val next2 = if (i + 2 < trimmed.length) trimmed.substring(i, i + 3) else ""

                if (!inSingleQuote && !inDoubleQuote && next2 == "\"\"\"") {
                    insideTripleDoubleQuote = !insideTripleDoubleQuote
                    i += 3
                    continue
                }
                if (!inSingleQuote && !inDoubleQuote && next2 == "'''") {
                    insideTripleSingleQuote = !insideTripleSingleQuote
                    i += 3
                    continue
                }

                if (insideTripleDoubleQuote || insideTripleSingleQuote) {
                    i++
                    continue
                }

                if (ch == '\'' && !inDoubleQuote && (i == 0 || trimmed[i - 1] != '\\')) {
                    inSingleQuote = !inSingleQuote
                    i++
                    continue
                }
                if (ch == '"' && !inSingleQuote && (i == 0 || trimmed[i - 1] != '\\')) {
                    inDoubleQuote = !inDoubleQuote
                    i++
                    continue
                }

                if (inSingleQuote || inDoubleQuote) {
                    i++
                    continue
                }

                // Check bracket balance
                when (ch) {
                    '(', '[', '{' -> bracketStack.add(Triple(ch, lineNum, i + 1))
                    ')' -> {
                        if (bracketStack.isEmpty() || bracketStack.last().first != '(') {
                            errors.add(PythonSyntaxError(lineNum, i + 1, "Unmatched closing parenthesis ')'."))
                        } else {
                            bracketStack.removeAt(bracketStack.size - 1)
                        }
                    }
                    ']' -> {
                        if (bracketStack.isEmpty() || bracketStack.last().first != '[') {
                            errors.add(PythonSyntaxError(lineNum, i + 1, "Unmatched closing bracket ']'."))
                        } else {
                            bracketStack.removeAt(bracketStack.size - 1)
                        }
                    }
                    '}' -> {
                        if (bracketStack.isEmpty() || bracketStack.last().first != '{') {
                            errors.add(PythonSyntaxError(lineNum, i + 1, "Unmatched closing brace '}'."))
                        } else {
                            bracketStack.removeAt(bracketStack.size - 1)
                        }
                    }
                }

                i++
            }

            if ((inSingleQuote || inDoubleQuote) && !insideTripleDoubleQuote && !insideTripleSingleQuote) {
                errors.add(PythonSyntaxError(lineNum, trimmed.length, "EOL while scanning single-line string literal."))
            }

            val stripped = trimmed.trim()
            if (bracketStack.isEmpty() && !insideTripleDoubleQuote && !insideTripleSingleQuote) {
                lastStatementEndedWithColon = stripped.endsWith(":")
                if (stripped.startsWith("async def ") || stripped.startsWith("def ") ||
                    stripped.startsWith("if ") || stripped.startsWith("elif ") ||
                    stripped == "else:" || stripped.startsWith("for ") || stripped.startsWith("while ")
                ) {
                    if (!stripped.endsWith(":")) {
                        errors.add(PythonSyntaxError(lineNum, trimmed.length, "SyntaxError: expected ':' at end of compound statement"))
                    }
                }
            } else {
                lastStatementEndedWithColon = false
            }
        }

        if (insideTripleDoubleQuote || insideTripleSingleQuote) {
            errors.add(PythonSyntaxError(lines.size, 1, "EOF while scanning multi-line string literal."))
        }

        while (bracketStack.isNotEmpty()) {
            val unclosed = bracketStack.removeAt(bracketStack.size - 1)
            errors.add(PythonSyntaxError(unclosed.second, unclosed.third, "Unclosed '${unclosed.first}' opened at line ${unclosed.second}:${unclosed.third}."))
        }

        return PythonValidationResult(
            isValid = errors.isEmpty(),
            errors = errors
        )
    }
}
