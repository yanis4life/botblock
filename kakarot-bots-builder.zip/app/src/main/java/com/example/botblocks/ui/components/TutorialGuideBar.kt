package com.example.botblocks.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentSuccess
import com.example.ui.theme.CategoryEvents

data class TutorialStep(
    val stepIndex: Int,
    val title: String,
    val instruction: String,
    val tip: String
)

val BotTutorialSteps = listOf(
    TutorialStep(
        stepIndex = 1,
        title = "Add Event Block",
        instruction = "Tap the Palette button (+) and add the 'On /start Command' block.",
        tip = "Event blocks have the golden curved top and trigger when users message your bot."
    ),
    TutorialStep(
        stepIndex = 2,
        title = "Attach Send Message Action",
        instruction = "Add a 'Send Message' block from Messages and connect it to /start.",
        tip = "Action blocks execute Telegram Bot API calls using the {chat_id} of the sender."
    ),
    TutorialStep(
        stepIndex = 3,
        title = "Compose Rich Formatted Text",
        instruction = "Tap the Send Message block, open Message Composer, and add styled text.",
        tip = "KAKAROT BOTS BUILDER handles MarkdownV2 special character escaping automatically."
    ),
    TutorialStep(
        stepIndex = 4,
        title = "Add Interactive Buttons",
        instruction = "Open Keyboard Builder on Send Message to add an Inline Button.",
        tip = "You can choose button styles like Primary, Success, or Danger (Bot API 9.0)."
    ),
    TutorialStep(
        stepIndex = 5,
        title = "Run & Export Bot",
        instruction = "Enter your bot token in settings, hit Run, or tap Export to generate Python.",
        tip = "The exported script uses async python-telegram-bot v20+ with zero comments."
    )
)

@Composable
fun TutorialGuideBar(
    currentStepIndex: Int,
    onNextStep: () -> Unit,
    onPrevStep: () -> Unit,
    onAutoCompleteStep: () -> Unit,
    onExitTutorial: () -> Unit,
    modifier: Modifier = Modifier
) {
    val step = BotTutorialSteps.getOrElse(currentStepIndex - 1) { BotTutorialSteps.first() }
    val isLastStep = currentStepIndex >= BotTutorialSteps.size

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .border(1.dp, CategoryEvents, RoundedCornerShape(8.dp))
            .testTag("tutorial_guide_bar"),
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = CategoryEvents,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "TUTORIAL: STEP $currentStepIndex OF ${BotTutorialSteps.size}",
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = androidx.compose.ui.graphics.Color.White
                            )
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = step.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = onExitTutorial,
                    modifier = Modifier.size(24.dp).testTag("exit_tutorial_button")
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Exit Tutorial", modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = step.instruction,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = step.tip,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onAutoCompleteStep,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("tutorial_auto_complete_button")
                ) {
                    Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Auto-Build Step", fontSize = 11.sp)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (currentStepIndex > 1) {
                        TextButton(
                            onClick = onPrevStep,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Back", fontSize = 11.sp)
                        }
                    }

                    Button(
                        onClick = {
                            if (isLastStep) {
                                onExitTutorial()
                            } else {
                                onNextStep()
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("tutorial_next_button")
                    ) {
                        Text(if (isLastStep) "Finish Tutorial" else "Next Step", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
