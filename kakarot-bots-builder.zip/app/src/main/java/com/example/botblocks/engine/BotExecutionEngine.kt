package com.example.botblocks.engine

import com.example.botblocks.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class BotExecutionEngine {

    private val apiClient = TelegramApiClient()
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private var executionJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _botUsername = MutableStateFlow<String?>(null)
    val botUsername: StateFlow<String?> = _botUsername.asStateFlow()

    private val _activeBlockId = MutableStateFlow<String?>(null)
    val activeBlockId: StateFlow<String?> = _activeBlockId.asStateFlow()

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    fun addLog(entry: LogEntry) {
        val updated = _logs.value.toMutableList()
        updated.add(0, entry)
        if (updated.size > 250) {
            _logs.value = updated.subList(0, 250)
        } else {
            _logs.value = updated
        }
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    fun startBot(project: Project) {
        if (_isRunning.value) {
            stopBot()
        }

        if (project.botToken.isBlank()) {
            addLog(
                LogEntry(
                    level = LogLevel.ERROR,
                    message = "Bot token is not configured. Please enter your Telegram bot token in settings."
                )
            )
            return
        }

        _isRunning.value = true
        addLog(
            LogEntry(
                level = LogLevel.INFO,
                message = "Starting bot: ${project.name} (mode: ${project.executionMode.name})"
            )
        )

        executionJob = scope.launch {
            val meResult = apiClient.getMe(project.botToken)
            if (meResult.isFailure) {
                val err = meResult.exceptionOrNull()?.message ?: "Unknown error"
                addLog(
                    LogEntry(
                        level = LogLevel.ERROR,
                        message = "Failed to authenticate bot token: $err"
                    )
                )
                _isRunning.value = false
                return@launch
            }

            val userObj = meResult.getOrNull()?.optJSONObject("result")
            val username = userObj?.optString("username", "bot") ?: "bot"
            val firstName = userObj?.optString("first_name", "Bot") ?: "Bot"
            _botUsername.value = "@$username"

            addLog(
                LogEntry(
                    level = LogLevel.SUCCESS,
                    message = "Authenticated successfully as @$username ($firstName). Waiting for updates..."
                )
            )

            if (project.executionMode == ExecutionMode.WEBHOOK) {
                addLog(
                    LogEntry(
                        level = LogLevel.INFO,
                        message = "Webhook mode active. Webhook URL: ${project.webhookUrl}"
                    )
                )
                if (project.webhookUrl.isNotBlank()) {
                    val whRes = apiClient.setWebhook(project.botToken, project.webhookUrl)
                    if (whRes.isSuccess) {
                        addLog(LogEntry(level = LogLevel.SUCCESS, message = "Webhook registered on Telegram API"))
                    } else {
                        addLog(LogEntry(level = LogLevel.ERROR, message = "Failed to register webhook: ${whRes.exceptionOrNull()?.message}"))
                    }
                }
                return@launch
            }

            // Long polling mode
            var lastUpdateId: Long? = null

            // Clean pending webhook to ensure long polling works
            apiClient.deleteWebhook(project.botToken)

            while (isActive && _isRunning.value) {
                try {
                    val result = apiClient.getUpdates(
                        token = project.botToken,
                        offset = if (lastUpdateId != null) lastUpdateId + 1 else null,
                        timeout = 20
                    )

                    if (result.isSuccess) {
                        val json = result.getOrNull()
                        val updatesArray = json?.optJSONArray("result")
                        if (updatesArray != null && updatesArray.length() > 0) {
                            for (i in 0 until updatesArray.length()) {
                                val update = updatesArray.getJSONObject(i)
                                val updateId = update.getLong("update_id")
                                lastUpdateId = updateId

                                processUpdate(project, update)
                            }
                        }
                    } else {
                        val err = result.exceptionOrNull()?.message ?: "Error getting updates"
                        addLog(LogEntry(level = LogLevel.ERROR, message = "Update polling issue: $err"))
                        delay(3000)
                    }
                } catch (ce: CancellationException) {
                    break
                } catch (e: Exception) {
                    addLog(LogEntry(level = LogLevel.ERROR, message = "Polling error: ${e.message}"))
                    delay(3000)
                }
            }
        }
    }

    fun stopBot() {
        executionJob?.cancel()
        executionJob = null
        _isRunning.value = false
        _activeBlockId.value = null
        _botUsername.value = null
        addLog(LogEntry(level = LogLevel.INFO, message = "Bot stopped."))
    }

    private suspend fun processUpdate(project: Project, update: JSONObject) {
        val contextVars = mutableMapOf<String, String>()
        contextVars.putAll(project.variables)

        if (update.has("message")) {
            val msg = update.getJSONObject("message")
            val chatId = msg.getJSONObject("chat").getLong("id").toString()
            val messageId = msg.getLong("message_id").toString()
            val text = msg.optString("text", "")
            val fromUser = msg.optJSONObject("from")
            val userId = fromUser?.optLong("id", 0)?.toString() ?: ""
            val userName = fromUser?.optString("username", fromUser.optString("first_name", "User")) ?: "User"

            contextVars["chat_id"] = chatId
            contextVars["message_id"] = messageId
            contextVars["text"] = text
            contextVars["user_id"] = userId
            contextVars["user_name"] = userName

            addLog(
                LogEntry(
                    level = LogLevel.INFO,
                    message = "Incoming message from @$userName in chat $chatId: \"$text\""
                )
            )

            // Match on_message blocks
            val eventBlocks = project.blocks.filter { it.typeId == "on_message" }
            for (eb in eventBlocks) {
                val fType = eb.parameters["filter_type"] ?: "Any"
                val fVal = eb.parameters["filter_value"]?.trim().orEmpty()

                var matches = false
                when (fType) {
                    "Any" -> matches = true
                    "Command" -> {
                        matches = text.trim() == fVal || text.startsWith("$fVal ") || text.startsWith("$fVal@")
                    }
                    "Text Matches" -> matches = text.trim().equals(fVal, ignoreCase = true)
                    "Contains Text" -> matches = text.contains(fVal, ignoreCase = true)
                    "Photo" -> matches = msg.has("photo")
                    "Document" -> matches = msg.has("document")
                    else -> matches = true
                }

                if (matches) {
                    executeBlockChain(project, eb.nextBlockId, contextVars)
                }
            }
        } else if (update.has("callback_query")) {
            val cb = update.getJSONObject("callback_query")
            val cbId = cb.getString("id")
            val data = cb.optString("data", "")
            val fromUser = cb.getJSONObject("from")
            val userId = fromUser.getLong("id").toString()
            val userName = fromUser.optString("username", fromUser.optString("first_name", "User"))

            val msg = cb.optJSONObject("message")
            val chatId = msg?.getJSONObject("chat")?.optLong("id", 0)?.toString() ?: ""
            val messageId = msg?.optLong("message_id", 0)?.toString() ?: ""

            contextVars["callback_query_id"] = cbId
            contextVars["callback_data"] = data
            contextVars["user_id"] = userId
            contextVars["user_name"] = userName
            contextVars["chat_id"] = chatId
            contextVars["message_id"] = messageId

            addLog(
                LogEntry(
                    level = LogLevel.INFO,
                    message = "Button callback: \"$data\" from @$userName"
                )
            )

            val eventBlocks = project.blocks.filter { it.typeId == "on_callback_query" }
            for (eb in eventBlocks) {
                val fType = eb.parameters["filter_type"] ?: "Any"
                val pattern = eb.parameters["data_pattern"]?.trim().orEmpty()

                val matches = when (fType) {
                    "Any" -> true
                    "Exact Match" -> data == pattern
                    "Starts With" -> data.startsWith(pattern)
                    else -> true
                }

                if (matches) {
                    executeBlockChain(project, eb.nextBlockId, contextVars)
                }
            }
        } else if (update.has("inline_query")) {
            val iq = update.getJSONObject("inline_query")
            val qId = iq.getString("id")
            val queryText = iq.optString("query", "")
            contextVars["query_id"] = qId
            contextVars["query_text"] = queryText

            val eventBlocks = project.blocks.filter { it.typeId == "on_inline_query" }
            for (eb in eventBlocks) {
                executeBlockChain(project, eb.nextBlockId, contextVars)
            }
        } else if (update.has("channel_post")) {
            val cp = update.getJSONObject("channel_post")
            val chatId = cp.getJSONObject("chat").getLong("id").toString()
            val messageId = cp.getLong("message_id").toString()
            val text = cp.optString("text", "")
            contextVars["chat_id"] = chatId
            contextVars["message_id"] = messageId
            contextVars["text"] = text

            val eventBlocks = project.blocks.filter { it.typeId == "on_channel_post" }
            for (eb in eventBlocks) {
                executeBlockChain(project, eb.nextBlockId, contextVars)
            }
        }
    }

    private suspend fun executeBlockChain(
        project: Project,
        startBlockId: String?,
        contextVars: MutableMap<String, String>
    ) {
        var currentId = startBlockId
        var loopGuard = 0

        while (currentId != null && loopGuard < 100) {
            loopGuard++
            val block = project.blocks.find { it.id == currentId } ?: break
            _activeBlockId.value = block.id

            val result = executeSingleBlock(project, block, contextVars)
            if (result.isFailure) {
                addLog(
                    LogEntry(
                        level = LogLevel.ERROR,
                        blockId = block.id,
                        blockTitle = block.title,
                        message = "Execution halted at block [${block.title}]: ${result.exceptionOrNull()?.message}"
                    )
                )
                break
            }

            currentId = when {
                block.hasBranch() -> {
                    val branchChosen = result.getOrNull() as? String
                    branchChosen ?: block.nextBlockId
                }
                else -> block.nextBlockId
            }
        }
        _activeBlockId.value = null
    }

    private fun BlockNode.hasBranch(): Boolean = typeId == "if_condition" || typeId == "loop_times"

    private suspend fun executeSingleBlock(
        project: Project,
        block: BlockNode,
        contextVars: MutableMap<String, String>
    ): Result<Any?> {
        val def = TelegramCatalog.findDefinition(block.typeId)

        fun replaceVars(value: String): String {
            var res = value
            for ((k, v) in contextVars) {
                res = res.replace("{$k}", v)
            }
            return res
        }

        return try {
            when (block.typeId) {
                "send_message" -> {
                    val chatId = replaceVars(block.parameters["chat_id"] ?: "{chat_id}")
                    val text = replaceVars(block.parameters["text"] ?: "")
                    val parseMode = block.parameters["parse_mode"] ?: "MarkdownV2"
                    val disableNotification = block.parameters["disable_notification"]?.toBoolean() ?: false
                    val protectContent = block.parameters["protect_content"]?.toBoolean() ?: false

                    val params = mutableMapOf<String, Any?>(
                        "chat_id" to chatId,
                        "text" to text,
                        "disable_notification" to disableNotification,
                        "protect_content" to protectContent
                    )
                    if (parseMode.isNotBlank() && parseMode != "Plain Text") {
                        params["parse_mode"] = parseMode
                    }

                    block.inlineKeyboard?.let {
                        if (it.rows.isNotEmpty()) params["reply_markup"] = TelegramApiClient.buildInlineKeyboardJson(it)
                    }
                    block.replyKeyboard?.let {
                        if (it.rows.isNotEmpty()) params["reply_markup"] = TelegramApiClient.buildReplyKeyboardJson(it)
                    }
                    block.removeKeyboard?.let {
                        params["reply_markup"] = TelegramApiClient.buildRemoveKeyboardJson(it)
                    }

                    addLog(
                        LogEntry(
                            level = LogLevel.API_CALL,
                            blockId = block.id,
                            blockTitle = block.title,
                            method = "sendMessage",
                            message = "Calling sendMessage to chat $chatId",
                            details = text
                        )
                    )

                    val res = apiClient.callMethod(project.botToken, "sendMessage", params)
                    if (res.isSuccess) {
                        addLog(LogEntry(level = LogLevel.SUCCESS, blockId = block.id, blockTitle = block.title, message = "Message sent successfully"))
                        Result.success(res.getOrNull())
                    } else {
                        Result.failure(res.exceptionOrNull() ?: Exception("sendMessage failed"))
                    }
                }

                "send_photo" -> {
                    val chatId = replaceVars(block.parameters["chat_id"] ?: "{chat_id}")
                    val photo = replaceVars(block.parameters["photo"] ?: "")
                    val caption = replaceVars(block.parameters["caption"] ?: "")
                    val parseMode = block.parameters["parse_mode"] ?: ""

                    val params = mutableMapOf<String, Any?>(
                        "chat_id" to chatId,
                        "photo" to photo,
                        "caption" to caption
                    )
                    if (parseMode.isNotBlank()) params["parse_mode"] = parseMode

                    block.inlineKeyboard?.let {
                        if (it.rows.isNotEmpty()) params["reply_markup"] = TelegramApiClient.buildInlineKeyboardJson(it)
                    }

                    addLog(LogEntry(level = LogLevel.API_CALL, blockId = block.id, blockTitle = block.title, method = "sendPhoto", message = "Sending photo to $chatId"))
                    val res = apiClient.callMethod(project.botToken, "sendPhoto", params)
                    if (res.isSuccess) Result.success(res.getOrNull()) else Result.failure(res.exceptionOrNull() ?: Exception("sendPhoto failed"))
                }

                "send_document" -> {
                    val chatId = replaceVars(block.parameters["chat_id"] ?: "{chat_id}")
                    val doc = replaceVars(block.parameters["document"] ?: "")
                    val caption = replaceVars(block.parameters["caption"] ?: "")
                    val params = mapOf("chat_id" to chatId, "document" to doc, "caption" to caption)
                    apiClient.callMethod(project.botToken, "sendDocument", params)
                }

                "send_poll" -> {
                    val chatId = replaceVars(block.parameters["chat_id"] ?: "{chat_id}")
                    val question = replaceVars(block.parameters["question"] ?: "")
                    val optionsRaw = replaceVars(block.parameters["options"] ?: "")
                    val options = optionsRaw.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    val isAnonymous = block.parameters["is_anonymous"]?.toBoolean() ?: true
                    val type = block.parameters["type"] ?: "regular"

                    val params = mutableMapOf<String, Any?>(
                        "chat_id" to chatId,
                        "question" to question,
                        "options" to JSONArray(options),
                        "is_anonymous" to isAnonymous,
                        "type" to type
                    )
                    if (type == "quiz") {
                        params["correct_option_id"] = block.parameters["correct_option_id"]?.toIntOrNull() ?: 0
                        val exp = block.parameters["explanation"] ?: ""
                        if (exp.isNotBlank()) params["explanation"] = exp
                    }

                    addLog(LogEntry(level = LogLevel.API_CALL, blockId = block.id, blockTitle = block.title, method = "sendPoll", message = "Dispatching poll to $chatId"))
                    apiClient.callMethod(project.botToken, "sendPoll", params)
                }

                "send_dice" -> {
                    val chatId = replaceVars(block.parameters["chat_id"] ?: "{chat_id}")
                    val emoji = block.parameters["emoji"] ?: "dice"
                    val telegramEmoji = when (emoji) {
                        "dart" -> "\uD83C\uDFAF"
                        "basketball" -> "\uD83C\uDFC0"
                        "football" -> "\u26BD"
                        "slot_machine" -> "\uD83C\uDFB0"
                        "bowling" -> "\uD83C\uDFB3"
                        else -> "\uD83C\uDFB2"
                    }
                    val params = mapOf("chat_id" to chatId, "emoji" to telegramEmoji)
                    apiClient.callMethod(project.botToken, "sendDice", params)
                }

                "edit_message_text" -> {
                    val chatId = replaceVars(block.parameters["chat_id"] ?: "{chat_id}")
                    val messageId = replaceVars(block.parameters["message_id"] ?: "{message_id}").toLongOrNull() ?: 0L
                    val text = replaceVars(block.parameters["text"] ?: "")
                    val parseMode = block.parameters["parse_mode"] ?: "MarkdownV2"
                    val params = mutableMapOf<String, Any?>(
                        "chat_id" to chatId,
                        "message_id" to messageId,
                        "text" to text
                    )
                    if (parseMode.isNotBlank() && parseMode != "Plain Text") params["parse_mode"] = parseMode
                    block.inlineKeyboard?.let {
                        if (it.rows.isNotEmpty()) params["reply_markup"] = TelegramApiClient.buildInlineKeyboardJson(it)
                    }

                    addLog(LogEntry(level = LogLevel.API_CALL, blockId = block.id, blockTitle = block.title, method = "editMessageText", message = "Editing message $messageId in $chatId"))
                    apiClient.callMethod(project.botToken, "editMessageText", params)
                }

                "answer_callback_query" -> {
                    val cbId = replaceVars(block.parameters["callback_query_id"] ?: "{callback_query_id}")
                    val text = replaceVars(block.parameters["text"] ?: "")
                    val showAlert = block.parameters["show_alert"]?.toBoolean() ?: false
                    val params = mapOf("callback_query_id" to cbId, "text" to text, "show_alert" to showAlert)
                    addLog(LogEntry(level = LogLevel.API_CALL, blockId = block.id, blockTitle = block.title, method = "answerCallbackQuery", message = "Acknowledging callback $cbId"))
                    apiClient.callMethod(project.botToken, "answerCallbackQuery", params)
                }

                "delete_message" -> {
                    val chatId = replaceVars(block.parameters["chat_id"] ?: "{chat_id}")
                    val messageId = replaceVars(block.parameters["message_id"] ?: "{message_id}").toLongOrNull() ?: 0L
                    val params = mapOf("chat_id" to chatId, "message_id" to messageId)
                    addLog(LogEntry(level = LogLevel.API_CALL, blockId = block.id, blockTitle = block.title, method = "deleteMessage", message = "Deleting message $messageId in $chatId"))
                    apiClient.callMethod(project.botToken, "deleteMessage", params)
                }

                "ban_chat_member" -> {
                    val chatId = replaceVars(block.parameters["chat_id"] ?: "{chat_id}")
                    val userId = replaceVars(block.parameters["user_id"] ?: "{user_id}").toLongOrNull() ?: 0L
                    val revoke = block.parameters["revoke_messages"]?.toBoolean() ?: true
                    val params = mapOf("chat_id" to chatId, "user_id" to userId, "revoke_messages" to revoke)
                    apiClient.callMethod(project.botToken, "banChatMember", params)
                }

                "pin_chat_message" -> {
                    val chatId = replaceVars(block.parameters["chat_id"] ?: "{chat_id}")
                    val messageId = replaceVars(block.parameters["message_id"] ?: "{message_id}").toLongOrNull() ?: 0L
                    val params = mapOf("chat_id" to chatId, "message_id" to messageId)
                    apiClient.callMethod(project.botToken, "pinChatMessage", params)
                }

                "set_variable" -> {
                    val varName = block.parameters["var_name"] ?: "temp"
                    val varValue = replaceVars(block.parameters["var_value"] ?: "")
                    contextVars[varName] = varValue
                    addLog(LogEntry(level = LogLevel.INFO, blockId = block.id, blockTitle = block.title, message = "Set variable {$varName} = \"$varValue\""))
                    Result.success(varValue)
                }

                "string_operation" -> {
                    val op = block.parameters["operation"] ?: "uppercase"
                    val input = replaceVars(block.parameters["input_text"] ?: "")
                    val targetVar = block.parameters["target_var"] ?: "result"
                    val search = replaceVars(block.parameters["search_pattern"] ?: "")
                    val rep = replaceVars(block.parameters["replace_value"] ?: "")

                    val resStr = when (op) {
                        "uppercase" -> input.uppercase()
                        "lowercase" -> input.lowercase()
                        "trim" -> input.trim()
                        "replace" -> input.replace(search, rep)
                        "length" -> input.length.toString()
                        else -> input
                    }
                    contextVars[targetVar] = resStr
                    addLog(LogEntry(level = LogLevel.INFO, blockId = block.id, blockTitle = block.title, message = "String op ($op) saved to {$targetVar} = \"$resStr\""))
                    Result.success(resStr)
                }

                "json_parse" -> {
                    val src = replaceVars(block.parameters["source_json"] ?: "{}")
                    val key = block.parameters["json_key"] ?: ""
                    val targetVar = block.parameters["target_var"] ?: "val"
                    val extracted = try {
                        val jo = JSONObject(src)
                        jo.optString(key, "")
                    } catch (e: Exception) {
                        ""
                    }
                    contextVars[targetVar] = extracted
                    addLog(LogEntry(level = LogLevel.INFO, blockId = block.id, blockTitle = block.title, message = "Extracted key $key -> {$targetVar} = \"$extracted\""))
                    Result.success(extracted)
                }

                "http_request" -> {
                    val method = block.parameters["method"] ?: "GET"
                    val url = replaceVars(block.parameters["url"] ?: "")
                    val bodyStr = replaceVars(block.parameters["body"] ?: "")
                    val targetVar = block.parameters["target_var"] ?: "response_body"

                    val reqBuilder = Request.Builder().url(url)
                    if (method == "POST") {
                        val reqBody = bodyStr.toRequestBody("application/json".toMediaType())
                        reqBuilder.post(reqBody)
                    }

                    addLog(LogEntry(level = LogLevel.API_CALL, blockId = block.id, blockTitle = block.title, message = "HTTP $method $url"))
                    val resp = httpClient.newCall(reqBuilder.build()).execute()
                    val respStr = resp.body?.string().orEmpty()
                    contextVars[targetVar] = respStr
                    addLog(LogEntry(level = LogLevel.SUCCESS, blockId = block.id, blockTitle = block.title, message = "HTTP ${resp.code} response saved to {$targetVar}"))
                    Result.success(respStr)
                }

                "delay_seconds" -> {
                    val secs = block.parameters["seconds"]?.toLongOrNull() ?: 1L
                    addLog(LogEntry(level = LogLevel.INFO, blockId = block.id, blockTitle = block.title, message = "Pausing execution for $secs seconds"))
                    delay(secs * 1000)
                    Result.success(null)
                }

                "if_condition" -> {
                    val left = replaceVars(block.parameters["left_operand"] ?: "")
                    val op = block.parameters["operator"] ?: "equals"
                    val right = replaceVars(block.parameters["right_operand"] ?: "")

                    val conditionMet = when (op) {
                        "equals" -> left.equals(right, ignoreCase = true)
                        "not_equals" -> !left.equals(right, ignoreCase = true)
                        "contains" -> left.contains(right, ignoreCase = true)
                        "starts_with" -> left.startsWith(right, ignoreCase = true)
                        "ends_with" -> left.endsWith(right, ignoreCase = true)
                        "is_empty" -> left.isBlank()
                        "is_not_empty" -> left.isNotBlank()
                        "greater_than" -> (left.toDoubleOrNull() ?: 0.0) > (right.toDoubleOrNull() ?: 0.0)
                        "less_than" -> (left.toDoubleOrNull() ?: 0.0) < (right.toDoubleOrNull() ?: 0.0)
                        else -> false
                    }

                    addLog(LogEntry(level = LogLevel.INFO, blockId = block.id, blockTitle = block.title, message = "Condition evaluated: \"$left\" $op \"$right\" -> $conditionMet"))
                    val nextTarget = if (conditionMet) block.branchBlockId else block.elseBlockId
                    Result.success(nextTarget)
                }

                "loop_times" -> {
                    val count = block.parameters["count"]?.toIntOrNull() ?: 1
                    addLog(LogEntry(level = LogLevel.INFO, blockId = block.id, blockTitle = block.title, message = "Loop starting for $count iterations"))
                    for (i in 1..count) {
                        contextVars["loop_index"] = i.toString()
                        block.branchBlockId?.let { branchStart ->
                            executeBlockChain(project, branchStart, contextVars)
                        }
                    }
                    Result.success(block.nextBlockId)
                }

                else -> {
                    // Generic fallback for any other Telegram API method
                    val methodName = block.typeId.replace("_", "")
                    val params = mutableMapOf<String, Any?>()
                    for ((k, v) in block.parameters) {
                        params[k] = replaceVars(v)
                    }
                    addLog(LogEntry(level = LogLevel.API_CALL, blockId = block.id, blockTitle = block.title, method = methodName, message = "Calling $methodName"))
                    apiClient.callMethod(project.botToken, methodName, params)
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
