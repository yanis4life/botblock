package com.example.botblocks.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.botblocks.data.DefaultProjects
import com.example.botblocks.data.ProjectRepository
import com.example.botblocks.data.ProjectSerializer
import com.example.botblocks.engine.BotExecutionEngine
import com.example.botblocks.model.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class BotBlocksViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ProjectRepository(application)
    val executionEngine = BotExecutionEngine()

    val allProjects: StateFlow<List<Project>> = repository.getAllProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentProject = MutableStateFlow<Project>(DefaultProjects.createStarterProjects().first())
    val currentProject: StateFlow<Project> = _currentProject.asStateFlow()

    private val _selectedBlockId = MutableStateFlow<String?>(null)
    val selectedBlockId: StateFlow<String?> = _selectedBlockId.asStateFlow()

    // Version control flow for active project
    val projectVersions: StateFlow<List<ProjectVersion>> = _currentProject
        .flatMapLatest { p -> repository.getProjectVersions(p.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Tutorial state
    private val _isTutorialActive = MutableStateFlow(false)
    val isTutorialActive: StateFlow<Boolean> = _isTutorialActive.asStateFlow()

    private val _currentTutorialStep = MutableStateFlow(1)
    val currentTutorialStep: StateFlow<Int> = _currentTutorialStep.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeDefaultsIfNeeded()
            val initial = repository.getAllProjects().first()
            if (initial.isNotEmpty()) {
                _currentProject.value = initial.first()
            }
        }
    }

    fun selectBlock(id: String?) {
        _selectedBlockId.value = id
    }

    fun addBlock(definition: BlockDefinition) {
        val current = _currentProject.value
        val defaultParams = definition.parameters.associate { it.key to it.defaultValue }

        val lastBlock = current.blocks.lastOrNull()
        val newX = (lastBlock?.posX ?: 80f) + 30f
        val newY = (lastBlock?.posY ?: 80f) + 70f

        val newBlock = BlockNode(
            id = UUID.randomUUID().toString(),
            typeId = definition.typeId,
            title = definition.title,
            category = definition.category,
            parameters = defaultParams,
            posX = newX.coerceAtMost(800f),
            posY = newY.coerceAtMost(1200f)
        )

        val updated = current.copy(blocks = current.blocks + newBlock)
        _currentProject.value = updated
        _selectedBlockId.value = newBlock.id
        saveProjectInternal(updated)
    }

    fun updateBlock(updatedBlock: BlockNode) {
        val current = _currentProject.value
        val updatedBlocks = current.blocks.map { if (it.id == updatedBlock.id) updatedBlock else it }
        val updated = current.copy(blocks = updatedBlocks)
        _currentProject.value = updated
        saveProjectInternal(updated)
    }

    fun moveBlock(id: String, dx: Float, dy: Float) {
        val current = _currentProject.value
        val updatedBlocks = current.blocks.map {
            if (it.id == id) it.copy(posX = (it.posX + dx).coerceAtLeast(0f), posY = (it.posY + dy).coerceAtLeast(0f)) else it
        }
        val updated = current.copy(blocks = updatedBlocks)
        _currentProject.value = updated
        saveProjectInternal(updated)
    }

    fun deleteBlock(id: String) {
        val current = _currentProject.value
        val updatedBlocks = current.blocks
            .filter { it.id != id }
            .map { b ->
                var modified = b
                if (b.nextBlockId == id) modified = modified.copy(nextBlockId = null)
                if (b.branchBlockId == id) modified = modified.copy(branchBlockId = null)
                if (b.elseBlockId == id) modified = modified.copy(elseBlockId = null)
                modified
            }

        val updated = current.copy(blocks = updatedBlocks)
        _currentProject.value = updated
        if (_selectedBlockId.value == id) {
            _selectedBlockId.value = null
        }
        saveProjectInternal(updated)
    }

    fun duplicateBlock(block: BlockNode) {
        val current = _currentProject.value
        val cloned = block.copy(
            id = UUID.randomUUID().toString(),
            title = "${block.title} (Copy)",
            posX = block.posX + 40f,
            posY = block.posY + 40f,
            nextBlockId = null,
            branchBlockId = null,
            elseBlockId = null
        )
        val updated = current.copy(blocks = current.blocks + cloned)
        _currentProject.value = updated
        _selectedBlockId.value = cloned.id
        saveProjectInternal(updated)
    }

    fun snapAllConnectedBlocks() {
        val current = _currentProject.value
        val blockMap = current.blocks.associateBy { it.id }.toMutableMap()
        val nonRoots = current.blocks.flatMap { listOfNotNull(it.nextBlockId, it.branchBlockId, it.elseBlockId) }.toSet()
        val roots = current.blocks.filter { it.id !in nonRoots }

        var currentRootX = 60f
        val visited = mutableSetOf<String>()

        fun layoutChain(blockId: String, currentX: Float, currentY: Float) {
            if (blockId in visited) return
            visited.add(blockId)
            val node = blockMap[blockId] ?: return
            blockMap[blockId] = node.copy(posX = currentX, posY = currentY)

            var nextY = currentY + 128f
            node.branchBlockId?.let { bId ->
                layoutChain(bId, currentX + 24f, nextY)
                nextY += 130f
            }
            node.elseBlockId?.let { eId ->
                layoutChain(eId, currentX + 24f, nextY)
                nextY += 130f
            }
            node.nextBlockId?.let { nId ->
                layoutChain(nId, currentX, nextY)
            }
        }

        for (root in roots) {
            layoutChain(root.id, currentRootX, 80f)
            currentRootX += 300f
        }

        val updated = current.copy(blocks = blockMap.values.toList())
        _currentProject.value = updated
        saveProjectInternal(updated)
    }

    fun selectProject(project: Project) {
        if (executionEngine.isRunning.value) {
            executionEngine.stopBot()
        }
        _currentProject.value = project
        _selectedBlockId.value = null
    }

    fun createProject(name: String) {
        val newProj = Project(
            id = UUID.randomUUID().toString(),
            name = name,
            blocks = emptyList()
        )
        viewModelScope.launch {
            repository.saveProject(newProj)
            _currentProject.value = newProj
            _selectedBlockId.value = null
        }
    }

    fun duplicateProject(project: Project) {
        viewModelScope.launch {
            val dup = repository.duplicateProject(project)
            _currentProject.value = dup
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            val remaining = repository.getAllProjects().first().filter { it.id != projectId }
            if (remaining.isNotEmpty()) {
                _currentProject.value = remaining.first()
            } else {
                val newOne = DefaultProjects.createStarterProjects().first()
                repository.saveProject(newOne)
                _currentProject.value = newOne
            }
        }
    }

    fun updateProjectDetails(project: Project) {
        _currentProject.value = project
        saveProjectInternal(project)
    }

    fun importProjectJson(jsonStr: String): Boolean {
        return try {
            val proj = ProjectSerializer.fromJson(jsonStr)
            viewModelScope.launch {
                repository.saveProject(proj)
                _currentProject.value = proj
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun toggleBot() {
        if (executionEngine.isRunning.value) {
            executionEngine.stopBot()
        } else {
            executionEngine.startBot(_currentProject.value)
        }
    }

    // Version Control Actions
    fun createVersion(name: String, description: String) {
        val current = _currentProject.value
        viewModelScope.launch {
            repository.createProjectVersion(current.id, name, description, current)
        }
    }

    fun restoreVersion(versionId: String) {
        viewModelScope.launch {
            val restored = repository.restoreVersion(versionId)
            if (restored != null) {
                _currentProject.value = restored
                _selectedBlockId.value = null
            }
        }
    }

    fun deleteVersion(versionId: String) {
        viewModelScope.launch {
            repository.deleteVersion(versionId)
        }
    }

    fun forkVersionAsProject(version: ProjectVersion) {
        viewModelScope.launch {
            val projectFromSnapshot = ProjectSerializer.fromJson(version.snapshotJson)
            val forked = projectFromSnapshot.copy(
                id = UUID.randomUUID().toString(),
                name = "${projectFromSnapshot.name} (${version.versionName})",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            repository.saveProject(forked)
            _currentProject.value = forked
        }
    }

    // Tutorial Actions
    fun startTutorial() {
        // Create clean tutorial project
        val tutorialProj = Project(
            id = UUID.randomUUID().toString(),
            name = "Tutorial: My First Bot",
            description = "Step-by-step tutorial bot project",
            blocks = emptyList()
        )
        viewModelScope.launch {
            repository.saveProject(tutorialProj)
            _currentProject.value = tutorialProj
            _selectedBlockId.value = null
            _isTutorialActive.value = true
            _currentTutorialStep.value = 1
        }
    }

    fun nextTutorialStep() {
        _currentTutorialStep.value = (_currentTutorialStep.value + 1).coerceAtMost(5)
    }

    fun prevTutorialStep() {
        _currentTutorialStep.value = (_currentTutorialStep.value - 1).coerceAtLeast(1)
    }

    fun exitTutorial() {
        _isTutorialActive.value = false
    }

    fun autoCompleteCurrentTutorialStep() {
        val step = _currentTutorialStep.value
        val current = _currentProject.value

        when (step) {
            1 -> {
                // Step 1: Add On /start
                val onStartDef = TelegramCatalog.findDefinition("on_message")
                if (onStartDef != null) {
                    val block = BlockNode(
                        id = "tutorial_start_node",
                        typeId = "on_message",
                        title = "On /start Command",
                        category = BlockCategory.EVENTS,
                        parameters = mapOf("filter_type" to "Command", "filter_value" to "/start"),
                        posX = 80f,
                        posY = 100f
                    )
                    val updated = current.copy(blocks = listOf(block))
                    _currentProject.value = updated
                    saveProjectInternal(updated)
                    nextTutorialStep()
                }
            }
            2 -> {
                // Step 2: Add Send Message and link
                val sendMsgBlock = BlockNode(
                    id = "tutorial_send_node",
                    typeId = "send_message",
                    title = "Send Welcome Message",
                    category = BlockCategory.MESSAGES,
                    parameters = mapOf(
                        "chat_id" to "{chat_id}",
                        "text" to "Hello! Welcome to your first Telegram bot built with KAKAROT BOTS BUILDER.",
                        "parse_mode" to "MarkdownV2"
                    ),
                    posX = 80f,
                    posY = 210f
                )
                val updatedBlocks = current.blocks.map {
                    if (it.id == "tutorial_start_node") it.copy(nextBlockId = sendMsgBlock.id) else it
                } + sendMsgBlock
                val updated = current.copy(blocks = updatedBlocks)
                _currentProject.value = updated
                saveProjectInternal(updated)
                nextTutorialStep()
            }
            3 -> {
                // Step 3: Format text with MarkdownV2
                val updatedBlocks = current.blocks.map {
                    if (it.id == "tutorial_send_node") {
                        val p = it.parameters.toMutableMap()
                        p["text"] = "*Hello\\!* Welcome to your first Telegram bot built with *KAKAROT BOTS BUILDER*\\."
                        it.copy(parameters = p)
                    } else it
                }
                val updated = current.copy(blocks = updatedBlocks)
                _currentProject.value = updated
                saveProjectInternal(updated)
                nextTutorialStep()
            }
            4 -> {
                // Step 4: Add Inline Button
                val kb = InlineKeyboardConfig(
                    rows = listOf(
                        InlineKeyboardRow(
                            buttons = listOf(
                                InlineButton(
                                    text = "Click Me",
                                    actionType = ActionType.CALLBACK_DATA,
                                    actionValue = "tutorial_click",
                                    style = ButtonStyle.SUCCESS
                                )
                            )
                        )
                    )
                )
                val updatedBlocks = current.blocks.map {
                    if (it.id == "tutorial_send_node") it.copy(inlineKeyboard = kb) else it
                }
                val updated = current.copy(blocks = updatedBlocks)
                _currentProject.value = updated
                saveProjectInternal(updated)
                nextTutorialStep()
            }
            5 -> {
                // Step 5: Finished
                exitTutorial()
            }
        }
    }

    private fun saveProjectInternal(project: Project) {
        viewModelScope.launch {
            repository.saveProject(project)
        }
    }

    override fun onCleared() {
        super.onCleared()
        executionEngine.stopBot()
    }
}
