package com.example.botblocks.ui.canvas

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.botblocks.model.BlockNode
import com.example.botblocks.ui.components.BlockNodeView
import com.example.ui.theme.*
import kotlin.math.abs

@Composable
fun VisualCanvas(
    blocks: List<BlockNode>,
    selectedBlockId: String?,
    activeExecutingBlockId: String?,
    onSelectBlock: (String) -> Unit,
    onMoveBlock: (id: String, dx: Float, dy: Float) -> Unit,
    onDeleteBlock: (String) -> Unit,
    onSnapBlocks: () -> Unit,
    modifier: Modifier = Modifier
) {
    var panOffsetX by remember { mutableStateOf(0f) }
    var panOffsetY by remember { mutableStateOf(0f) }
    var zoomScale by remember { mutableStateOf(1f) }

    val tabOffsetLeft = 42f // Offset where the puzzle tab / notch is located
    val defaultBlockHeight = 110f

    val gridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
    val canvasBg = MaterialTheme.colorScheme.background

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(canvasBg)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    panOffsetX += pan.x
                    panOffsetY += pan.y
                    zoomScale = (zoomScale * zoom).coerceIn(0.5f, 2.5f)
                }
            }
            .testTag("visual_canvas")
    ) {
        // Background grid and puzzle connection paths
        Canvas(modifier = Modifier.fillMaxSize()) {
            val step = 40f * zoomScale
            val startX = (panOffsetX % step)
            val startY = (panOffsetY % step)

            // Draw grid dots
            var x = startX
            while (x < size.width) {
                var y = startY
                while (y < size.height) {
                    drawCircle(
                        color = gridColor,
                        radius = 1.5f,
                        center = Offset(x, y)
                    )
                    y += step
                }
                x += step
            }

            // Draw interlocking puzzle connector links
            for (block in blocks) {
                val fromTabX = (block.posX + tabOffsetLeft) * zoomScale + panOffsetX
                val fromTabY = (block.posY + defaultBlockHeight) * zoomScale + panOffsetY

                // Sequential next block connection (puzzle tab to puzzle notch)
                block.nextBlockId?.let { targetId ->
                    blocks.find { it.id == targetId }?.let { target ->
                        val toNotchX = (target.posX + tabOffsetLeft) * zoomScale + panOffsetX
                        val toNotchY = target.posY * zoomScale + panOffsetY

                        val isPhysicallySnapped = abs(block.posX - target.posX) < 15f &&
                            (target.posY - block.posY) in 90f..145f

                        if (isPhysicallySnapped) {
                            // Draw tight interlocking snap ring between puzzle tab and notch
                            drawCircle(
                                color = AccentSuccess,
                                radius = 4f * zoomScale,
                                center = Offset(toNotchX, toNotchY)
                            )
                        } else {
                            // Draw puzzle flow link between tab and target notch
                            val path = Path().apply {
                                moveTo(fromTabX, fromTabY)
                                val dy = toNotchY - fromTabY
                                if (dy > 0 && abs(fromTabX - toNotchX) < 60f) {
                                    val midY = (fromTabY + toNotchY) / 2
                                    cubicTo(fromTabX, midY, toNotchX, midY, toNotchX, toNotchY)
                                } else {
                                    val ctrlX = fromTabX
                                    val ctrlY = fromTabY + 40f * zoomScale
                                    val targetCtrlY = toNotchY - 40f * zoomScale
                                    cubicTo(ctrlX, ctrlY, toNotchX, targetCtrlY, toNotchX, toNotchY)
                                }
                            }

                            drawPath(
                                path = path,
                                color = CategoryMessages,
                                style = Stroke(width = 3.5f * zoomScale, cap = StrokeCap.Round)
                            )
                            // Draw tab arrow/socket at entrance
                            drawCircle(color = CategoryMessages, radius = 5f * zoomScale, center = Offset(toNotchX, toNotchY))
                        }
                    }
                }

                // Branch connection (for C-container blocks: if / loop)
                block.branchBlockId?.let { targetId ->
                    blocks.find { it.id == targetId }?.let { target ->
                        val fromMouthX = (block.posX + 30f) * zoomScale + panOffsetX
                        val fromMouthY = (block.posY + 55f) * zoomScale + panOffsetY
                        val toNotchX = (target.posX + tabOffsetLeft) * zoomScale + panOffsetX
                        val toNotchY = target.posY * zoomScale + panOffsetY

                        val path = Path().apply {
                            moveTo(fromMouthX, fromMouthY)
                            val midX = (fromMouthX + toNotchX) / 2
                            cubicTo(fromMouthX, fromMouthY + 20f, toNotchX, toNotchY - 20f, toNotchX, toNotchY)
                        }

                        drawPath(
                            path = path,
                            color = AccentSuccess,
                            style = Stroke(width = 3f * zoomScale, cap = StrokeCap.Round)
                        )
                        drawCircle(color = AccentSuccess, radius = 5f * zoomScale, center = Offset(toNotchX, toNotchY))
                    }
                }

                // Else branch connection
                block.elseBlockId?.let { targetId ->
                    blocks.find { it.id == targetId }?.let { target ->
                        val fromElseX = (block.posX + 30f) * zoomScale + panOffsetX
                        val fromElseY = (block.posY + 90f) * zoomScale + panOffsetY
                        val toNotchX = (target.posX + tabOffsetLeft) * zoomScale + panOffsetX
                        val toNotchY = target.posY * zoomScale + panOffsetY

                        val path = Path().apply {
                            moveTo(fromElseX, fromElseY)
                            val midX = (fromElseX + toNotchX) / 2
                            cubicTo(fromElseX, fromElseY + 20f, toNotchX, toNotchY - 20f, toNotchX, toNotchY)
                        }

                        drawPath(
                            path = path,
                            color = AccentWarning,
                            style = Stroke(width = 3f * zoomScale, cap = StrokeCap.Round)
                        )
                        drawCircle(color = AccentWarning, radius = 5f * zoomScale, center = Offset(toNotchX, toNotchY))
                    }
                }
            }
        }

        // Render block nodes
        Box(modifier = Modifier.fillMaxSize()) {
            for (block in blocks) {
                val transformedBlock = block.copy(
                    posX = block.posX * zoomScale + panOffsetX,
                    posY = block.posY * zoomScale + panOffsetY
                )
                BlockNodeView(
                    block = transformedBlock,
                    isSelected = block.id == selectedBlockId,
                    isActiveExecuting = block.id == activeExecutingBlockId,
                    onSelect = { onSelectBlock(block.id) },
                    onDragDelta = { dx, dy ->
                        onMoveBlock(block.id, dx / zoomScale, dy / zoomScale)
                    },
                    onDelete = { onDeleteBlock(block.id) }
                )
            }
        }

        // Canvas Navigation and Interlock Controls overlay
        Card(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)),
            shape = MaterialTheme.shapes.small
        ) {
            Row(
                modifier = Modifier.padding(4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Button(
                    onClick = onSnapBlocks,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("snap_blocks_button")
                ) {
                    Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Snap Stacks", fontSize = 11.sp)
                }

                IconButton(
                    onClick = { zoomScale = (zoomScale + 0.15f).coerceAtMost(2.5f) },
                    modifier = Modifier.size(34.dp).testTag("canvas_zoom_in")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Zoom In")
                }
                IconButton(
                    onClick = { zoomScale = (zoomScale - 0.15f).coerceAtLeast(0.5f) },
                    modifier = Modifier.size(34.dp).testTag("canvas_zoom_out")
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Zoom Out")
                }
                IconButton(
                    onClick = {
                        zoomScale = 1f
                        panOffsetX = 0f
                        panOffsetY = 0f
                    },
                    modifier = Modifier.size(34.dp).testTag("canvas_reset_view")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset Canvas")
                }
            }
        }
    }
}
