package com.example.botblocks.ui.projects

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.botblocks.data.ProjectSerializer
import com.example.botblocks.model.ExecutionMode
import com.example.botblocks.model.Project
import java.util.UUID

@Composable
fun ProjectListDialog(
    projects: List<Project>,
    currentProject: Project,
    onSelectProject: (Project) -> Unit,
    onCreateProject: (name: String) -> Unit,
    onDuplicateProject: (Project) -> Unit,
    onDeleteProject: (String) -> Unit,
    onImportJson: (json: String) -> Boolean,
    onUpdateProjectDetails: (Project) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var isCreatingNew by remember { mutableStateOf(false) }
    var newProjectName by remember { mutableStateOf("") }
    var isImporting by remember { mutableStateOf(false) }
    var importJsonText by remember { mutableStateOf("") }
    var editingTokenProject by remember { mutableStateOf<Project?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(12.dp))
                .testTag("project_list_dialog"),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Projects & Bot Settings",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Manage bot configurations, tokens, and JSON import/export",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_projects_button")) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Actions: New Project, Import JSON
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { isCreatingNew = true },
                        modifier = Modifier.weight(1f).testTag("new_project_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("New Project")
                    }

                    OutlinedButton(
                        onClick = { isImporting = true },
                        modifier = Modifier.weight(1f).testTag("import_json_button")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Import JSON")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(10.dp))

                // Projects List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(projects) { p ->
                        val isCurrent = p.id == currentProject.id
                        ProjectCardItem(
                            project = p,
                            isCurrent = isCurrent,
                            onSelect = {
                                onSelectProject(p)
                                onDismiss()
                            },
                            onEditSettings = {
                                editingTokenProject = p
                            },
                            onDuplicate = { onDuplicateProject(p) },
                            onDelete = { onDeleteProject(p.id) },
                            onExportJson = {
                                val json = ProjectSerializer.toJson(p)
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("${p.name}.json", json)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Copied project JSON to clipboard", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }
    }

    // Create New Project Dialog
    if (isCreatingNew) {
        AlertDialog(
            onDismissRequest = { isCreatingNew = false },
            title = { Text("Create New Bot Project") },
            text = {
                OutlinedTextField(
                    value = newProjectName,
                    onValueChange = { newProjectName = it },
                    label = { Text("Project Name") },
                    placeholder = { Text("e.g. Support Bot") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = newProjectName.trim().ifBlank { "Untitled Bot" }
                        onCreateProject(name)
                        isCreatingNew = false
                        newProjectName = ""
                        onDismiss()
                    }
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { isCreatingNew = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Import JSON Dialog
    if (isImporting) {
        AlertDialog(
            onDismissRequest = { isImporting = false },
            title = { Text("Import Project JSON") },
            text = {
                Column {
                    Text("Paste previously exported BotBlocks JSON:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = importJsonText,
                        onValueChange = { importJsonText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ok = onImportJson(importJsonText.trim())
                        if (ok) {
                            Toast.makeText(context, "Project imported successfully", Toast.LENGTH_SHORT).show()
                            isImporting = false
                            importJsonText = ""
                            onDismiss()
                        } else {
                            Toast.makeText(context, "Invalid JSON structure", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Import")
                }
            },
            dismissButton = {
                TextButton(onClick = { isImporting = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Edit Bot Token and Mode Dialog
    editingTokenProject?.let { p ->
        var tokenInput by remember { mutableStateOf(p.botToken) }
        var modeInput by remember { mutableStateOf(p.executionMode) }
        var webhookUrlInput by remember { mutableStateOf(p.webhookUrl) }
        var nameInput by remember { mutableStateOf(p.name) }

        AlertDialog(
            onDismissRequest = { editingTokenProject = null },
            title = { Text("Bot Configuration: ${p.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Bot Project Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = tokenInput,
                        onValueChange = { tokenInput = it },
                        label = { Text("Telegram Bot Token") },
                        placeholder = { Text("123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Text(
                        text = "Get your token from @BotFather on Telegram. It is stored securely on device.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Execution Mode:", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = modeInput == ExecutionMode.LONG_POLLING,
                            onClick = { modeInput = ExecutionMode.LONG_POLLING },
                            label = { Text("Long Polling") }
                        )
                        FilterChip(
                            selected = modeInput == ExecutionMode.WEBHOOK,
                            onClick = { modeInput = ExecutionMode.WEBHOOK },
                            label = { Text("Webhook") }
                        )
                    }

                    if (modeInput == ExecutionMode.WEBHOOK) {
                        OutlinedTextField(
                            value = webhookUrlInput,
                            onValueChange = { webhookUrlInput = it },
                            label = { Text("Webhook URL") },
                            placeholder = { Text("https://example.com/bot") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val updated = p.copy(
                            name = nameInput.trim().ifBlank { p.name },
                            botToken = tokenInput.trim(),
                            executionMode = modeInput,
                            webhookUrl = webhookUrlInput.trim()
                        )
                        onUpdateProjectDetails(updated)
                        editingTokenProject = null
                    }
                ) {
                    Text("Save Settings")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingTokenProject = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ProjectCardItem(
    project: Project,
    isCurrent: Boolean,
    onSelect: () -> Unit,
    onEditSettings: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onExportJson: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .border(
                width = if (isCurrent) 2.dp else 1.dp,
                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onSelect() }
            .testTag("project_item_${project.id}"),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = project.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (isCurrent) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "ACTIVE",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }
                }

                Row {
                    IconButton(onClick = onEditSettings, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onExportJson, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Share, contentDescription = "Export JSON", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDuplicate, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "${project.blocks.size} visual blocks | Mode: ${project.executionMode.name} | Token: ${if (project.botToken.isNotBlank()) "Configured" else "None"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
