package com.example.botblocks.ui.execution

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.botblocks.engine.LogEntry
import com.example.botblocks.engine.LogLevel
import com.example.ui.theme.*

@Composable
fun ExecutionLogPanel(
    logs: List<LogEntry>,
    isRunning: Boolean,
    botUsername: String?,
    onClearLogs: () -> Unit,
    onSelectBlock: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf<LogLevel?>(null) }

    val filteredLogs = remember(logs, selectedFilter) {
        if (selectedFilter == null) logs else logs.filter { it.level == selectedFilter }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("execution_log_panel"),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp
    ) {
        Column {
            // Header bar (always visible)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Execution Engine & Logs",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    if (isRunning) {
                        Surface(
                            color = AccentSuccess.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "RUNNING ${botUsername ?: ""}",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AccentSuccess
                                )
                            )
                        }
                    } else {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "STOPPED",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.secondary)
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${logs.size} events",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    if (isExpanded) {
                        IconButton(onClick = onClearLogs, modifier = Modifier.size(28.dp).testTag("clear_logs_button")) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear Logs", modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            // Expanded view
            if (isExpanded) {
                HorizontalDivider()

                // Filter row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedFilter == null,
                        onClick = { selectedFilter = null },
                        label = { Text("All (${logs.size})") }
                    )
                    FilterChip(
                        selected = selectedFilter == LogLevel.API_CALL,
                        onClick = { selectedFilter = if (selectedFilter == LogLevel.API_CALL) null else LogLevel.API_CALL },
                        label = { Text("API Calls") }
                    )
                    FilterChip(
                        selected = selectedFilter == LogLevel.ERROR,
                        onClick = { selectedFilter = if (selectedFilter == LogLevel.ERROR) null else LogLevel.ERROR },
                        label = { Text("Errors (${logs.count { it.level == LogLevel.ERROR }})") }
                    )
                    FilterChip(
                        selected = selectedFilter == LogLevel.SUCCESS,
                        onClick = { selectedFilter = if (selectedFilter == LogLevel.SUCCESS) null else LogLevel.SUCCESS },
                        label = { Text("Success") }
                    )
                }

                // Logs list
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (filteredLogs.isEmpty()) {
                        item {
                            Text(
                                text = "No log events yet. Start the bot or trigger an action to see real-time events.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 12.dp)
                            )
                        }
                    } else {
                        items(filteredLogs) { entry ->
                            LogItemView(entry = entry, onSelectBlock = onSelectBlock)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LogItemView(
    entry: LogEntry,
    onSelectBlock: (String) -> Unit
) {
    val levelColor = when (entry.level) {
        LogLevel.INFO -> Slate400
        LogLevel.API_CALL -> AccentBlue
        LogLevel.SUCCESS -> AccentSuccess
        LogLevel.ERROR -> AccentDanger
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = entry.blockId != null) {
                entry.blockId?.let { onSelectBlock(it) }
            },
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        shape = RoundedCornerShape(4.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.Top
        ) {
            Text(
                text = entry.formattedTime(),
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = entry.level.name,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = levelColor
                ),
                modifier = Modifier.width(60.dp)
            )

            Spacer(modifier = Modifier.width(6.dp))

            Column(modifier = Modifier.weight(1f)) {
                if (entry.blockTitle != null) {
                    Text(
                        text = "Block [${entry.blockTitle}]",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 11.sp
                        )
                    )
                }

                Text(
                    text = entry.message,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                )

                if (!entry.details.isNullOrBlank()) {
                    Text(
                        text = entry.details,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
