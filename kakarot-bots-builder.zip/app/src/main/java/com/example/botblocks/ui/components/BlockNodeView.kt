package com.example.botblocks.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.botblocks.model.BlockCategory
import com.example.botblocks.model.BlockNode
import com.example.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun BlockNodeView(
    block: BlockNode,
    isSelected: Boolean,
    isActiveExecuting: Boolean,
    onSelect: () -> Unit,
    onDragDelta: (dx: Float, dy: Float) -> Unit,
    onDelete: () -> Unit
) {
    val form = when {
        block.typeId.startsWith("on_") || block.category == BlockCategory.EVENTS -> SketchwareBlockForm.EVENT_HAT
        block.typeId == "if_condition" || block.typeId == "loop_times" -> SketchwareBlockForm.C_CONTAINER
        else -> SketchwareBlockForm.STATEMENT
    }

    val blockColor = when (block.category) {
        BlockCategory.EVENTS -> CategoryEvents
        BlockCategory.MESSAGES -> CategoryMessages
        BlockCategory.MEDIA -> CategoryMedia
        BlockCategory.KEYBOARDS -> CategoryKeyboards
        BlockCategory.EDITING -> CategoryEditing
        BlockCategory.CHAT_ADMIN -> CategoryAdmin
        BlockCategory.PAYMENTS -> CategoryPayments
        BlockCategory.LOGIC -> CategoryLogic
        BlockCategory.HTTP_WEB -> CategoryNetwork
        BlockCategory.UPDATES -> CategoryUpdates
    }

    val puzzleShape = SketchwarePuzzleShape(form = form)
    val highlightBorder = when {
        isActiveExecuting -> AccentSuccess
        isSelected -> Color.White
        else -> Color.Transparent
    }

    val isCContainer = form == SketchwareBlockForm.C_CONTAINER
    val nodeWidth = if (isCContainer) 250.dp else 235.dp

    Surface(
        modifier = Modifier
            .offset { IntOffset(block.posX.roundToInt(), block.posY.roundToInt()) }
            .width(nodeWidth)
            .shadow(if (isSelected) 10.dp else 4.dp, puzzleShape)
            .border(if (isSelected || isActiveExecuting) 2.5.dp else 0.dp, highlightBorder, puzzleShape)
            .clip(puzzleShape)
            .pointerInput(block.id) {
                detectDragGestures(
                    onDragStart = { onSelect() },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        onDragDelta(dragAmount.x, dragAmount.y)
                    }
                )
            }
            .clickable { onSelect() }
            .testTag("node_${block.id}"),
        color = blockColor
    ) {
        Column(
            modifier = Modifier
                .padding(
                    start = 12.dp,
                    end = 12.dp,
                    top = if (form == SketchwareBlockForm.EVENT_HAT) 16.dp else 12.dp,
                    bottom = 14.dp
                )
        ) {
            // Header Row: Title & Active Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val icon = when (block.category) {
                        BlockCategory.EVENTS -> Icons.Default.PlayCircleOutline
                        BlockCategory.MESSAGES -> Icons.Default.Send
                        BlockCategory.MEDIA -> Icons.Default.Image
                        BlockCategory.KEYBOARDS -> Icons.Default.SmartButton
                        BlockCategory.EDITING -> Icons.Default.Edit
                        BlockCategory.CHAT_ADMIN -> Icons.Default.Gavel
                        BlockCategory.PAYMENTS -> Icons.Default.Payment
                        BlockCategory.LOGIC -> Icons.Default.CallSplit
                        BlockCategory.HTTP_WEB -> Icons.Default.Http
                        BlockCategory.UPDATES -> Icons.Default.Sync
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = block.title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (isActiveExecuting) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color.White, CircleShape)
                            .border(2.dp, AccentSuccess, CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Parameter argument slots (Sketchware pill design)
            val previewEntries = block.parameters.entries.take(3)
            if (previewEntries.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    for ((k, v) in previewEntries) {
                        val isVariableRef = v.startsWith("{") && v.endsWith("}")
                        val pillColor = if (isVariableRef) Color(0xFFFFF7ED) else Color.White.copy(alpha = 0.94f)
                        val textColor = if (isVariableRef) Color(0xFFC2410C) else Color(0xFF1E293B)

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = pillColor,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isVariableRef) Color(0xFFFB923C) else Color(0xFFCBD5E1)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "$k:",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF64748B)
                                    )
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = v.ifBlank { "(empty)" },
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = if (isVariableRef) FontWeight.Bold else FontWeight.Normal,
                                        color = textColor
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Method: ${block.typeId}",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = Color.DarkGray)
                    )
                }
            }

            // Attached Keyboards badges
            if (block.inlineKeyboard != null && block.inlineKeyboard.rows.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.Black.copy(alpha = 0.22f)
                ) {
                    Text(
                        text = "Inline: ${block.inlineKeyboard.rows.sumOf { it.buttons.size }} buttons",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    )
                }
            }

            // Inner mouth preview for C_CONTAINER blocks (if / loop)
            if (isCContainer) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 12.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(6.dp)),
                    color = Color.Black.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.SubdirectoryArrowRight,
                            contentDescription = null,
                            modifier = Modifier.size(12.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (block.branchBlockId != null) "Branch: Locked" else "Branch Slot (Empty)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (block.branchBlockId != null) AccentSuccess else Color.White.copy(alpha = 0.8f)
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Connection indicator row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (block.typeId == "if_condition") {
                    Text(
                        text = if (block.branchBlockId != null) "Then: Linked" else "Then: (None)",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = Color.White.copy(alpha = 0.95f))
                    )
                    Text(
                        text = if (block.elseBlockId != null) "Else: Linked" else "Else: (None)",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = Color.White.copy(alpha = 0.95f))
                    )
                } else {
                    Text(
                        text = if (block.nextBlockId != null) "Snap: Connected" else "Bottom Tab: Free",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.95f)
                        )
                    )
                    if (form != SketchwareBlockForm.EVENT_HAT) {
                        Text(
                            text = "Top Notch",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                color = Color.White.copy(alpha = 0.75f)
                            )
                        )
                    }
                }
            }
        }
    }
}
