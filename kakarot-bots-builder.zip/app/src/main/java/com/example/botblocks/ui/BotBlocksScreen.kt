package com.example.botblocks.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.botblocks.model.*
import com.example.botblocks.ui.canvas.VisualCanvas
import com.example.botblocks.ui.components.KeyboardBuilderDialog
import com.example.botblocks.ui.components.MessageComposerDialog
import com.example.botblocks.ui.components.OnboardingDialog
import com.example.botblocks.ui.components.TutorialGuideBar
import com.example.botblocks.ui.execution.ExecutionLogPanel
import com.example.botblocks.ui.export.PythonExportDialog
import com.example.botblocks.ui.inspector.BlockInspector
import com.example.botblocks.ui.palette.BlockPalette
import com.example.botblocks.ui.projects.ProjectListDialog
import com.example.botblocks.ui.versioning.VersionHistoryDialog
import com.example.ui.theme.AccentDanger
import com.example.ui.theme.AccentSuccess

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BotBlocksScreen(
    viewModel: BotBlocksViewModel,
    modifier: Modifier = Modifier
) {
    val currentProject by viewModel.currentProject.collectAsState()
    val allProjects by viewModel.allProjects.collectAsState()
    val selectedBlockId by viewModel.selectedBlockId.collectAsState()
    val isRunning by viewModel.executionEngine.isRunning.collectAsState()
    val botUsername by viewModel.executionEngine.botUsername.collectAsState()
    val activeExecutingBlockId by viewModel.executionEngine.activeBlockId.collectAsState()
    val logs by viewModel.executionEngine.logs.collectAsState()
    val projectVersions by viewModel.projectVersions.collectAsState()
    val isTutorialActive by viewModel.isTutorialActive.collectAsState()
    val currentTutorialStep by viewModel.currentTutorialStep.collectAsState()

    var showPalette by remember { mutableStateOf(false) }
    var showInspector by remember { mutableStateOf(false) }
    var showProjectsDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showVersionDialog by remember { mutableStateOf(false) }
    var showOnboardingDialog by remember { mutableStateOf(false) }

    // Dialogs for composer and keyboard builder
    var composerTargetParam by remember { mutableStateOf<Pair<String, String>?>(null) } // text, parseMode
    var showKeyboardBuilder by remember { mutableStateOf(false) }

    val selectedBlock = remember(currentProject.blocks, selectedBlockId) {
        currentProject.blocks.find { it.id == selectedBlockId }
    }

    LaunchedEffect(selectedBlockId) {
        if (selectedBlockId != null) {
            showInspector = true
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "KAKAROT BOTS BUILDER",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Surface(
                                modifier = Modifier.testTag("project_selector_chip"),
                                onClick = { showProjectsDialog = true },
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = currentProject.name,
                                        style = MaterialTheme.typography.labelMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    },
                    actions = {
                        // Guide / Onboarding Button
                        IconButton(
                            onClick = { showOnboardingDialog = true },
                            modifier = Modifier.testTag("onboarding_guide_button")
                        ) {
                            Icon(Icons.Default.HelpOutline, contentDescription = "Guide & Onboarding")
                        }

                        // Version History Button
                        IconButton(
                            onClick = { showVersionDialog = true },
                            modifier = Modifier.testTag("version_history_button")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (projectVersions.isNotEmpty()) {
                                        Badge { Text(projectVersions.size.toString()) }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.History, contentDescription = "Version History")
                            }
                        }

                        // Toggle Palette Button
                        IconButton(
                            onClick = { showPalette = !showPalette },
                            modifier = Modifier.testTag("toggle_palette_button")
                        ) {
                            Icon(
                                Icons.Default.AddBox,
                                contentDescription = "Block Palette",
                                tint = if (showPalette) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Run / Stop Bot Button
                        Button(
                            onClick = { viewModel.toggleBot() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isRunning) AccentDanger else AccentSuccess
                            ),
                            modifier = Modifier.padding(horizontal = 2.dp).testTag("run_bot_button"),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = if (isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isRunning) "Stop" else "Run")
                        }

                        // Export Python Button
                        OutlinedButton(
                            onClick = { showExportDialog = true },
                            modifier = Modifier.padding(horizontal = 2.dp).testTag("export_python_button"),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export")
                        }

                        // Toggle Inspector Button
                        IconButton(
                            onClick = { showInspector = !showInspector },
                            modifier = Modifier.testTag("toggle_inspector_button")
                        ) {
                            Icon(
                                Icons.Default.Tune,
                                contentDescription = "Inspector",
                                tint = if (showInspector) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )

                // Tutorial step banner if active
                if (isTutorialActive) {
                    TutorialGuideBar(
                        currentStepIndex = currentTutorialStep,
                        onNextStep = { viewModel.nextTutorialStep() },
                        onPrevStep = { viewModel.prevTutorialStep() },
                        onAutoCompleteStep = { viewModel.autoCompleteCurrentTutorialStep() },
                        onExitTutorial = { viewModel.exitTutorial() }
                    )
                }
            }
        },
        bottomBar = {
            ExecutionLogPanel(
                logs = logs,
                isRunning = isRunning,
                botUsername = botUsername,
                onClearLogs = { viewModel.executionEngine.clearLogs() },
                onSelectBlock = { blockId ->
                    viewModel.selectBlock(blockId)
                    showInspector = true
                }
            )
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isWideScreen = maxWidth > 840.dp

            if (isWideScreen) {
                // 3-Pane Desktop / Tablet Layout: Palette (280dp) | Canvas (Flex) | Inspector (340dp)
                Row(modifier = Modifier.fillMaxSize()) {
                    if (showPalette) {
                        BlockPalette(
                            onAddBlock = { def ->
                                viewModel.addBlock(def)
                            },
                            modifier = Modifier.width(280.dp)
                        )
                        HorizontalDivider(modifier = Modifier.fillMaxHeight().width(1.dp))
                    }

                    VisualCanvas(
                        blocks = currentProject.blocks,
                        selectedBlockId = selectedBlockId,
                        activeExecutingBlockId = activeExecutingBlockId,
                        onSelectBlock = { id ->
                            viewModel.selectBlock(id)
                            showInspector = true
                        },
                        onMoveBlock = { id, dx, dy ->
                            viewModel.moveBlock(id, dx, dy)
                        },
                        onDeleteBlock = { id ->
                            viewModel.deleteBlock(id)
                        },
                        onSnapBlocks = { viewModel.snapAllConnectedBlocks() },
                        modifier = Modifier.weight(1f)
                    )

                    if (showInspector && selectedBlock != null) {
                        HorizontalDivider(modifier = Modifier.fillMaxHeight().width(1.dp))
                        BlockInspector(
                            block = selectedBlock,
                            allBlocks = currentProject.blocks,
                            onUpdateBlock = { viewModel.updateBlock(it) },
                            onDeleteBlock = { viewModel.deleteBlock(it) },
                            onDuplicateBlock = { viewModel.duplicateBlock(it) },
                            onOpenComposer = { currentText, currentMode ->
                                composerTargetParam = Pair(currentText, currentMode)
                            },
                            onOpenKeyboardBuilder = {
                                showKeyboardBuilder = true
                            },
                            onClose = { showInspector = false },
                            modifier = Modifier.width(340.dp)
                        )
                    }
                }
            } else {
                // Compact / Phone Layout: Canvas in center, Floating Panels
                Box(modifier = Modifier.fillMaxSize()) {
                    VisualCanvas(
                        blocks = currentProject.blocks,
                        selectedBlockId = selectedBlockId,
                        activeExecutingBlockId = activeExecutingBlockId,
                        onSelectBlock = { id ->
                            viewModel.selectBlock(id)
                            showInspector = true
                        },
                        onMoveBlock = { id, dx, dy ->
                            viewModel.moveBlock(id, dx, dy)
                        },
                        onDeleteBlock = { id ->
                            viewModel.deleteBlock(id)
                        },
                        onSnapBlocks = { viewModel.snapAllConnectedBlocks() },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay Palette Sheet if active
                    if (showPalette) {
                        Surface(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(300.dp)
                                .align(Alignment.CenterStart)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            tonalElevation = 8.dp
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    IconButton(onClick = { showPalette = false }) {
                                        Icon(Icons.Default.Close, contentDescription = "Close Palette")
                                    }
                                }
                                BlockPalette(
                                    onAddBlock = { def ->
                                        viewModel.addBlock(def)
                                        showPalette = false
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }

                    // Overlay Inspector Sheet if active and block selected
                    if (showInspector && selectedBlock != null) {
                        Surface(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(320.dp)
                                .align(Alignment.CenterEnd)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            tonalElevation = 8.dp
                        ) {
                            BlockInspector(
                                block = selectedBlock,
                                allBlocks = currentProject.blocks,
                                onUpdateBlock = { viewModel.updateBlock(it) },
                                onDeleteBlock = { viewModel.deleteBlock(it) },
                                onDuplicateBlock = { viewModel.duplicateBlock(it) },
                                onOpenComposer = { currentText, currentMode ->
                                    composerTargetParam = Pair(currentText, currentMode)
                                },
                                onOpenKeyboardBuilder = {
                                    showKeyboardBuilder = true
                                },
                                onClose = { showInspector = false },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }
        }
    }

    // Onboarding Dialog
    if (showOnboardingDialog) {
        OnboardingDialog(
            onDismiss = { showOnboardingDialog = false },
            onStartTutorial = {
                viewModel.startTutorial()
            }
        )
    }

    // Version History Dialog
    if (showVersionDialog) {
        VersionHistoryDialog(
            project = currentProject,
            versions = projectVersions,
            onCreateVersion = { name, desc ->
                viewModel.createVersion(name, desc)
            },
            onRestoreVersion = { versionId ->
                viewModel.restoreVersion(versionId)
            },
            onDeleteVersion = { versionId ->
                viewModel.deleteVersion(versionId)
            },
            onDuplicateAsProject = { version ->
                viewModel.forkVersionAsProject(version)
            },
            onDismiss = { showVersionDialog = false }
        )
    }

    // Projects Dialog
    if (showProjectsDialog) {
        ProjectListDialog(
            projects = allProjects,
            currentProject = currentProject,
            onSelectProject = { viewModel.selectProject(it) },
            onCreateProject = { viewModel.createProject(it) },
            onDuplicateProject = { viewModel.duplicateProject(it) },
            onDeleteProject = { viewModel.deleteProject(it) },
            onImportJson = { viewModel.importProjectJson(it) },
            onUpdateProjectDetails = { viewModel.updateProjectDetails(it) },
            onDismiss = { showProjectsDialog = false }
        )
    }

    // Export Python Dialog
    if (showExportDialog) {
        PythonExportDialog(
            project = currentProject,
            onDismiss = { showExportDialog = false }
        )
    }

    // Message Composer Dialog
    composerTargetParam?.let { (text, mode) ->
        MessageComposerDialog(
            initialText = text,
            initialParseMode = mode,
            onDismiss = { composerTargetParam = null },
            onApply = { newText, newMode ->
                selectedBlock?.let { b ->
                    val updatedParams = b.parameters.toMutableMap()
                    if (updatedParams.containsKey("text")) {
                        updatedParams["text"] = newText
                    } else if (updatedParams.containsKey("caption")) {
                        updatedParams["caption"] = newText
                    }
                    updatedParams["parse_mode"] = newMode
                    viewModel.updateBlock(b.copy(parameters = updatedParams))
                }
                composerTargetParam = null
            }
        )
    }

    // Keyboard Builder Dialog
    if (showKeyboardBuilder && selectedBlock != null) {
        KeyboardBuilderDialog(
            initialInlineKeyboard = selectedBlock.inlineKeyboard,
            initialReplyKeyboard = selectedBlock.replyKeyboard,
            onDismiss = { showKeyboardBuilder = false },
            onApply = { inline, reply, remove ->
                viewModel.updateBlock(
                    selectedBlock.copy(
                        inlineKeyboard = inline,
                        replyKeyboard = reply,
                        removeKeyboard = remove
                    )
                )
            }
        )
    }
}
