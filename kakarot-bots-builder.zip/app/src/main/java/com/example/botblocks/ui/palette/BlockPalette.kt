package com.example.botblocks.ui.palette

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.botblocks.model.BlockCategory
import com.example.botblocks.model.BlockDefinition
import com.example.botblocks.model.TelegramCatalog
import com.example.ui.theme.*

@Composable
fun BlockPalette(
    onAddBlock: (BlockDefinition) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<BlockCategory?>(null) }

    val filteredBlocks = remember(searchQuery, selectedCategory) {
        TelegramCatalog.allDefinitions.filter { def ->
            val matchCategory = selectedCategory == null || def.category == selectedCategory
            val matchSearch = searchQuery.isBlank() ||
                def.title.contains(searchQuery, ignoreCase = true) ||
                def.typeId.contains(searchQuery, ignoreCase = true) ||
                def.description.contains(searchQuery, ignoreCase = true)
            matchCategory && matchSearch
        }
    }

    Surface(
        modifier = modifier
            .fillMaxHeight()
            .testTag("block_palette"),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "Block Palette",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Telegram Bot API methods & logic",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Search input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search blocks or methods...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("palette_search_input"),
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Categories horizontal bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { selectedCategory = null },
                    label = { Text("All (${TelegramCatalog.allDefinitions.size})") }
                )
                BlockCategory.values().forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
                        label = { Text(cat.displayName) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Blocks List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredBlocks) { def ->
                    PaletteBlockItem(
                        definition = def,
                        onAdd = { onAddBlock(def) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PaletteBlockItem(
    definition: BlockDefinition,
    onAdd: () -> Unit
) {
    val categoryColor = when (definition.category) {
        BlockCategory.EVENTS -> CategoryEvents
        BlockCategory.MESSAGES -> CategoryMessages
        BlockCategory.MEDIA -> CategoryMedia
        BlockCategory.KEYBOARDS -> CategoryKeyboards
        BlockCategory.EDITING -> CategoryEditing
        BlockCategory.CHAT_ADMIN -> CategoryAdmin
        BlockCategory.PAYMENTS -> CategoryPayments
        BlockCategory.LOGIC -> CategoryLogic
        BlockCategory.HTTP_WEB -> CategoryNetwork
        BlockCategory.UPDATES -> CategoryUpdates
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .clickable { onAdd() }
            .testTag("palette_item_${definition.typeId}"),
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(36.dp)
                    .background(categoryColor, RoundedCornerShape(2.dp))
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = definition.title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = definition.description,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(
                onClick = onAdd,
                modifier = Modifier.size(32.dp).testTag("add_block_${definition.typeId}")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Block", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
