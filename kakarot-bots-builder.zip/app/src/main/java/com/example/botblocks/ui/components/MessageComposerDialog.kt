package com.example.botblocks.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.botblocks.format.TelegramFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageComposerDialog(
    initialText: String,
    initialParseMode: String,
    onDismiss: () -> Unit,
    onApply: (text: String, parseMode: String) -> Unit
) {
    var rawText by remember { mutableStateOf(initialText) }
    var selectedParseMode by remember { mutableStateOf(if (initialParseMode.isBlank()) "MarkdownV2" else initialParseMode) }
    var linkUrlInput by remember { mutableStateOf("") }
    var showLinkDialog by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(12.dp))
                .testTag("message_composer_dialog"),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Message Composer",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Automatic escaping for MarkdownV2 and HTML formatting",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("composer_close_button")) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Parse Mode selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Target Format:", style = MaterialTheme.typography.labelMedium)
                    FilterChip(
                        selected = selectedParseMode == "MarkdownV2",
                        onClick = { selectedParseMode = "MarkdownV2" },
                        label = { Text("MarkdownV2") },
                        modifier = Modifier.testTag("chip_markdownv2")
                    )
                    FilterChip(
                        selected = selectedParseMode == "HTML",
                        onClick = { selectedParseMode = "HTML" },
                        label = { Text("HTML") },
                        modifier = Modifier.testTag("chip_html")
                    )
                    FilterChip(
                        selected = selectedParseMode == "Plain Text",
                        onClick = { selectedParseMode = "Plain Text" },
                        label = { Text("Plain Text") },
                        modifier = Modifier.testTag("chip_plain")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Formatting Tool Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            rawText = if (selectedParseMode == "HTML") {
                                "$rawText<b>Bold Text</b>"
                            } else {
                                "$rawText*Bold Text*"
                            }
                        },
                        modifier = Modifier.testTag("format_bold_button"),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("B", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bold")
                    }

                    OutlinedButton(
                        onClick = {
                            rawText = if (selectedParseMode == "HTML") {
                                "$rawText<i>Italic Text</i>"
                            } else {
                                "${rawText}_Italic Text_"
                            }
                        },
                        modifier = Modifier.testTag("format_italic_button"),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("I", fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Italic")
                    }

                    OutlinedButton(
                        onClick = {
                            rawText = if (selectedParseMode == "HTML") {
                                "$rawText<code>code</code>"
                            } else {
                                "$rawText`code`"
                            }
                        },
                        modifier = Modifier.testTag("format_code_button"),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Code")
                    }

                    OutlinedButton(
                        onClick = {
                            rawText = if (selectedParseMode == "HTML") {
                                "$rawText<pre><code class=\"language-python\">def run():\n    pass</code></pre>"
                            } else {
                                "$rawText```python\ndef run():\n    pass\n```"
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Code Block")
                    }

                    OutlinedButton(
                        onClick = {
                            rawText = if (selectedParseMode == "HTML") {
                                "$rawText<u>Underlined</u>"
                            } else {
                                "${rawText}__Underlined__"
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Underline")
                    }

                    OutlinedButton(
                        onClick = {
                            rawText = if (selectedParseMode == "HTML") {
                                "$rawText<s>Strikethrough</s>"
                            } else {
                                "$rawText~Strikethrough~"
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Strike")
                    }

                    OutlinedButton(
                        onClick = {
                            rawText = if (selectedParseMode == "HTML") {
                                "$rawText<tg-spoiler>Secret</tg-spoiler>"
                            } else {
                                "$rawText||Secret||"
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Spoiler")
                    }

                    OutlinedButton(
                        onClick = { showLinkDialog = true },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Link")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Variable insertion chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("Insert:", style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.CenterVertically))
                    listOf("{chat_id}", "{user_name}", "{user_id}", "{text}", "{message_id}").forEach { varTag ->
                        AssistChip(
                            onClick = { rawText += varTag },
                            label = { Text(varTag, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Text input area
                OutlinedTextField(
                    value = rawText,
                    onValueChange = { rawText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("composer_text_input"),
                    placeholder = { Text("Write message text or click formatting buttons above...") },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Escaped Output & Validation Preview
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(85.dp)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp)),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(8.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = "Escaped API Output Preview ($selectedParseMode):",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        val escapedPreview = when (selectedParseMode) {
                            "MarkdownV2" -> TelegramFormatter.escapeMarkdownV2(rawText)
                            "HTML" -> TelegramFormatter.escapeHtml(rawText)
                            else -> rawText
                        }
                        Text(
                            text = escapedPreview,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Footer Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss, modifier = Modifier.testTag("composer_cancel_button")) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            onApply(rawText, selectedParseMode)
                            onDismiss()
                        },
                        modifier = Modifier.testTag("composer_apply_button")
                    ) {
                        Text("Apply to Block")
                    }
                }
            }
        }
    }

    if (showLinkDialog) {
        var linkText by remember { mutableStateOf("Click Here") }
        var linkUrl by remember { mutableStateOf("https://") }

        AlertDialog(
            onDismissRequest = { showLinkDialog = false },
            title = { Text("Insert Hyperlink") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = linkText,
                        onValueChange = { linkText = it },
                        label = { Text("Display Text") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = linkUrl,
                        onValueChange = { linkUrl = it },
                        label = { Text("URL") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val formattedLink = if (selectedParseMode == "HTML") {
                            "<a href=\"$linkUrl\">$linkText</a>"
                        } else {
                            "[$linkText]($linkUrl)"
                        }
                        rawText += formattedLink
                        showLinkDialog = false
                    }
                ) {
                    Text("Insert")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLinkDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
