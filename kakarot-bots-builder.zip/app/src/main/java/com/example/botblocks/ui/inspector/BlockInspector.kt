package com.example.botblocks.ui.inspector

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.botblocks.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlockInspector(
    block: BlockNode,
    allBlocks: List<BlockNode>,
    onUpdateBlock: (BlockNode) -> Unit,
    onDeleteBlock: (String) -> Unit,
    onDuplicateBlock: (BlockNode) -> Unit,
    onOpenComposer: (currentText: String, currentParseMode: String) -> Unit,
    onOpenKeyboardBuilder: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val def = TelegramCatalog.findDefinition(block.typeId)

    Surface(
        modifier = modifier
            .fillMaxHeight()
            .testTag("block_inspector"),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = block.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Type: ${block.typeId} (${block.category.displayName})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onClose, modifier = Modifier.testTag("close_inspector_button")) {
                    Icon(Icons.Default.Close, contentDescription = "Close Inspector")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action toolbar: Duplicate, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onDuplicateBlock(block) },
                    modifier = Modifier.weight(1f).testTag("duplicate_block_button"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Duplicate")
                }
                OutlinedButton(
                    onClick = { onDeleteBlock(block.id) },
                    modifier = Modifier.weight(1f).testTag("delete_block_button"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Delete")
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(14.dp))

            // Custom Title
            OutlinedTextField(
                value = block.title,
                onValueChange = { onUpdateBlock(block.copy(title = it)) },
                label = { Text("Display Label") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Parameters list
            if (def != null && def.parameters.isNotEmpty()) {
                Text(
                    text = "Parameters",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                for (param in def.parameters) {
                    val currentValue = block.parameters[param.key] ?: param.defaultValue

                    when (param.type) {
                        ParameterType.STRING -> {
                            OutlinedTextField(
                                value = currentValue,
                                onValueChange = { newVal ->
                                    val updatedParams = block.parameters.toMutableMap()
                                    updatedParams[param.key] = newVal
                                    onUpdateBlock(block.copy(parameters = updatedParams))
                                },
                                label = { Text(param.label) },
                                placeholder = { Text(param.hint) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("param_${param.key}"),
                                singleLine = true
                            )
                        }

                        ParameterType.TEXT_MULTILINE -> {
                            Column {
                                OutlinedTextField(
                                    value = currentValue,
                                    onValueChange = { newVal ->
                                        val updatedParams = block.parameters.toMutableMap()
                                        updatedParams[param.key] = newVal
                                        onUpdateBlock(block.copy(parameters = updatedParams))
                                    },
                                    label = { Text(param.label) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 80.dp)
                                        .testTag("param_${param.key}"),
                                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Button(
                                    onClick = {
                                        val pMode = block.parameters["parse_mode"] ?: "MarkdownV2"
                                        onOpenComposer(currentValue, pMode)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("open_composer_${param.key}"),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Open Message Composer")
                                }
                            }
                        }

                        ParameterType.BOOLEAN -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(param.label, style = MaterialTheme.typography.bodyMedium)
                                Switch(
                                    checked = currentValue.toBoolean(),
                                    onCheckedChange = { checked ->
                                        val updatedParams = block.parameters.toMutableMap()
                                        updatedParams[param.key] = checked.toString()
                                        onUpdateBlock(block.copy(parameters = updatedParams))
                                    },
                                    modifier = Modifier.testTag("param_switch_${param.key}")
                                )
                            }
                        }

                        ParameterType.INTEGER -> {
                            OutlinedTextField(
                                value = currentValue,
                                onValueChange = { newVal ->
                                    val digitsOnly = newVal.filter { it.isDigit() }
                                    val updatedParams = block.parameters.toMutableMap()
                                    updatedParams[param.key] = digitsOnly
                                    onUpdateBlock(block.copy(parameters = updatedParams))
                                },
                                label = { Text(param.label) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }

                        ParameterType.OPTION_LIST, ParameterType.PARSE_MODE -> {
                            var expandedOpt by remember { mutableStateOf(false) }
                            val optionsList = if (param.type == ParameterType.PARSE_MODE) {
                                listOf("MarkdownV2", "HTML", "Plain Text")
                            } else {
                                param.options
                            }

                            ExposedDropdownMenuBox(
                                expanded = expandedOpt,
                                onExpandedChange = { expandedOpt = it }
                            ) {
                                OutlinedTextField(
                                    value = currentValue,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text(param.label) },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedOpt) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .menuAnchor()
                                )
                                ExposedDropdownMenu(
                                    expanded = expandedOpt,
                                    onDismissRequest = { expandedOpt = false }
                                ) {
                                    optionsList.forEach { opt ->
                                        DropdownMenuItem(
                                            text = { Text(opt) },
                                            onClick = {
                                                val updatedParams = block.parameters.toMutableMap()
                                                updatedParams[param.key] = opt
                                                onUpdateBlock(block.copy(parameters = updatedParams))
                                                expandedOpt = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        else -> {}
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            // Keyboard Builder attachment button
            if (block.typeId in listOf("send_message", "send_photo", "send_document", "edit_message_text", "edit_message_reply_markup")) {
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedButton(
                    onClick = onOpenKeyboardBuilder,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("open_keyboard_builder_button")
                ) {
                    Icon(Icons.Default.Menu, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    val kbSummary = when {
                        block.inlineKeyboard != null && block.inlineKeyboard.rows.isNotEmpty() -> "Edit Inline Keyboard (${block.inlineKeyboard.rows.sumOf { it.buttons.size }} btns)"
                        block.replyKeyboard != null && block.replyKeyboard.rows.isNotEmpty() -> "Edit Reply Keyboard"
                        block.removeKeyboard != null -> "Edit Reply Markup (Remove)"
                        else -> "Attach Inline / Reply Keyboard"
                    }
                    Text(kbSummary)
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            Spacer(modifier = Modifier.height(6.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(12.dp))

            // Flow Routing Connections
            Text(
                text = "Flow Routing",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            val candidateBlocks = allBlocks.filter { it.id != block.id }

            // Next Block Selector
            BlockTargetSelector(
                label = if (block.typeId == "if_condition") "Follow-up After Branch" else "Next Connected Block",
                selectedTargetId = block.nextBlockId,
                candidateBlocks = candidateBlocks,
                onSelectTarget = { targetId ->
                    onUpdateBlock(block.copy(nextBlockId = targetId))
                }
            )

            // Branching Target Selectors (if condition or loop)
            if (block.typeId == "if_condition") {
                Spacer(modifier = Modifier.height(8.dp))
                BlockTargetSelector(
                    label = "If Condition True (Then)",
                    selectedTargetId = block.branchBlockId,
                    candidateBlocks = candidateBlocks,
                    onSelectTarget = { targetId ->
                        onUpdateBlock(block.copy(branchBlockId = targetId))
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))
                BlockTargetSelector(
                    label = "If Condition False (Else)",
                    selectedTargetId = block.elseBlockId,
                    candidateBlocks = candidateBlocks,
                    onSelectTarget = { targetId ->
                        onUpdateBlock(block.copy(elseBlockId = targetId))
                    }
                )
            } else if (block.typeId == "loop_times") {
                Spacer(modifier = Modifier.height(8.dp))
                BlockTargetSelector(
                    label = "Loop Body",
                    selectedTargetId = block.branchBlockId,
                    candidateBlocks = candidateBlocks,
                    onSelectTarget = { targetId ->
                        onUpdateBlock(block.copy(branchBlockId = targetId))
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BlockTargetSelector(
    label: String,
    selectedTargetId: String?,
    candidateBlocks: List<BlockNode>,
    onSelectTarget: (String?) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val currentTarget = candidateBlocks.find { it.id == selectedTargetId }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it }
    ) {
        OutlinedTextField(
            value = currentTarget?.title ?: "(None - End of Flow)",
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            DropdownMenuItem(
                text = { Text("(None - End of Flow)") },
                onClick = {
                    onSelectTarget(null)
                    expanded = false
                }
            )
            candidateBlocks.forEach { candidate ->
                DropdownMenuItem(
                    text = { Text("${candidate.title} [${candidate.typeId}]") },
                    onClick = {
                        onSelectTarget(candidate.id)
                        expanded = false
                    }
                )
            }
        }
    }
}
