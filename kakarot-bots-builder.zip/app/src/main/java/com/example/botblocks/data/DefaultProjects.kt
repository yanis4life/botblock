package com.example.botblocks.data

import com.example.botblocks.model.*
import java.util.UUID

object DefaultProjects {

    fun createStarterProjects(): List<Project> {
        return listOf(
            createMenuBot(),
            createModeratorBot(),
            createQuizBot()
        )
    }

    private fun createMenuBot(): Project {
        val projId = "menu-bot-starter"
        val onStartId = UUID.randomUUID().toString()
        val sendWelcomeId = UUID.randomUUID().toString()
        val onCallbackId = UUID.randomUUID().toString()
        val answerCallbackId = UUID.randomUUID().toString()
        val sendDetailId = UUID.randomUUID().toString()

        val welcomeInlineKeyboard = InlineKeyboardConfig(
            rows = listOf(
                InlineKeyboardRow(
                    buttons = listOf(
                        InlineButton(
                            text = "Explore Features",
                            actionType = ActionType.CALLBACK_DATA,
                            actionValue = "action_features",
                            style = ButtonStyle.PRIMARY
                        ),
                        InlineButton(
                            text = "Telegram Docs",
                            actionType = ActionType.URL,
                            actionValue = "https://core.telegram.org/bots/api",
                            style = ButtonStyle.DEFAULT
                        )
                    )
                ),
                InlineKeyboardRow(
                    buttons = listOf(
                        InlineButton(
                            text = "Reset State",
                            actionType = ActionType.CALLBACK_DATA,
                            actionValue = "action_reset",
                            style = ButtonStyle.DANGER
                        )
                    )
                )
            )
        )

        val onStartBlock = BlockNode(
            id = onStartId,
            typeId = "on_message",
            title = "On /start Command",
            category = BlockCategory.EVENTS,
            parameters = mapOf("filter_type" to "Command", "filter_value" to "/start"),
            nextBlockId = sendWelcomeId,
            posX = 60f,
            posY = 80f
        )

        val sendWelcomeBlock = BlockNode(
            id = sendWelcomeId,
            typeId = "send_message",
            title = "Send Welcome Message",
            category = BlockCategory.MESSAGES,
            parameters = mapOf(
                "chat_id" to "{chat_id}",
                "text" to "*Welcome to KAKAROT BOTS BUILDER\\!*\n\nThis bot was created using visual Sketchware\\-style blocks\\.\nSelect an option below to proceed\\:",
                "parse_mode" to "MarkdownV2",
                "disable_notification" to "false",
                "protect_content" to "false"
            ),
            inlineKeyboard = welcomeInlineKeyboard,
            posX = 60f,
            posY = 210f
        )

        val onCallbackBlock = BlockNode(
            id = onCallbackId,
            typeId = "on_callback_query",
            title = "On Button Click",
            category = BlockCategory.EVENTS,
            parameters = mapOf("filter_type" to "Exact Match", "data_pattern" to "action_features"),
            nextBlockId = answerCallbackId,
            posX = 380f,
            posY = 80f
        )

        val answerCallbackBlock = BlockNode(
            id = answerCallbackId,
            typeId = "answer_callback_query",
            title = "Acknowledge Button Click",
            category = BlockCategory.KEYBOARDS,
            parameters = mapOf(
                "callback_query_id" to "{callback_query_id}",
                "text" to "Loading features list...",
                "show_alert" to "false"
            ),
            nextBlockId = sendDetailId,
            posX = 380f,
            posY = 210f
        )

        val sendDetailBlock = BlockNode(
            id = sendDetailId,
            typeId = "send_message",
            title = "Send Features Overview",
            category = BlockCategory.MESSAGES,
            parameters = mapOf(
                "chat_id" to "{chat_id}",
                "text" to "*KAKAROT BOTS BUILDER Key Capabilities\\:*\n\n1\\. Sketchware interlocking puzzle blocks\n2\\. Telegram Bot API 9\\.0 style buttons\n3\\. Real on\\-device execution engine\n4\\. Clean Python code generator",
                "parse_mode" to "MarkdownV2"
            ),
            posX = 380f,
            posY = 340f
        )

        return Project(
            id = projId,
            name = "Interactive Menu Bot",
            description = "Welcome flow with multi-row styled buttons and callback handling",
            blocks = listOf(onStartBlock, sendWelcomeBlock, onCallbackBlock, answerCallbackBlock, sendDetailBlock)
        )
    }

    private fun createModeratorBot(): Project {
        val projId = "moderator-bot-starter"
        val onMsgId = UUID.randomUUID().toString()
        val ifConditionId = UUID.randomUUID().toString()
        val deleteMsgId = UUID.randomUUID().toString()
        val sendWarnId = UUID.randomUUID().toString()

        val onMsgBlock = BlockNode(
            id = onMsgId,
            typeId = "on_message",
            title = "On Every Message",
            category = BlockCategory.EVENTS,
            parameters = mapOf("filter_type" to "Any", "filter_value" to ""),
            nextBlockId = ifConditionId,
            posX = 80f,
            posY = 80f
        )

        val ifBlock = BlockNode(
            id = ifConditionId,
            typeId = "if_condition",
            title = "Check Forbidden Words",
            category = BlockCategory.LOGIC,
            parameters = mapOf(
                "left_operand" to "{text}",
                "operator" to "contains",
                "right_operand" to "spam"
            ),
            branchBlockId = deleteMsgId,
            posX = 80f,
            posY = 280f
        )

        val deleteBlock = BlockNode(
            id = deleteMsgId,
            typeId = "delete_message",
            title = "Delete Offending Message",
            category = BlockCategory.EDITING,
            parameters = mapOf(
                "chat_id" to "{chat_id}",
                "message_id" to "{message_id}"
            ),
            nextBlockId = sendWarnId,
            posX = 80f,
            posY = 500f
        )

        val warnBlock = BlockNode(
            id = sendWarnId,
            typeId = "send_message",
            title = "Send Warning Notice",
            category = BlockCategory.MESSAGES,
            parameters = mapOf(
                "chat_id" to "{chat_id}",
                "text" to "Notice: Message deleted due to rule violations.",
                "parse_mode" to ""
            ),
            posX = 80f,
            posY = 700f
        )

        return Project(
            id = projId,
            name = "Chat Moderator Bot",
            description = "Filters unwanted messages and takes disciplinary action",
            blocks = listOf(onMsgBlock, ifBlock, deleteBlock, warnBlock)
        )
    }

    private fun createQuizBot(): Project {
        val projId = "quiz-bot-starter"
        val onQuizId = UUID.randomUUID().toString()
        val sendPollId = UUID.randomUUID().toString()

        val onQuizBlock = BlockNode(
            id = onQuizId,
            typeId = "on_message",
            title = "On /quiz Command",
            category = BlockCategory.EVENTS,
            parameters = mapOf("filter_type" to "Command", "filter_value" to "/quiz"),
            nextBlockId = sendPollId,
            posX = 80f,
            posY = 80f
        )

        val sendPollBlock = BlockNode(
            id = sendPollId,
            typeId = "send_poll",
            title = "Dispatch Quiz Poll",
            category = BlockCategory.MESSAGES,
            parameters = mapOf(
                "chat_id" to "{chat_id}",
                "question" to "Which language does BotBlocks export to natively?",
                "options" to "JavaScript, Python, C++, Rust",
                "is_anonymous" to "false",
                "type" to "quiz",
                "correct_option_id" to "1",
                "explanation" to "KAKAROT BOTS BUILDER exports PEP 8 compliant async python-telegram-bot code."
            ),
            posX = 80f,
            posY = 280f
        )

        return Project(
            id = projId,
            name = "Quiz & Poll Bot",
            description = "Dispatches interactive quizzes with scoring and explanations",
            blocks = listOf(onQuizBlock, sendPollBlock)
        )
    }
}
