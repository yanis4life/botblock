package com.example.botblocks.data

import android.content.Context
import androidx.room.Room
import com.example.botblocks.model.Project
import com.example.botblocks.model.ProjectVersion
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

class ProjectRepository(context: Context) {

    private val db = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "botblocks_database.db"
    )
        .fallbackToDestructiveMigration()
        .build()

    private val dao = db.projectDao()

    fun getAllProjects(): Flow<List<Project>> {
        return dao.getAllProjects().map { entities ->
            entities.map { it.toProject() }
        }
    }

    suspend fun getProjectById(id: String): Project? {
        return dao.getProjectById(id)?.toProject()
    }

    suspend fun saveProject(project: Project) {
        val updated = project.copy(updatedAt = System.currentTimeMillis())
        dao.insertProject(ProjectEntity.fromProject(updated))
    }

    suspend fun deleteProject(projectId: String) {
        dao.deleteProjectById(projectId)
    }

    suspend fun duplicateProject(project: Project): Project {
        val newProject = project.copy(
            id = UUID.randomUUID().toString(),
            name = "${project.name} (Copy)",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        saveProject(newProject)
        return newProject
    }

    suspend fun initializeDefaultsIfNeeded() {
        val currentList = dao.getAllProjects().first()
        if (currentList.isEmpty()) {
            val starters = DefaultProjects.createStarterProjects()
            for (p in starters) {
                dao.insertProject(ProjectEntity.fromProject(p))
                // Create initial v1.0 commit for starter projects
                val snapJson = ProjectSerializer.toJson(p)
                val initialVer = ProjectVersion(
                    id = UUID.randomUUID().toString(),
                    projectId = p.id,
                    versionName = "v1.0 - Initial",
                    description = "Default starter template snapshot",
                    snapshotJson = snapJson,
                    blockCount = p.blocks.size,
                    timestamp = p.createdAt
                )
                dao.insertVersion(ProjectVersionEntity.fromProjectVersion(initialVer))
            }
        }
    }

    // Version Control Operations
    fun getProjectVersions(projectId: String): Flow<List<ProjectVersion>> {
        return dao.getVersionsForProject(projectId).map { entities ->
            entities.map { it.toProjectVersion() }
        }
    }

    suspend fun createProjectVersion(
        projectId: String,
        versionName: String,
        description: String,
        project: Project
    ): ProjectVersion {
        val snapJson = ProjectSerializer.toJson(project)
        val version = ProjectVersion(
            id = UUID.randomUUID().toString(),
            projectId = projectId,
            versionName = versionName,
            description = description,
            snapshotJson = snapJson,
            blockCount = project.blocks.size,
            timestamp = System.currentTimeMillis()
        )
        dao.insertVersion(ProjectVersionEntity.fromProjectVersion(version))
        return version
    }

    suspend fun restoreVersion(versionId: String): Project? {
        val entity = dao.getVersionById(versionId) ?: return null
        val restoredProject = ProjectSerializer.fromJson(entity.snapshotJson)
        val updated = restoredProject.copy(updatedAt = System.currentTimeMillis())
        dao.insertProject(ProjectEntity.fromProject(updated))
        return updated
    }

    suspend fun deleteVersion(versionId: String) {
        dao.deleteVersion(versionId)
    }
}
