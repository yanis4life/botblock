package com.example.botblocks.format

object TelegramFormatter {

    private val MARKDOWN_V2_CHARS = setOf(
        '_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!'
    )

    fun escapeMarkdownV2(text: String): String {
        val sb = StringBuilder(text.length * 2)
        for (ch in text) {
            if (ch in MARKDOWN_V2_CHARS || ch == '\\') {
                sb.append('\\')
            }
            sb.append(ch)
        }
        return sb.toString()
    }

    fun escapeHtml(text: String): String {
        return text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
    }

    fun wrapBold(text: String, mode: String): String {
        return when (mode.lowercase()) {
            "markdownv2", "markdown_v2" -> "*${escapeMarkdownV2(text)}*"
            "html" -> "<b>${escapeHtml(text)}</b>"
            else -> text
        }
    }

    fun wrapItalic(text: String, mode: String): String {
        return when (mode.lowercase()) {
            "markdownv2", "markdown_v2" -> "_${escapeMarkdownV2(text)}_"
            "html" -> "<i>${escapeHtml(text)}</i>"
            else -> text
        }
    }

    fun wrapCode(text: String, mode: String): String {
        return when (mode.lowercase()) {
            "markdownv2", "markdown_v2" -> "`" + text.replace("\\", "\\\\").replace("`", "\\`") + "`"
            "html" -> "<code>${escapeHtml(text)}</code>"
            else -> text
        }
    }

    fun wrapCodeBlock(text: String, language: String, mode: String): String {
        return when (mode.lowercase()) {
            "markdownv2", "markdown_v2" -> "```$language\n" + text.replace("\\", "\\\\").replace("`", "\\`") + "\n```"
            "html" -> "<pre><code class=\"language-$language\">${escapeHtml(text)}</code></pre>"
            else -> text
        }
    }

    fun wrapUnderline(text: String, mode: String): String {
        return when (mode.lowercase()) {
            "markdownv2", "markdown_v2" -> "__${escapeMarkdownV2(text)}__"
            "html" -> "<u>${escapeHtml(text)}</u>"
            else -> text
        }
    }

    fun wrapStrikethrough(text: String, mode: String): String {
        return when (mode.lowercase()) {
            "markdownv2", "markdown_v2" -> "~${escapeMarkdownV2(text)}~"
            "html" -> "<s>${escapeHtml(text)}</s>"
            else -> text
        }
    }

    fun wrapSpoiler(text: String, mode: String): String {
        return when (mode.lowercase()) {
            "markdownv2", "markdown_v2" -> "||${escapeMarkdownV2(text)}||"
            "html" -> "<tg-spoiler>${escapeHtml(text)}</tg-spoiler>"
            else -> text
        }
    }

    fun wrapLink(text: String, url: String, mode: String): String {
        return when (mode.lowercase()) {
            "markdownv2", "markdown_v2" -> "[${escapeMarkdownV2(text)}](${escapeMarkdownV2(url)})"
            "html" -> "<a href=\"${escapeHtml(url)}\">${escapeHtml(text)}</a>"
            else -> "$text ($url)"
        }
    }

    fun validateCallbackData(data: String): Pair<Boolean, String> {
        val bytes = data.toByteArray(Charsets.UTF_8).size
        return if (bytes > 64) {
            Pair(false, "Exceeds 64 bytes limit ($bytes bytes). Telegram will reject this callback data.")
        } else {
            Pair(true, "$bytes / 64 bytes")
        }
    }
}
