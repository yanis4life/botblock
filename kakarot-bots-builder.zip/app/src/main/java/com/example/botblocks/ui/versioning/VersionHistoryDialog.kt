package com.example.botblocks.ui.versioning

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.botblocks.model.Project
import com.example.botblocks.model.ProjectVersion
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VersionHistoryDialog(
    project: Project,
    versions: List<ProjectVersion>,
    onCreateVersion: (name: String, description: String) -> Unit,
    onRestoreVersion: (versionId: String) -> Unit,
    onDeleteVersion: (versionId: String) -> Unit,
    onDuplicateAsProject: (version: ProjectVersion) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var isCreatingSnapshot by remember { mutableStateOf(false) }
    var newVersionName by remember { mutableStateOf("") }
    var newVersionDescription by remember { mutableStateOf("") }

    var selectedVersionToPreview by remember { mutableStateOf<ProjectVersion?>(null) }
    var confirmRestoreVersion by remember { mutableStateOf<ProjectVersion?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(12.dp))
                .testTag("version_history_dialog"),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Version Control: ${project.name}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Snapshot history, commit checkpoints, and rollback",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_versions_button")) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Create Snapshot Banner / Button
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Current State: ${project.blocks.size} visual blocks",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Save a named commit checkpoint before making major edits",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = { isCreatingSnapshot = true },
                            modifier = Modifier.testTag("create_snapshot_button")
                        ) {
                            Icon(Icons.Default.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Create Version")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Saved Version History (${versions.size})",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Versions list
                if (versions.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No version snapshots saved yet. Click 'Create Version' above to commit a snapshot.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(versions) { ver ->
                            VersionItemCard(
                                version = ver,
                                onRestore = { confirmRestoreVersion = ver },
                                onDuplicate = { onDuplicateAsProject(ver) },
                                onPreview = { selectedVersionToPreview = ver },
                                onDelete = { onDeleteVersion(ver.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Create Version Snapshot Dialog
    if (isCreatingSnapshot) {
        AlertDialog(
            onDismissRequest = { isCreatingSnapshot = false },
            title = { Text("Create Version Snapshot") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newVersionName,
                        onValueChange = { newVersionName = it },
                        label = { Text("Version Label") },
                        placeholder = { Text("e.g. v1.1 - Added Welcome Menu") },
                        modifier = Modifier.fillMaxWidth().testTag("version_name_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newVersionDescription,
                        onValueChange = { newVersionDescription = it },
                        label = { Text("Changelog / Notes (Optional)") },
                        placeholder = { Text("Summary of block changes or new methods added...") },
                        modifier = Modifier.fillMaxWidth().testTag("version_desc_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = newVersionName.trim().ifBlank { "v${versions.size + 1}.0" }
                        onCreateVersion(name, newVersionDescription.trim())
                        isCreatingSnapshot = false
                        newVersionName = ""
                        newVersionDescription = ""
                        Toast.makeText(context, "Version snapshot saved", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("confirm_create_version_button")
                ) {
                    Text("Save Snapshot")
                }
            },
            dismissButton = {
                TextButton(onClick = { isCreatingSnapshot = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Confirm Rollback / Restore Dialog
    confirmRestoreVersion?.let { ver ->
        AlertDialog(
            onDismissRequest = { confirmRestoreVersion = null },
            title = { Text("Restore Version: ${ver.versionName}?") },
            text = {
                Text("This will replace the current canvas blocks and parameters with the state saved in this snapshot (${ver.blockCount} blocks).")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRestoreVersion(ver.id)
                        confirmRestoreVersion = null
                        onDismiss()
                        Toast.makeText(context, "Restored to ${ver.versionName}", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("confirm_restore_button")
                ) {
                    Text("Restore")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmRestoreVersion = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Preview Snapshot JSON Dialog
    selectedVersionToPreview?.let { ver ->
        AlertDialog(
            onDismissRequest = { selectedVersionToPreview = null },
            title = { Text("Snapshot JSON: ${ver.versionName}") },
            text = {
                Column {
                    OutlinedTextField(
                        value = ver.snapshotJson,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().height(260.dp),
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("${ver.versionName}.json", ver.snapshotJson)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Copied snapshot JSON", Toast.LENGTH_SHORT).show()
                        selectedVersionToPreview = null
                    }
                ) {
                    Text("Copy JSON")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedVersionToPreview = null }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun VersionItemCard(
    version: ProjectVersion,
    onRestore: () -> Unit,
    onDuplicate: () -> Unit,
    onPreview: () -> Unit,
    onDelete: () -> Unit
) {
    val dateStr = remember(version.timestamp) {
        val sdf = SimpleDateFormat("MMM d, yyyy HH:mm:ss", Locale.getDefault())
        sdf.format(Date(version.timestamp))
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp)),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = version.versionName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$dateStr | ${version.blockCount} blocks",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onPreview, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Code, contentDescription = "Preview JSON", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDuplicate, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Fork As Project", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Version", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                    }
                }
            }

            if (version.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = version.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = onRestore,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("restore_version_${version.id}")
                ) {
                    Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Restore to this Version", fontSize = 11.sp)
                }
            }
        }
    }
}
