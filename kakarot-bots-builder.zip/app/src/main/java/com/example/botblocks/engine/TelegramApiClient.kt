package com.example.botblocks.engine

import com.example.botblocks.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class TelegramApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun callMethod(
        token: String,
        methodName: String,
        params: Map<String, Any?> = emptyMap()
    ): Result<JSONObject> = withContext(Dispatchers.IO) {
        if (token.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Bot token is empty. Please set your Telegram bot token in project settings."))
        }

        val url = "https://api.telegram.org/bot$token/$methodName"
        val jsonBody = JSONObject()

        for ((key, value) in params) {
            if (value != null) {
                jsonBody.put(key, value)
            }
        }

        val body = jsonBody.toString().toRequestBody(jsonMediaType)
        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string().orEmpty()
                if (responseStr.isBlank()) {
                    return@withContext Result.failure(IOException("Empty response from Telegram API (HTTP ${response.code})"))
                }

                val jsonResponse = try {
                    JSONObject(responseStr)
                } catch (e: Exception) {
                    return@withContext Result.failure(IOException("Invalid JSON response from Telegram: $responseStr", e))
                }

                val ok = jsonResponse.optBoolean("ok", false)
                if (ok) {
                    Result.success(jsonResponse)
                } else {
                    val errorCode = jsonResponse.optInt("error_code", response.code)
                    val description = jsonResponse.optString("description", "Unknown Telegram API error")
                    Result.failure(TelegramApiException(errorCode, description))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getMe(token: String): Result<JSONObject> {
        return callMethod(token, "getMe")
    }

    suspend fun getUpdates(
        token: String,
        offset: Long? = null,
        timeout: Int = 20,
        allowedUpdates: List<String>? = null
    ): Result<JSONObject> {
        val params = mutableMapOf<String, Any?>("timeout" to timeout)
        if (offset != null) {
            params["offset"] = offset
        }
        if (allowedUpdates != null) {
            params["allowed_updates"] = JSONArray(allowedUpdates)
        }
        return callMethod(token, "getUpdates", params)
    }

    suspend fun setWebhook(
        token: String,
        url: String,
        secretToken: String? = null,
        maxConnections: Int? = null
    ): Result<JSONObject> {
        val params = mutableMapOf<String, Any?>("url" to url)
        if (!secretToken.isNullOrBlank()) params["secret_token"] = secretToken
        if (maxConnections != null && maxConnections > 0) params["max_connections"] = maxConnections
        return callMethod(token, "setWebhook", params)
    }

    suspend fun deleteWebhook(token: String, dropPendingUpdates: Boolean = false): Result<JSONObject> {
        return callMethod(token, "deleteWebhook", mapOf("drop_pending_updates" to dropPendingUpdates))
    }

    suspend fun getWebhookInfo(token: String): Result<JSONObject> {
        return callMethod(token, "getWebhookInfo")
    }

    companion object {
        fun buildInlineKeyboardJson(config: InlineKeyboardConfig): JSONObject {
            val root = JSONObject()
            val keyboardArray = JSONArray()

            for (row in config.rows) {
                val rowArray = JSONArray()
                for (btn in row.buttons) {
                    val btnObj = JSONObject()
                    btnObj.put("text", btn.text)
                    when (btn.actionType) {
                        ActionType.CALLBACK_DATA -> btnObj.put("callback_data", btn.actionValue)
                        ActionType.URL -> btnObj.put("url", btn.actionValue)
                        ActionType.WEB_APP -> {
                            val webAppObj = JSONObject()
                            webAppObj.put("url", btn.actionValue)
                            btnObj.put("web_app", webAppObj)
                        }
                        ActionType.LOGIN_URL -> {
                            val loginObj = JSONObject()
                            loginObj.put("url", btn.actionValue)
                            btnObj.put("login_url", loginObj)
                        }
                        ActionType.SWITCH_INLINE_QUERY -> btnObj.put("switch_inline_query", btn.actionValue)
                        ActionType.SWITCH_INLINE_QUERY_CURRENT_CHAT -> btnObj.put("switch_inline_query_current_chat", btn.actionValue)
                        ActionType.PAY -> btnObj.put("pay", true)
                        ActionType.COPY_TEXT -> {
                            val copyObj = JSONObject()
                            copyObj.put("text", btn.actionValue)
                            btnObj.put("copy_text", copyObj)
                        }
                    }
                    if (btn.style != ButtonStyle.DEFAULT) {
                        btnObj.put("style", btn.style.apiValue)
                    }
                    rowArray.put(btnObj)
                }
                keyboardArray.put(rowArray)
            }
            root.put("inline_keyboard", keyboardArray)
            return root
        }

        fun buildReplyKeyboardJson(config: ReplyKeyboardConfig): JSONObject {
            val root = JSONObject()
            val keyboardArray = JSONArray()

            for (row in config.rows) {
                val rowArray = JSONArray()
                for (btn in row.buttons) {
                    val btnObj = JSONObject()
                    btnObj.put("text", btn.text)
                    if (btn.requestContact) btnObj.put("request_contact", true)
                    if (btn.requestLocation) btnObj.put("request_location", true)
                    rowArray.put(btnObj)
                }
                keyboardArray.put(rowArray)
            }
            root.put("keyboard", keyboardArray)
            root.put("resize_keyboard", config.resizeKeyboard)
            root.put("one_time_keyboard", config.oneTimeKeyboard)
            root.put("selective", config.selective)
            if (config.inputFieldPlaceholder.isNotBlank()) {
                root.put("input_field_placeholder", config.inputFieldPlaceholder)
            }
            return root
        }

        fun buildRemoveKeyboardJson(config: RemoveKeyboardConfig): JSONObject {
            val root = JSONObject()
            root.put("remove_keyboard", config.removeKeyboard)
            root.put("selective", config.selective)
            return root
        }
    }
}

class TelegramApiException(val errorCode: Int, override val message: String) : Exception("Telegram API error $errorCode: $message")
