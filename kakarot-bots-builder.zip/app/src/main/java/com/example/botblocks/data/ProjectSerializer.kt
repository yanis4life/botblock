package com.example.botblocks.data

import com.example.botblocks.model.*
import org.json.JSONArray
import org.json.JSONObject

object ProjectSerializer {

    fun toJson(project: Project): String {
        val root = JSONObject()
        root.put("id", project.id)
        root.put("name", project.name)
        root.put("description", project.description)
        root.put("botToken", project.botToken)
        root.put("executionMode", project.executionMode.name)
        root.put("webhookUrl", project.webhookUrl)
        root.put("createdAt", project.createdAt)
        root.put("updatedAt", project.updatedAt)

        val varsObj = JSONObject()
        project.variables.forEach { (k, v) -> varsObj.put(k, v) }
        root.put("variables", varsObj)

        val blocksArray = JSONArray()
        for (block in project.blocks) {
            val blockObj = JSONObject()
            blockObj.put("id", block.id)
            blockObj.put("typeId", block.typeId)
            blockObj.put("title", block.title)
            blockObj.put("category", block.category.name)
            blockObj.put("posX", block.posX.toDouble())
            blockObj.put("posY", block.posY.toDouble())
            block.nextBlockId?.let { blockObj.put("nextBlockId", it) }
            block.branchBlockId?.let { blockObj.put("branchBlockId", it) }
            block.elseBlockId?.let { blockObj.put("elseBlockId", it) }

            val paramsObj = JSONObject()
            block.parameters.forEach { (k, v) -> paramsObj.put(k, v) }
            blockObj.put("parameters", paramsObj)

            block.inlineKeyboard?.let { kb ->
                val kbObj = JSONObject()
                val rowsArray = JSONArray()
                for (row in kb.rows) {
                    val rowObj = JSONObject()
                    rowObj.put("id", row.id)
                    val btnsArray = JSONArray()
                    for (btn in row.buttons) {
                        val btnObj = JSONObject()
                        btnObj.put("id", btn.id)
                        btnObj.put("text", btn.text)
                        btnObj.put("actionType", btn.actionType.name)
                        btnObj.put("actionValue", btn.actionValue)
                        btnObj.put("style", btn.style.name)
                        btnsArray.put(btnObj)
                    }
                    rowObj.put("buttons", btnsArray)
                    rowsArray.put(rowObj)
                }
                kbObj.put("rows", rowsArray)
                blockObj.put("inlineKeyboard", kbObj)
            }

            block.replyKeyboard?.let { rkb ->
                val rkbObj = JSONObject()
                rkbObj.put("resizeKeyboard", rkb.resizeKeyboard)
                rkbObj.put("oneTimeKeyboard", rkb.oneTimeKeyboard)
                rkbObj.put("selective", rkb.selective)
                rkbObj.put("inputFieldPlaceholder", rkb.inputFieldPlaceholder)
                val rowsArray = JSONArray()
                for (row in rkb.rows) {
                    val rowObj = JSONObject()
                    rowObj.put("id", row.id)
                    val btnsArray = JSONArray()
                    for (btn in row.buttons) {
                        val btnObj = JSONObject()
                        btnObj.put("id", btn.id)
                        btnObj.put("text", btn.text)
                        btnObj.put("requestContact", btn.requestContact)
                        btnObj.put("requestLocation", btn.requestLocation)
                        btnsArray.put(btnObj)
                    }
                    rowObj.put("buttons", btnsArray)
                    rowsArray.put(rowObj)
                }
                rkbObj.put("rows", rowsArray)
                blockObj.put("replyKeyboard", rkbObj)
            }

            block.removeKeyboard?.let { rem ->
                val remObj = JSONObject()
                remObj.put("removeKeyboard", rem.removeKeyboard)
                remObj.put("selective", rem.selective)
                blockObj.put("removeKeyboard", remObj)
            }

            blocksArray.put(blockObj)
        }
        root.put("blocks", blocksArray)

        return root.toString(2)
    }

    fun fromJson(jsonStr: String): Project {
        val root = JSONObject(jsonStr)
        val id = root.optString("id", java.util.UUID.randomUUID().toString())
        val name = root.optString("name", "Imported Project")
        val description = root.optString("description", "")
        val botToken = root.optString("botToken", "")
        val executionMode = try {
            ExecutionMode.valueOf(root.optString("executionMode", ExecutionMode.LONG_POLLING.name))
        } catch (_: Exception) {
            ExecutionMode.LONG_POLLING
        }
        val webhookUrl = root.optString("webhookUrl", "")
        val createdAt = root.optLong("createdAt", System.currentTimeMillis())
        val updatedAt = root.optLong("updatedAt", System.currentTimeMillis())

        val variables = mutableMapOf<String, String>()
        val varsObj = root.optJSONObject("variables")
        if (varsObj != null) {
            val keys = varsObj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                variables[k] = varsObj.optString(k, "")
            }
        }

        val blocks = mutableListOf<BlockNode>()
        val blocksArray = root.optJSONArray("blocks")
        if (blocksArray != null) {
            for (i in 0 until blocksArray.length()) {
                val bObj = blocksArray.getJSONObject(i)
                val blockId = bObj.getString("id")
                val typeId = bObj.getString("typeId")
                val title = bObj.optString("title", typeId)
                val category = try {
                    BlockCategory.valueOf(bObj.optString("category", BlockCategory.MESSAGES.name))
                } catch (_: Exception) {
                    BlockCategory.MESSAGES
                }
                val posX = bObj.optDouble("posX", 0.0).toFloat()
                val posY = bObj.optDouble("posY", 0.0).toFloat()
                val nextBlockId = if (bObj.has("nextBlockId")) bObj.getString("nextBlockId") else null
                val branchBlockId = if (bObj.has("branchBlockId")) bObj.getString("branchBlockId") else null
                val elseBlockId = if (bObj.has("elseBlockId")) bObj.getString("elseBlockId") else null

                val parameters = mutableMapOf<String, String>()
                val paramsObj = bObj.optJSONObject("parameters")
                if (paramsObj != null) {
                    val pKeys = paramsObj.keys()
                    while (pKeys.hasNext()) {
                        val pk = pKeys.next()
                        parameters[pk] = paramsObj.getString(pk)
                    }
                }

                var inlineKeyboard: InlineKeyboardConfig? = null
                val ikbObj = bObj.optJSONObject("inlineKeyboard")
                if (ikbObj != null) {
                    val rowsList = mutableListOf<InlineKeyboardRow>()
                    val rArr = ikbObj.optJSONArray("rows")
                    if (rArr != null) {
                        for (r in 0 until rArr.length()) {
                            val rObj = rArr.getJSONObject(r)
                            val rowId = rObj.optString("id", java.util.UUID.randomUUID().toString())
                            val btnsList = mutableListOf<InlineButton>()
                            val btnsArr = rObj.optJSONArray("buttons")
                            if (btnsArr != null) {
                                for (b in 0 until btnsArr.length()) {
                                    val btnObj = btnsArr.getJSONObject(b)
                                    val btnId = btnObj.optString("id", java.util.UUID.randomUUID().toString())
                                    val btnText = btnObj.optString("text", "Button")
                                    val actType = try {
                                        ActionType.valueOf(btnObj.optString("actionType", ActionType.CALLBACK_DATA.name))
                                    } catch (_: Exception) {
                                        ActionType.CALLBACK_DATA
                                    }
                                    val actVal = btnObj.optString("actionValue", "")
                                    val style = try {
                                        ButtonStyle.valueOf(btnObj.optString("style", ButtonStyle.DEFAULT.name))
                                    } catch (_: Exception) {
                                        ButtonStyle.DEFAULT
                                    }
                                    btnsList.add(InlineButton(btnId, btnText, actType, actVal, style))
                                }
                            }
                            rowsList.add(InlineKeyboardRow(rowId, btnsList))
                        }
                    }
                    inlineKeyboard = InlineKeyboardConfig(rowsList)
                }

                var replyKeyboard: ReplyKeyboardConfig? = null
                val rkbObj = bObj.optJSONObject("replyKeyboard")
                if (rkbObj != null) {
                    val resize = rkbObj.optBoolean("resizeKeyboard", true)
                    val oneTime = rkbObj.optBoolean("oneTimeKeyboard", false)
                    val selective = rkbObj.optBoolean("selective", false)
                    val placeholder = rkbObj.optString("inputFieldPlaceholder", "")
                    val rowsList = mutableListOf<ReplyKeyboardRow>()
                    val rArr = rkbObj.optJSONArray("rows")
                    if (rArr != null) {
                        for (r in 0 until rArr.length()) {
                            val rObj = rArr.getJSONObject(r)
                            val rowId = rObj.optString("id", java.util.UUID.randomUUID().toString())
                            val btnsList = mutableListOf<ReplyKeyboardButton>()
                            val btnsArr = rObj.optJSONArray("buttons")
                            if (btnsArr != null) {
                                for (b in 0 until btnsArr.length()) {
                                    val btnObj = btnsArr.getJSONObject(b)
                                    val btnId = btnObj.optString("id", java.util.UUID.randomUUID().toString())
                                    val btnText = btnObj.optString("text", "Option")
                                    val reqContact = btnObj.optBoolean("requestContact", false)
                                    val reqLoc = btnObj.optBoolean("requestLocation", false)
                                    btnsList.add(ReplyKeyboardButton(btnId, btnText, reqContact, reqLoc))
                                }
                            }
                            rowsList.add(ReplyKeyboardRow(rowId, btnsList))
                        }
                    }
                    replyKeyboard = ReplyKeyboardConfig(rowsList, resize, oneTime, selective, placeholder)
                }

                var removeKeyboard: RemoveKeyboardConfig? = null
                val remObj = bObj.optJSONObject("removeKeyboard")
                if (remObj != null) {
                    removeKeyboard = RemoveKeyboardConfig(
                        removeKeyboard = remObj.optBoolean("removeKeyboard", true),
                        selective = remObj.optBoolean("selective", false)
                    )
                }

                blocks.add(
                    BlockNode(
                        id = blockId,
                        typeId = typeId,
                        title = title,
                        category = category,
                        parameters = parameters,
                        inlineKeyboard = inlineKeyboard,
                        replyKeyboard = replyKeyboard,
                        removeKeyboard = removeKeyboard,
                        nextBlockId = nextBlockId,
                        branchBlockId = branchBlockId,
                        elseBlockId = elseBlockId,
                        posX = posX,
                        posY = posY
                    )
                )
            }
        }

        return Project(
            id = id,
            name = name,
            description = description,
            botToken = botToken,
            executionMode = executionMode,
            webhookUrl = webhookUrl,
            blocks = blocks,
            variables = variables,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }
}
