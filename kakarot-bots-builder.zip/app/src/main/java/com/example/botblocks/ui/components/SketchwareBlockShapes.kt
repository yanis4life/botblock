package com.example.botblocks.ui.components

import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection

enum class SketchwareBlockForm {
    EVENT_HAT,
    STATEMENT,
    C_CONTAINER
}

class SketchwarePuzzleShape(
    val form: SketchwareBlockForm = SketchwareBlockForm.STATEMENT,
    val notchLeft: Float = 24f,
    val notchWidth: Float = 36f,
    val notchDepth: Float = 10f,
    val cornerRadius: Float = 12f
) : Shape {

    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline {
        val path = Path()
        val w = size.width
        val h = size.height
        val cr = cornerRadius
        val nL = notchLeft
        val nR = notchLeft + notchWidth
        val nD = notchDepth

        when (form) {
            SketchwareBlockForm.EVENT_HAT -> {
                // Sketchware Event "Hat" curved dome
                path.moveTo(0f, 18f)
                path.cubicTo(0f, 4f, 16f, 0f, 32f, 0f)
                path.cubicTo(56f, 0f, 72f, 8f, 96f, 12f)
                path.lineTo(w - cr, 12f)
                path.quadraticTo(w, 12f, w, 12f + cr)

                // Right vertical side
                path.lineTo(w, h - cr)
                path.quadraticTo(w, h, w - cr, h)

                // Bottom with interlocking puzzle tab
                path.lineTo(nR, h)
                path.lineTo(nR - 4f, h + nD)
                path.lineTo(nL + 4f, h + nD)
                path.lineTo(nL, h)

                // Left corner
                path.lineTo(cr, h)
                path.quadraticTo(0f, h, 0f, h - cr)
                path.close()
            }

            SketchwareBlockForm.STATEMENT -> {
                // Top with puzzle notch (inward indent)
                path.moveTo(0f, cr)
                path.quadraticTo(0f, 0f, cr, 0f)
                path.lineTo(nL, 0f)
                path.lineTo(nL + 4f, nD)
                path.lineTo(nR - 4f, nD)
                path.lineTo(nR, 0f)
                path.lineTo(w - cr, 0f)
                path.quadraticTo(w, 0f, w, cr)

                // Right vertical edge
                path.lineTo(w, h - cr)
                path.quadraticTo(w, h, w - cr, h)

                // Bottom with interlocking puzzle tab (outward protrusion)
                path.lineTo(nR, h)
                path.lineTo(nR - 4f, h + nD)
                path.lineTo(nL + 4f, h + nD)
                path.lineTo(nL, h)

                // Left bottom edge
                path.lineTo(cr, h)
                path.quadraticTo(0f, h, 0f, h - cr)
                path.close()
            }

            SketchwareBlockForm.C_CONTAINER -> {
                // Top with puzzle notch
                path.moveTo(0f, cr)
                path.quadraticTo(0f, 0f, cr, 0f)
                path.lineTo(nL, 0f)
                path.lineTo(nL + 4f, nD)
                path.lineTo(nR - 4f, nD)
                path.lineTo(nR, 0f)
                path.lineTo(w - cr, 0f)
                path.quadraticTo(w, 0f, w, cr)

                // Right edge of top header
                val headerBottom = 54f
                path.lineTo(w, headerBottom)
                path.lineTo(nL + 20f, headerBottom)

                // Inner notch on top of mouth
                path.lineTo(nL + 20f - 4f, headerBottom + nD)
                path.lineTo(nL + 4f, headerBottom + nD)
                path.lineTo(nL, headerBottom)
                path.lineTo(18f, headerBottom)

                // Inner spine left edge
                val mouthBottom = h - 28f
                path.lineTo(18f, mouthBottom)
                path.lineTo(w - cr, mouthBottom)
                path.quadraticTo(w, mouthBottom, w, mouthBottom + cr)

                // Bottom right edge
                path.lineTo(w, h - cr)
                path.quadraticTo(w, h, w - cr, h)

                // Bottom outer puzzle tab
                path.lineTo(nR, h)
                path.lineTo(nR - 4f, h + nD)
                path.lineTo(nL + 4f, h + nD)
                path.lineTo(nL, h)

                // Left edge
                path.lineTo(cr, h)
                path.quadraticTo(0f, h, 0f, h - cr)
                path.close()
            }
        }

        return Outline.Generic(path)
    }
}
