package com.example.botblocks.data

import androidx.room.*
import com.example.botblocks.model.Project
import com.example.botblocks.model.ProjectVersion
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val botToken: String,
    val executionMode: String,
    val webhookUrl: String,
    val jsonContent: String,
    val updatedAt: Long,
    val createdAt: Long
) {
    fun toProject(): Project {
        return try {
            ProjectSerializer.fromJson(jsonContent)
        } catch (_: Exception) {
            Project(
                id = id,
                name = name,
                description = description,
                botToken = botToken,
                updatedAt = updatedAt,
                createdAt = createdAt
            )
        }
    }

    companion object {
        fun fromProject(project: Project): ProjectEntity {
            return ProjectEntity(
                id = project.id,
                name = project.name,
                description = project.description,
                botToken = project.botToken,
                executionMode = project.executionMode.name,
                webhookUrl = project.webhookUrl,
                jsonContent = ProjectSerializer.toJson(project),
                updatedAt = project.updatedAt,
                createdAt = project.createdAt
            )
        }
    }
}

@Entity(
    tableName = "project_versions",
    indices = [Index("projectId")]
)
data class ProjectVersionEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val versionName: String,
    val description: String,
    val snapshotJson: String,
    val blockCount: Int,
    val timestamp: Long
) {
    fun toProjectVersion(): ProjectVersion {
        return ProjectVersion(
            id = id,
            projectId = projectId,
            versionName = versionName,
            description = description,
            snapshotJson = snapshotJson,
            blockCount = blockCount,
            timestamp = timestamp
        )
    }

    companion object {
        fun fromProjectVersion(version: ProjectVersion): ProjectVersionEntity {
            return ProjectVersionEntity(
                id = version.id,
                projectId = version.projectId,
                versionName = version.versionName,
                description = version.description,
                snapshotJson = version.snapshotJson,
                blockCount = version.blockCount,
                timestamp = version.timestamp
            )
        }
    }
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: String)

    // Version Control Queries
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVersion(version: ProjectVersionEntity)

    @Query("SELECT * FROM project_versions WHERE projectId = :projectId ORDER BY timestamp DESC")
    fun getVersionsForProject(projectId: String): Flow<List<ProjectVersionEntity>>

    @Query("SELECT * FROM project_versions WHERE id = :versionId LIMIT 1")
    suspend fun getVersionById(versionId: String): ProjectVersionEntity?

    @Query("DELETE FROM project_versions WHERE id = :versionId")
    suspend fun deleteVersion(versionId: String)
}

@Database(entities = [ProjectEntity::class, ProjectVersionEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
}
